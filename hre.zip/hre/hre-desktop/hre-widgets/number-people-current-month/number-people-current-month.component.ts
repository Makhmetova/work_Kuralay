import { Component, Inject, Input, OnInit, PLATFORM_ID } from '@angular/core';
// amCharts imports
import * as am4core from '@amcharts/amcharts4/core';
import * as am4charts from '@amcharts/amcharts4/charts';
import am4themes_animated from '@amcharts/amcharts4/themes/animated';
import { isPlatformBrowser } from '@angular/common';
import { NgZone } from '@angular/core';
import { PrsnaWidget } from '@app/business/prsna/prsna-desktop/prsna-widgets/widget.model';
import { DbQueryService } from '@app/_services';

@Component({
  selector: 'app-number-people-current-month',
  templateUrl: './number-people-current-month.component.html',
  styleUrls: ['./number-people-current-month.component.less']
})
export class NumberPeopleCurrentMonthComponent implements OnInit {

  @Input() widget: PrsnaWidget;
  @Input() userId: number;
  @Input() userInfo: any;
  data: any[] = [];

  private chart: am4charts.PieChart;

  constructor(
    @Inject(PLATFORM_ID) private platformId, 
    private zone: NgZone,
    private dbQueryService: DbQueryService
  ) { }

  ngOnInit(): void {
  }

  // Run the function only in the browser
  browserOnly(f: () => void) {
    if (isPlatformBrowser(this.platformId)) {
      this.zone.runOutsideAngular(() => {
        f();
      });
    }
  }

  ngAfterViewInit () {
    setTimeout(() => {
      this.bind();
    });
  }

  bind() {
    this.dbQueryService.getQuerySelect('hre_people_numbers', "", 1000)
      .subscribe(res => {
        if (res.items) {
          this.data = res.items;
          this.drawChart();
        }
      })
  }

  drawChart() {
    // Chart code goes in here
    this.browserOnly(() => {
      am4core.useTheme(am4themes_animated);

      // Create chart instance
      let chart = am4core.create("hre-pieChart-" + this.widget.id, am4charts.PieChart);
      chart.data = this.data;

      // Add and configure Series
      let pieSeries = chart.series.push(new am4charts.PieSeries());
      pieSeries.dataFields.value = "value";
      pieSeries.dataFields.category = "title";
      pieSeries.slices.template.strokeWidth = 1;
      pieSeries.slices.template.stroke = am4core.color("#fff");

      // pieSeries.labels.template.disabled = true;
      pieSeries.labels.template.maxWidth = 200;
      pieSeries.labels.template.text = "{title.} {percent}%";
      pieSeries.labels.template.truncate = true;
      // pieSeries.ticks.template.disabled = true;

      // Add a legend
      chart.legend = new am4charts.Legend();
      chart.legend.labels.template.text = "{title}";
      chart.legend.valueLabels.template.text = "";
      chart.legend.maxHeight = 150;
      chart.legend.scrollable = true;
      chart.legend.position = "bottom";

      this.chart = chart;
    });
  }

  ngOnDestroy() {
    // Clean up chart when the component is removed
    this.browserOnly(() => {
      if (this.chart) {
        this.chart.dispose();
      }
    });
  }
}

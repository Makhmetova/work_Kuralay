import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NumberPeopleCurrentMonthComponent } from './number-people-current-month.component';

describe('NumberPeopleCurrentMonthComponent', () => {
  let component: NumberPeopleCurrentMonthComponent;
  let fixture: ComponentFixture<NumberPeopleCurrentMonthComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NumberPeopleCurrentMonthComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NumberPeopleCurrentMonthComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, ComponentFactoryResolver, Input, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { PrsnaWidget, PrsnaWidgetForm } from '@app/business/prsna/prsna-desktop/prsna-widgets/widget.model';
import { WidgetWrapperComponent } from '@app/business/prsna/prsna-employee-card/widget-wrapper/widget-wrapper.component';
import { QueryOptions, UserInfo } from '@app/_models';
import { COMMANDS_SUB } from '@app/_models/commands';
import { AccountService, DbQueryService } from '@app/_services';
import { MainService } from '@app/_services/main.service';
import { Subscription } from 'rxjs';
import { filter } from 'rxjs/operators';

@Component({
  selector: 'app-hre-widgets',
  templateUrl: './hre-widgets.component.html',
  styleUrls: ['./hre-widgets.component.less']
})
export class HreWidgetsComponent implements OnInit {

  @ViewChild('widgetTemplate', {read: ViewContainerRef}) widgetTemplate: ViewContainerRef;
  entity_widgets = "hre_widgets";

  @Input() dashboard: any;

  userInfo: UserInfo;
  widgets = [];
  widgetsSelect: {id: number; code: string; title: string; img: string; component_name: string; widget_cols: number; widget_rows: number;}[] = [];
  componentWrappers = [];
  
  widgetForm: PrsnaWidgetForm;

  displayModal: boolean;
  commandSub: Subscription;
  userValueSub: Subscription;

  constructor(
    private dbQueryService: DbQueryService,
    private accountService: AccountService,
    private _componentFactoryResolver: ComponentFactoryResolver,
    private mainService: MainService
  ) { }

  ngOnInit(): void {
    this.newWidgetForm();

    this.widgetsSelect = [
      { id: 1, code: "linear_diagram", title: "Линейная диаграмма", img: "./assets/icons/prsna/linear-chart.svg", component_name: 'WidgetMonthAchievementsComponent', widget_cols: 6, widget_rows: 1 },
      { id: 2, code: "bar_chart", title: "Гистограмма", img: "./assets/icons/prsna/histogram.svg", component_name: 'WidgetDynamicBarchartComponent', widget_cols: 6, widget_rows: 1},
      { id: 3, code: "pie_chart", title: "Круговая диаграмма", img: "./assets/icons/prsna/pie-chart.svg", component_name: 'WidgetInworkDynamicComponent', widget_cols: 3, widget_rows: 1 },
      { id: 4, code: "progress_chart", title: "Прогресс %", img: "./assets/icons/prsna/progress-chart.svg", component_name: 'WidgetDynamicProgressbarComponent', widget_cols: 3, widget_rows: 1 },
      { id: 5, code: "top_chart", title: "Топ 3 задачи", img: "./assets/icons/prsna/top-tasks.svg", component_name: 'WidgetDynamicToptasksComponent', widget_cols: 3, widget_rows: 1 },
      { id: 6, code: "numerical_chart", title: "Числовой", img: "./assets/icons/prsna/numerical-chart.svg", component_name: 'WidgetDynamicNumericalchartComponent', widget_cols: 3, widget_rows: 1 }
    ];

  }

  newWidgetForm() {
    this.widgetForm = {
      title: null,
      chart_code: null,
      nn: null,
      options: {
        due_time: null,
        query_code: null,
        fields: []
      }
    }
  }

  ngAfterViewInit () {
    const user = this.accountService.userValue;
    this.userValueSub = this.accountService.getById(user.sessioninfo.id)
      .subscribe(user => {
        if(user.users) {
          this.userInfo = user.users[0];
          this.bindWidgets();
        }
      });

    this.commandSub = this.mainService.commandSub
      .pipe(
        filter(cmd => cmd.cmd === COMMANDS_SUB.WIDGET_DELETE && this.dashboard.id === cmd.data.dashboard_id)
      ).subscribe( (res) => {
        this.removeComponent(res.data);
        // console.log("Dashboard: ", this.dashboard);
        // console.log("Widget delete: ", res);
      });
  }

  bindWidgets() {
    let options = new QueryOptions(this.entity_widgets);
    // options.flteq = {
    //   // created_by: user.id,
    //   dashboard_id: this.dashboard.id
    // }
    options.orderBy = 'nn';
    options.orderAsc = 1;

    this.dbQueryService.getQuery(options)
      .subscribe( (resp) => {
        if (resp && resp.items) {
          this.widgets = resp.items;
          let wrappersCount = this.componentWrappers.length;
          this.widgets.forEach((w, i) => {
            // console.log("Each widgets: ", w);
            if (i >= wrappersCount) {
              wrappersCount = this.loadWidgetComponents(w);
            }
          })
        }
      });
  }

  loadWidgetComponents(widget: PrsnaWidget) {
    // instantiate the component
    let componentFactory = this._componentFactoryResolver.resolveComponentFactory(WidgetWrapperComponent);

    let componentRef = this.widgetTemplate.createComponent(componentFactory);
    let instance = componentRef.instance;
    // set the props
    instance.widget = widget;
    instance.userInfo = this.userInfo;
    instance.dropdownMoreVisible = this.dashboard.is_common !== '1';

    // getting the component's HTML
    let element: HTMLElement = <HTMLElement>componentRef.location.nativeElement;

    // adding styles
    element.classList.add('col-md-'+widget.widget_cols);
    element.classList.add('col-sm-12');
    element.classList.add('p-mt-3');

    return this.componentWrappers.push(componentRef);
  }

  showModalDialog() {
    this.newWidgetForm();
    this.displayModal = true;
    this.widgetForm.nn = this.widgets.length + 1;
  }

  saveWidget() {
    let values: PrsnaWidget[] = [];
    let widgetSelected = this.widgetsSelect.find(w => w.code == this.widgetForm.chart_code);
    values.push({
      id: 0,
      component_name: widgetSelected.component_name,
      dashboard_id: this.dashboard.id,
      title: this.widgetForm.title,
      widget_cols: widgetSelected.widget_cols,
      widget_rows: widgetSelected.widget_rows,
      options: JSON.stringify(this.widgetForm.options),
      nn: this.widgetForm.nn
    });

    // console.log("Dashboard: ", this.dashboard);
    // console.log("Widget form: ", values);
    this.dbQueryService.insertTable(this.entity_widgets, values)
      .subscribe((resp) => {
        this.mainService.toastSuccess("Виджет успешно добавлено!");
        // console.log("Saved widget: ", resp);
        this.bindWidgets();
      });
    this.displayModal = false;
  }


  removeComponent(data: PrsnaWidget) {
    // Find the component
    const component = this.componentWrappers.find((component) => component.instance.widget.id == data.id);
    const componentIndex = this.componentWrappers.indexOf(component);

    if (componentIndex !== -1) {
      this.dbQueryService.deleteTable(this.entity_widgets, data.id)
        .subscribe( (resp) => {
          this.mainService.toastSuccess("Виджет успешно удален!");
          // console.log("Widget Deleted: ", resp);
          // Remove component from both view and array
          this.widgetTemplate.remove(componentIndex);
          this.componentWrappers.splice(componentIndex, 1);
        });
    }
  }

  cancel() {
    this.displayModal = false;
  }

  widgetOnChange() {
    
  }

  ngOnDestroy() {
    this.commandSub.unsubscribe();
    this.userValueSub.unsubscribe();
  }


}

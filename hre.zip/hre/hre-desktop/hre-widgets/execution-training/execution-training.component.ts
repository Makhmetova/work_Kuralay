import { Component, Input, OnInit } from '@angular/core';
import { PrsnaWidget } from '@app/business/prsna/prsna-desktop/prsna-widgets/widget.model';

@Component({
  selector: 'app-execution-training',
  templateUrl: './execution-training.component.html',
  styleUrls: ['./execution-training.component.less']
})
export class ExecutionTrainingComponent implements OnInit {

  @Input() widget: PrsnaWidget;
  @Input() userId: number;
  @Input() userInfo: any;
  data: any[] = [];
  
  constructor() { }

  ngOnInit(): void {
  }

}

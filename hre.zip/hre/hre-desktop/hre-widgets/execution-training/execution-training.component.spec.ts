import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ExecutionTrainingComponent } from './execution-training.component';

describe('ExecutionTrainingComponent', () => {
  let component: ExecutionTrainingComponent;
  let fixture: ComponentFixture<ExecutionTrainingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ExecutionTrainingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ExecutionTrainingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

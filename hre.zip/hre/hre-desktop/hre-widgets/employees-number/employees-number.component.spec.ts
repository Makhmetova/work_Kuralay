import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeesNumberComponent } from './employees-number.component';

describe('EmployeesNumberComponent', () => {
  let component: EmployeesNumberComponent;
  let fixture: ComponentFixture<EmployeesNumberComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EmployeesNumberComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeesNumberComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

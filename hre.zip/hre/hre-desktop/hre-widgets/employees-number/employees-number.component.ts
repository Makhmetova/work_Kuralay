import { Component, Input, OnInit } from '@angular/core';
import { PrsnaWidget } from '@app/business/prsna/prsna-desktop/prsna-widgets/widget.model';

@Component({
  selector: 'app-employees-number',
  templateUrl: './employees-number.component.html',
  styleUrls: ['./employees-number.component.less']
})
export class EmployeesNumberComponent implements OnInit {

  @Input() widget: PrsnaWidget;
  @Input() userId: number;
  @Input() userInfo: any;
  data: any[] = [];
  
  constructor() { }

  ngOnInit(): void {
  }

}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DaysAnnualVacationComponent } from './days-annual-vacation.component';

describe('DaysAnnualVacationComponent', () => {
  let component: DaysAnnualVacationComponent;
  let fixture: ComponentFixture<DaysAnnualVacationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DaysAnnualVacationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DaysAnnualVacationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

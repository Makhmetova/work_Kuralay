import { isPlatformBrowser } from '@angular/common';
import { Component, Inject, Input, NgZone, OnInit, PLATFORM_ID } from '@angular/core';
import { PrsnaWidget } from '@app/business/prsna/prsna-desktop/prsna-widgets/widget.model';
import { DbQueryService } from '@app/_services';

// amCharts imports
import * as am4core from '@amcharts/amcharts4/core';
import * as am4charts from '@amcharts/amcharts4/charts';
import am4themes_animated from '@amcharts/amcharts4/themes/animated';


@Component({
  selector: 'app-days-annual-vacation',
  templateUrl: './days-annual-vacation.component.html',
  styleUrls: ['./days-annual-vacation.component.less']
})
export class DaysAnnualVacationComponent implements OnInit {

  @Input() widget: PrsnaWidget;
  @Input() userId: number;
  @Input() userInfo: any;
  data: any[] = [];

  private chart: am4charts.XYChart;

  constructor(
    @Inject(PLATFORM_ID) private platformId, 
    private zone: NgZone,
    private dbQueryService: DbQueryService
  ) { }

  ngOnInit(): void {
  }

  // Run the function only in the browser
  browserOnly(f: () => void) {
    if (isPlatformBrowser(this.platformId)) {
      this.zone.runOutsideAngular(() => {
        f();
      });
    }
  }

  ngAfterViewInit () {
    setTimeout(() => {
      this.bind();
    });
  }

  bind() {
    this.dbQueryService.getQuerySelect('hre_vacation_days', "", 1000)
      .subscribe(res => {
        if (res.items) {
          this.data = res.items;
          this.drawChart();
        }
      })
  }

  drawChart() {
    // Chart code goes in here
    this.browserOnly(() => {
      am4core.useTheme(am4themes_animated);

      // Create chart instance
      let chart = am4core.create("hre-xychart-" + this.widget.id, am4charts.XYChart);
      chart.data = this.data;

      // Create axes
      let categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
      categoryAxis.dataFields.category = "title";
      let label = categoryAxis.renderer.labels.template;
      label.wrap = true;
      label.maxWidth = 120;
      // categoryAxis.title.text = "Local country offices";
      // categoryAxis.renderer.grid.template.location = 0;
      // categoryAxis.renderer.minGridDistance = 20;


      let valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
      // valueAxis.title.text = "Expenditure (M)";

      // Create series
      let series = chart.series.push(new am4charts.ColumnSeries());
      series.dataFields.valueY = "plan_total";
      series.dataFields.categoryX = "title";
      series.name = "План на год";
      series.tooltipText = "{name}: [bold]{valueY}[/]";
      // series.stacked = true;

      let series2 = chart.series.push(new am4charts.ColumnSeries());
      series2.dataFields.valueY = "plan_month";
      series2.dataFields.categoryX = "title";
      series2.name = "План на текущую дату";
      series2.tooltipText = "{name}: [bold]{valueY}[/]";
      // series2.stacked = true;

      let series3 = chart.series.push(new am4charts.ColumnSeries());
      series3.dataFields.valueY = "fact_month";
      series3.dataFields.categoryX = "title";
      series3.name = "Факт на текущую дату";
      series3.tooltipText = "{name}: [bold]{valueY}[/]";
      //series3.stacked = true;

      // Add cursor
      chart.cursor = new am4charts.XYCursor();
      // Add legend
      chart.legend = new am4charts.Legend();
      chart.legend.position = "top";

      this.chart = chart;
    });
  }

  ngOnDestroy() {
    // Clean up chart when the component is removed
    this.browserOnly(() => {
      if (this.chart) {
        this.chart.dispose();
      }
    });
  }

}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HreWidgetsComponent } from './hre-widgets.component';

describe('HreWidgetsComponent', () => {
  let component: HreWidgetsComponent;
  let fixture: ComponentFixture<HreWidgetsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HreWidgetsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HreWidgetsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DbQueryService } from '@app/_services';

@Component({
  selector: 'app-hre-desktop',
  templateUrl: './hre-desktop.component.html',
  styleUrls: ['./hre-desktop.component.less']
})
export class HreDesktopComponent implements OnInit {

  entity_dashboards = "hre_dashboards";

  dashboards = [];
  activeDashboardIndex: number = 0;
  formDashboard: FormGroup;

  displayModal: boolean;

  
  constructor(
    private dbQueryService: DbQueryService,
    private formBuilder: FormBuilder,
  ) { }


  ngOnInit(): void {
    
    this.formDashboard = this.formBuilder.group({
      title: ['', Validators.required]
    });

  }
     

  ngAfterViewInit () {
    this.bindDashboards();
  }
  
  bindDashboards() {
    this.dashboards.push({id: 1, title: "Дэшборд 1", is_common: '1' });
    // let query = this.dbQueryService.getQuerySelect('prsna_my_dashboards', '', 10)
    //   .subscribe( (resp) => {
    //     if (resp && resp.items) {
    //       this.dashboards = resp.items;
    //     }
    //     query.unsubscribe();
    //   });
  }


  // saveDashboard() {
  //   // console.log("Form Dashboards: ", this.formDashboard);
  //   let query = this.dbQueryService.insertTable(this.entity_dashboards, [this.formDashboard.value])
  //     .subscribe( (resp) => {
  //       this.bindDashboards();
  //       query.unsubscribe();
  //     });
  //   this.displayModal = false;
  // }

  // deleteDashboard(event: any) {
  //   event.close();
  //   let query = this.dbQueryService.deleteTable(this.entity_dashboards, this.dashboards[event.index].id)
  //     .subscribe( res => {
  //       this.mainService.toastSuccess("Дэшбоард успешно удалено!");
  //       query.unsubscribe();
  //     });
  // }

  // cancel() {
  //   this.displayModal = false;
  // }

  // showModalDialog() {
  //   this.displayModal = true;
  // }


  ngOnDestroy() {
  }


}

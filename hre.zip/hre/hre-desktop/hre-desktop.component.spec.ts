import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HreDesktopComponent } from './hre-desktop.component';

describe('HreDesktopComponent', () => {
  let component: HreDesktopComponent;
  let fixture: ComponentFixture<HreDesktopComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HreDesktopComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HreDesktopComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

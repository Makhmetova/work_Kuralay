
export const HRE_APPLICATIONS = {
    VACATION: 'hre_vacation_new',
    BUSINESS_TRIP: 'hre_busines_trip'
}

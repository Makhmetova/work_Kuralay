import {
  Component,
  ComponentRef,
  Input,
  OnInit,
  ViewChild,
  ViewContainerRef,
} from '@angular/core';
import { AppComponent, MenuItem } from '@app/app.component';
import { QueryOptions } from '@app/_models';
import { AccountService, DbQueryService } from '@app/_services';
import { MainService } from '@app/_services/main.service';
import { take } from 'rxjs/operators';
import { EventEmitter } from 'events';
import { PureDetailFormComponent } from '@app/_components/PureDetailForm/pureDetailForm.component';
import { IFormOptions } from '@app/_models/common';
import { ComponentPoolService } from '@app/_services/componentPool.service';
import { BuilderSerice } from '@app/_services/builder.service';
import { InitiatorInfoComponent } from '../../applications/initiator-info/initiator-info.component';
import { StepInfoComponent } from '../../applications/step-info/step-info.component';
import { PureInfoBlockComponent } from '@app/_components/PureInfoBlock/pureInfoBlock.component';
import { IdeaTimelineComponent } from '../../applications/hre-idea-center/idea-timeline/idea-timeline.component';

@Component({
  selector: 'app-catalog-services',
  templateUrl: './catalog-services.component.html',
  styleUrls: ['./catalog-services.component.less'],
})
export class CatalogServicesComponent implements OnInit {
  display: boolean;
  dispatcher: EventEmitter;
  detailIsOpen: boolean;
  menu_services: MenuItem;
  services: any[] = [];
  @ViewChild('detailFormHolder', { read: ViewContainerRef })
  detailFormHolder: ViewContainerRef;
  id: number;
  user: Object;
  temp_id:any;
  saved_id:any;
  infoBlockParams = {};
  verticalInfoBlock: boolean = true;
  approveOptions;
  filesOptions;
  requestFormOptions;
  constructor(
    private network: DbQueryService,
    private mainService: MainService,
    private account: AccountService,
    private pool: ComponentPoolService,
    private factory: BuilderSerice
  ) {
    this.dispatcher = new EventEmitter();
    this.detailIsOpen = false;
    this.id = 0;
    this.verticalInfoBlock = true;
  }

  ngOnInit(): void {
    this.menu_services = AppComponent.menuItems
      .find((m) => m.url == '/hre')
      .childs.find((ch) => ch.url == '#/hre/services');
    this.account
      .getSession()
      .pipe(take(1))
      .subscribe((u) => {
        let us = u.sessioninfo;
        this.network
          .executeQuery(`code=users&flt$id$eq$=${us.id}`, 'get')
          .pipe(take(1))
          .subscribe((res) => {
            this.user = res.items[0];
          });
      });
  }

  ngAfterViewInit() {
    this.bind(this.menu_services.id);
    let zis = this;
    let modalOpenFunc = (data) => {
      console.log('GGGGGGG');
      let parent_lookup = 14;
      zis.detailIsOpen = true;
      zis.detailFormHolder.clear();
      console.log('openDetail', data);
      let req_code = data['quicklink_code'];
      // if(req_code != 'hre_idea_center'){
        this.verticalInfoBlock = true;
        if (req_code == 'hre_ref_work') {
          // this.verticalInfoBlock = false;
          parent_lookup = 19;
        }else if (req_code == 'hre_idea_center') {
          // this.verticalInfoBlock = false;
          parent_lookup = 21;
        }
        let FilesSelectQueryOptions = new QueryOptions('hre_req_files');
        FilesSelectQueryOptions.flteq = {
          req_id: data['id'],
        };

        let timelineQueryOptions = new QueryOptions('req_statuses_lookups_step');
        timelineQueryOptions.flteq = {
          parent_lookup: 14,
        };
        let _comp = zis.pool.getComponentsType(
          'tables',
          data['quicklink_code'],
          true
        );
        console.log('Component', _comp);
        if (req_code == "hre_idea_center") {
          this.approveOptions =  {
            templateId:this.temp_id,
            showButtons: true,
            showApproveButtons: true,
            useUsersFilter: true,
            useDefaultPreSettings: true
          };
          this.filesOptions = {
            multiple: true,
            tableToSave: `${'hre_idea_center'}_files`,
            fieldForLink: `${'hre_idea_center'}_id`,
            saveHistory: true
          };
          this.requestFormOptions = {
            onSaveUpdateInfoBlock: true,
            onSaveUpdateTimeline: true,
            onSaveReloadApprove:true
          }
        } else {
          this.approveOptions = {
            showButtons: true,
            showApproveButtons: true,
            useUsersFilter: true,
            useDefaultPreSettings: true,
            templateId: 72,
          }
          this.filesOptions = {
            multiple: true,
            tableToSave: 'hre_req_files',
            FilesSelectQueryOptions: FilesSelectQueryOptions,
            fieldForLink: 'req_id',
            saveHistory: true,
          }
          this.requestFormOptions = {
            onSaveUpdateInfoBlock: true
          }
        }
        let FormOptions: IFormOptions = {
          showApproveForm: true,
          showCommentsForm: true,
          showFilesForm: true,
          showHistoryForm: true,
          showTimeline: true,
          showOrdersForm: false,
          showInfoBlock: true,
          formComponent: _comp,
          mainFormOptions: {},
          formComponentParams: {
            detailId: 0,
            user: zis.user,
            entity_code: data['quicklink_code'],
            isSender:true,
            id: 0,
            cur_user_get:this.user
          },
          requestFormOptions:  this.requestFormOptions,

          approveOptions: this.approveOptions,
          filesOptions: this.filesOptions,
          infoBlockOptions: {
            verticalInfoBlock: this.verticalInfoBlock,
            InfoBlockComponent: PureInfoBlockComponent,
            InfoBlockParams: this.infoBlockParams,
            InfoBlockCustomParams : {
              showCancelButton : false,
              showEndingButton : false,
              showReassignationButton : false,
              showTakeButton : false,
              disableGroup : true,
              disableStatus : true,
              disablePriority : true,
              disableExecutor : true,
              disableParent : true
          }
          },
          timelineOptions: {
            useCustomTimeline: true,
            customTimelineComponent: StepInfoComponent,
            defaultTimelineOptions: {
              statusesLookupQuery: timelineQueryOptions,
            },
          },
        };
        console.log('Form done', FormOptions);

        let compRef: ComponentRef<any>;
        compRef = zis.factory.MountComponent(
          zis.detailFormHolder,
          PureDetailFormComponent,
          {
            FormOptions: FormOptions,
            table_name: data['quicklink_code'],
            id: 0,
            user: zis.user,
            title: '',
          }
        );
        compRef.instance.onClose.subscribe((val) => {
          zis.detailFormHolder.clear();
          zis.detailIsOpen = false;
        });
      // }else{
      //   // let entityQuery = new QueryOptions('entities')
      //   // entityQuery.flteq = {
      //   //     code : req_code
      //   // }
      //   // let queryOpts = new QueryOptions(req_code)
      //   // queryOpts.flteq = {
      //   //     id : (this.temp_id)?this.saved_id:0
      //   // }
      //   let timelineQueryOptions = new QueryOptions(
      //     'req_statuses_lookups_step'
      //   );
      //   timelineQueryOptions.flteq = {
      //     parent_lookup: 21,
      //   };
      //   let _comp = zis.pool.getComponentsType(
      //     'tables',
      //     data['quicklink_code'],
      //     true
      //   );
      //   let options: IFormOptions = {
      //     showApproveForm: true,
      //     showCommentsForm: true,
      //     showFilesForm: true,
      //     showHistoryForm: true,
      //     showTimeline: true,
      //     showOrdersForm: false,
      //     showInfoBlock: true,
      //     formComponent: _comp,
      //     infoBlockOptions : {
      //       verticalInfoBlock : true,
      //       InfoBlockComponent : PureInfoBlockComponent,
      //       InfoBlockParams : {},
      //       InfoBlockCustomParams : {
      //         showCancelButton : false,
      //         showEndingButton : false,
      //         showReassignationButton : false,
      //         showTakeButton : false,
      //         disableGroup : true,
      //         disableStatus : true,
      //         disablePriority : true,
      //         disableExecutor : true,
      //         disableParent : true
      //     }
      //     },
      //     timelineOptions: {
      //       useCustomTimeline: true,
      //       customTimelineComponent: IdeaTimelineComponent,
      //       customTimelineOptions: {

      //       },
      //       defaultTimelineOptions: {
      //         statusesLookupQuery: timelineQueryOptions,
      //       },
      //     },
      //     requestFormOptions: {
      //       onSaveUpdateInfoBlock: true,
      //       onSaveUpdateTimeline:true,
      //       onSaveReloadApprove:true
      //     },
      //     formComponentParams: {
      //       entity_code:'hre_idea_center',
      //       id: 0,
      //       isSender:true,
      //       status_ice:0,
      //       cur_user_get:this.user,
      //       approveId:0
      //     },
      //     mainFormOptions: {
      //       title: 'Добавление новой идеи',
      //       // formStyle: {
      //       //   "margin-top": "0rem"
      //       // },
      //       // mainCardStyle:{
      //       //       "width":"75%",
      //       //       "margin-left":"1.5rem"
      //       //     },
      //       // formStyleClass: ['p-4']
      //     },

      //   }
      //   let compRef: ComponentRef<any>
      //   // let user = this.users.find(x => x['id'] == this.user['id'])
      //   compRef = this.factory.MountComponent(this.detailFormHolder, PureDetailFormComponent, {
      //     FormOptions: options,
      //     table_name: 'hre_idea_center',
      //     code: 'hre_idea_center',
      //     id: (this.temp_id)?this.saved_id:0,
      //     user: this.user,
      //     sender:true

      //   })
      //   compRef.instance.onClose.subscribe(val => {

      //     this.detailFormHolder.clear();
      //     this.detailIsOpen = false;

      //   })
        compRef.instance.onSave.subscribe(val => {

          this.temp_id=+val.tempId;
          this.saved_id=+val.reqId;
          compRef.instance.FormOptions.approveOptions.templateId=+val.data.approve_id
          compRef.instance.id=val.id;
        })
      }



    let modalCloseFunc = function (data) {
      zis.display = false;
      zis.detailFormHolder.clear();
    };
    this.dispatcher.on('open', modalOpenFunc);
    this.dispatcher.on('close', modalCloseFunc);

    let goBack = function (data) {
      zis.detailFormHolder.clear();
      zis.detailIsOpen = false;
    };

    let openOrder = function (data) {
      zis.detailFormHolder.clear();
      zis.detailIsOpen = false;
      zis.detailIsOpen = true;
      zis.factory.MountComponent(zis.detailFormHolder, data.component, {
        parentEmitter: data.parentEmitter,
        req_id: data.id,
        req_code: data['quicklink_code'],
      });
    };
    zis.dispatcher.on('goback', goBack);
    zis.dispatcher.on('openOrder', openOrder);
  }

  bind(parent_id?: number) {
    let options = new QueryOptions('angular_menu');
    options.flteq = {
      parent_id: parent_id,
    };

    this.network.getQuery(options).subscribe((res) => {
      if (res.items) {
        this.services = res.items;
      }
    });
  }
}
@Component({
  selector: 'hre-services',
  templateUrl: './services.html',
  styleUrls: ['./catalog-services.component.less'],
})
export class Services {
  @Input() requests?: Array<any>;
  @Input() title?: string;
  @Input() params?: Object;
  @Input() services: Object;
  @Input() parentEmitter: EventEmitter;
  constructor() {}
  openModal(req) {
    //console.log('click', req);
    this.parentEmitter.emit('open', req);
  }
}

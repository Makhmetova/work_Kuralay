import { Component, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { BuilderSerice } from '@app/_services/builder.service';
import { CatalogServicesComponent } from './catalog-services/catalog-services.component';
import { IncomingComponent } from './incoming/incoming.component';
import { OutcomingComponent } from './outcoming/outcoming.component';

@Component({
  selector: 'app-hre-catalog',
  templateUrl: './hre-catalog.component.html',
  styleUrls: ['./hre-catalog.component.less'],
})
export class HreCatalogComponent implements OnInit {
  @ViewChild('hrIncoming', { read: ViewContainerRef })
  hrIncoming: ViewContainerRef;
  @ViewChild('hrOutcoming', { read: ViewContainerRef })
  hrOutcoming: ViewContainerRef;
  @ViewChild('catalog', { read: ViewContainerRef })
  catalog: ViewContainerRef;
  currentPage = 'main';

  constructor(private factory: BuilderSerice) {}

  ngOnInit(): void {
  }
  ngAfterViewInit(){
   // this.factory.MountComponent(this.catalog, CatalogServicesComponent, {});

  }
  clearIncomeContainer() {
   // this.catalog.clear();
    this.hrIncoming.clear();
    this.factory.MountComponent(this.hrIncoming, IncomingComponent, {});
  }
  clearOutcomeContainer() {
     this.hrOutcoming.clear();
     this.factory.MountComponent(this.hrOutcoming, OutcomingComponent, {
      detailIsOpen: false
     });

   }
}

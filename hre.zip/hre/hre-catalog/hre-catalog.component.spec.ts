import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HreCatalogComponent } from './hre-catalog.component';

describe('HreCatalogComponent', () => {
  let component: HreCatalogComponent;
  let fixture: ComponentFixture<HreCatalogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HreCatalogComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HreCatalogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

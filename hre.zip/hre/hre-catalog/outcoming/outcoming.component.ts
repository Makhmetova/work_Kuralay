import {
  Component,
  ComponentRef,
  EventEmitter,
  Input,
  OnInit,
  Output,
  ViewChild,
  ViewContainerRef,
} from '@angular/core';
import { BuilderSerice } from '@app/_services/builder.service';
import { HreRefWorkComponent } from '../../applications/hre-ref-work/hre-ref-work.component';

import { AccountService, DbQueryService, MainService } from '@app/_services';
import { ComponentPoolService } from '@app/_services/componentPool.service';
import { take, takeUntil } from 'rxjs/operators';
import { InfoBlockCmtComponent } from '@app/business/cmt/components/InfoBlockCmt/InfoBlockCmt.component';
import { StatusCmtComponent } from '@app/business/cmt/components/StatusCmt/StatusCmt.component';
import { PureDetailFormComponent } from '@app/_components/PureDetailForm/pureDetailForm.component';
import { QueryOptions } from '@app/_models';
import { IFormOptions } from '@app/_models/common';
import { InitiatorInfoComponent } from '../../applications/initiator-info/initiator-info.component';
import { StepInfoComponent } from '../../applications/step-info/step-info.component';
import { PureInfoBlockComponent } from '@app/_components/PureInfoBlock/pureInfoBlock.component';

@Component({
  selector: 'app-outcoming',
  templateUrl: './outcoming.component.html',
  styleUrls: ['./outcoming.component.less'],
})
export class OutcomingComponent implements OnInit {
  entity_code: string = 'hre_outbox';
  @Input() detailIsOpen: boolean;
  @ViewChild('detailFormHolder', { read: ViewContainerRef })
  detailFormHolder: ViewContainerRef;

  display: boolean;
  id: number;
  user: Object;
  infoUser: Object;
  showOrdersForm: boolean;
  infoBlockParams = {};
  verticalInfoBlock: boolean = true;
  temp_id:any;
  saved_id:any;
  approveOptions;
  filesOptions;
  requestFormOptions;
  constructor(
    private factory: BuilderSerice,
    private network: DbQueryService,
    private account: AccountService,
    private pool: ComponentPoolService
  ) {
    this.detailIsOpen = false;
    this.showOrdersForm = false;
  }

  ngOnInit(): void {
    console.log("Detail is open", this.detailIsOpen)
    this.account
      .getSession()
      .pipe(take(1))
      .subscribe((u) => {
        let us = u.sessioninfo;
        this.network
          .executeQuery(`code=users&flt$id$eq$=${us.id}`, 'get')
          .pipe(take(1))
          .subscribe((res) => {
            this.user = res.items[0];
          });
      });
  }
  ngAfterViewInit() {}
  openDetail(data) {

    console.log("Detail is open", this.detailIsOpen)
//data['title'] + '_requests';
    let tableForOrders: string = data['title'] + '_orders';
    let tableForRequests: string = data['title'] + '_requests';
    let tableForFiles: string = data['title'] + '_files';
    let linkField = data['title'] + '_id';
    // this.network
    //   .executeQuery(`code=users&flt$id$eq$=${data.created_by}`, 'get')
    //   .pipe(take(1))
    //   .subscribe((res) => {
    //     this.infoUser = res.items[0];
    //   });
    this.network
      .getDetail(data['title'], data['detail_id'])
      .subscribe((det) => {
        let detail = det[data['title']][0];
        this.detailFormHolder.clear();
        this.detailIsOpen = true;
        console.log('Out', data);

        if (data['application_type_id'] == 1) {
          this.showOrdersForm = true;
        } else if (data['application_type_id'] == 4) {
            // this.verticalInfoBlock = false;
        }
        let FilesSelectQueryOptions = new QueryOptions(tableForFiles);
        FilesSelectQueryOptions.flteq = {
          [linkField]: data['detail_id'],
        };
        let timelineQueryOptions = new QueryOptions(
          'req_statuses_lookups_step'
        );
        timelineQueryOptions.flteq = {
          parent_lookup: 14,
        };
        let ordersOptions = new QueryOptions(tableForOrders);
        ordersOptions.flteq = {
          entity_pk: data['detail_id'],
        };
        let requestOptions = new QueryOptions(tableForRequests);
        requestOptions.flteq = {
          entity_pk: data['detail_id'],
        };
        let req_code = data['title'];
        if (req_code == "hre_idea_center") {
          this.approveOptions =  {
            templateId:this.temp_id,
            showButtons: true,
            showApproveButtons: true,
            useUsersFilter: true,
            useDefaultPreSettings: true
          };
          this.filesOptions = {
            multiple: true,
            tableToSave: `${'hre_idea_center'}_files`,
            fieldForLink: `${'hre_idea_center'}_id`,
            saveHistory: true
          };
          this.requestFormOptions = {
            onSaveUpdateInfoBlock: true,
            onSaveUpdateTimeline: true,
            onSaveReloadApprove:true
          }
        } else {
          this.approveOptions = {
            showButtons: true,
            showApproveButtons: true,
            useUsersFilter: true,
            useDefaultPreSettings: true,
            templateId: 72,
          }
          this.filesOptions = {
            multiple: true,
            tableToSave: 'hre_req_files',
            FilesSelectQueryOptions: FilesSelectQueryOptions,
            fieldForLink: 'req_id',
            saveHistory: true,
          };
          this.requestFormOptions = {
            onSaveUpdateInfoBlock: true
          }
        }

        let _comp = this.pool.getComponentsType('tables', data['title'], true);
        let FormOptions: IFormOptions = {
          showApproveForm: true,
          showCommentsForm: true,
          showFilesForm: true,
          showHistoryForm: true,
          showTimeline: true,
          showOrdersForm: true,
          showInfoBlock: true,
          formComponent: _comp,
          mainFormOptions: {},
          formComponentParams: {
            detailId: data['detail_id'],
            user: this.user,
            isSender:true,
            id: data['id'],
            cur_user_get:this.user,
            entity_code: req_code
          },
          approveOptions: this.approveOptions,
          requestFormOptions: this.requestFormOptions,
          filesOptions: this.filesOptions,

          ordersOptions: {
            tableForRequests: tableForOrders,
            tableForOrders: tableForRequests,
            ordersOptions: requestOptions,
            requestsOptions: requestOptions,
            useRest: true,
            requestsLinkField: 'entity_pk',
            ordersLinkField: 'entity_pk'

          },
          infoBlockOptions: {
            verticalInfoBlock: this.verticalInfoBlock,
            InfoBlockComponent : PureInfoBlockComponent,
            InfoBlockParams : this.infoBlockParams,
            InfoBlockCustomParams : {
              showCancelButton : false,
              showEndingButton : false,
              showReassignationButton : false,
              showTakeButton : false,
              disableGroup : true,
              disableStatus : true,
              disablePriority : true,
              disableExecutor : true,
              disableParent : true
          }
          },
          timelineOptions: {
            useCustomTimeline: true,
            customTimelineComponent: StepInfoComponent,
            customTimelineOptions: {
              inputParams: {
                detail: detail,
              },
            },
            defaultTimelineOptions: {
              statusesLookupQuery: timelineQueryOptions,
            },
          },
        };
        console.log('Form done', FormOptions);

        let compRef: ComponentRef<any>;
        compRef = this.factory.MountComponent(
          this.detailFormHolder,
          PureDetailFormComponent,
          {
            FormOptions: FormOptions,
            table_name: data['title'],
            id: data['detail_id'],
            user: this.user,
            title: '',
          }
        );
        compRef.instance.onClose.subscribe((val) => {
          this.detailFormHolder.clear();
          this.detailIsOpen = false;
        });

        compRef.instance.onSave.subscribe(val => {

          this.temp_id=+val.tempId;
          this.saved_id=+val.reqId;
          compRef.instance.FormOptions.approveOptions.templateId=+val.data.approve_id
          compRef.instance.id=val.id;
        })
      });
  }
}

import { AllApplicationsComponent } from './all-applications/all-applications.component';
import { TreatmentsComponent } from './treatments/treatments.component';
import { Component, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { BuilderSerice } from '@app/_services/builder.service';
import { AllRequestsComponent } from './all-requests/all-requests.component';

@Component({
  selector: 'app-hre-management',
  templateUrl: './hre-management.component.html',
  styleUrls: ['./hre-management.component.less'],
})
export class HreManagementComponent implements OnInit {
  @ViewChild('allTreatments', { read: ViewContainerRef })
  allTreatments: ViewContainerRef;
  @ViewChild('allTreatments', { read: ViewContainerRef })
  allApplic: ViewContainerRef;
  @ViewChild('allTreatments', { read: ViewContainerRef })
  allReqs: ViewContainerRef;
  currentPage = 'tr'

  constructor(private factory: BuilderSerice) {}

  ngOnInit(): void {}
  openAllTreatments() {
    // this.allTreatments.clear();
    // this.factory.MountComponent(this.allTreatments, TreatmentsComponent, {});
    this.currentPage = 'tr'

  }
  openAllApplic() {
    // this.allApplic.clear();
    // this.factory.MountComponent(this.allApplic, AllApplicationsComponent, {});
    this.currentPage = 'apl'
  }
  openAllReqs() {
    // this.allReqs.clear();
    // this.factory.MountComponent(this.allReqs, AllRequestsComponent, {});
    this.currentPage = 'reqs'
  }
}

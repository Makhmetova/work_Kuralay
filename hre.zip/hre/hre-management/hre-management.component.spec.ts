import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HreManagementComponent } from './hre-management.component';

describe('HreManagementComponent', () => {
  let component: HreManagementComponent;
  let fixture: ComponentFixture<HreManagementComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HreManagementComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HreManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { AfterViewInit, Component, ComponentRef, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { DbQueryService } from '@app/_services/db-query.service';
import { QueryOptions } from '@app/_models/query';
import { BuilderSerice } from '@app/_services/builder.service';
import { EventEmitter } from 'events';
import { ComponentPoolService } from '@app/_services/componentPool.service';
import { IFormOptions } from '@app/_models/common';
import { PureDetailFormComponent } from '@app/_components/PureDetailForm/pureDetailForm.component';
import { StepInfoComponent } from '../../applications/step-info/step-info.component';
import { take } from 'rxjs/operators';
import { AccountService } from '@app/_services';
import { PureInfoBlockComponent } from '@app/_components/PureInfoBlock/pureInfoBlock.component';
@Component({
  selector: 'app-treatments',
  templateUrl: './treatments.component.html',
  styleUrls: ['./treatments.component.less']
})
export class TreatmentsComponent implements OnInit, AfterViewInit {
  display: boolean;
  dispatcher: EventEmitter;
  detailIsOpen: boolean;
  entity_code: string = 'hre_all_treatments';
  my_treatments: string = 'hre_treatments_work';
  group_treatments: string = 'hre_treatments_group';
  applicType = [];
  user: Object;
  infoUser: Object
  Emitter:EventEmitter;
  currentUser:Object;
  showOrdersForm: boolean = false;
  infoBlockParams = {};
  verticalInfoBlock: boolean = true;
  @ViewChild('detailFormHolder', {read:ViewContainerRef}) detailFormHolder:ViewContainerRef
  constructor(private network: DbQueryService, private account: AccountService, private pool: ComponentPoolService, private factory:BuilderSerice) {
    this.detailIsOpen=false;

   }

  ngOnInit(): void {
    this.account.getSession().pipe(take(1)).subscribe(u=>{
      let us = u.sessioninfo;
      this.network.executeQuery(`code=users&flt$id$eq$=${us.id}`,'get').pipe(take(1)).subscribe(res=>{
        this.user = res.items[0]
      })
    })

  }
  ngAfterViewInit() {
    let self = this;

  }

  openDetail(data) {

    console.log("Detail is open", data)
//data['title'] + '_requests';
    this.verticalInfoBlock = true;

    let tableForOrders: string = data['entity_code'] == "hre_vacation_new" ?'hre_vacation_order' : data['entity_code'] + '_orders';
    let tableForRequests: string = data['entity_code'] + '_requests';
    let tableForFiles: string = data['entity_code'] + '_files';
    let linkField = data['entity_code'] + '_id';
    this.network
      .getDetail(data['entity_code'], data['req_id'])
      .subscribe((det) => {
        let detail = det[data['entity_code']][0];
        this.detailFormHolder.clear();
        this.detailIsOpen = true;
        console.log('Out', data);

        if (data['application_type_id'] == 1) {
          this.showOrdersForm = true;
        } else if (data['application_type_id'] == 4) {
            // this.verticalInfoBlock = false;
        }
        let FilesSelectQueryOptions = new QueryOptions(tableForFiles);
        FilesSelectQueryOptions.flteq = {
          [linkField]: data['req_id'],
        };
        let timelineQueryOptions = new QueryOptions(
          'req_statuses_lookups_step'
        );
        timelineQueryOptions.flteq = {
          parent_lookup: 14,
        };
        let ordersOptions = new QueryOptions(tableForOrders);
        ordersOptions.flteq = {
          [linkField]: data['req_id'],
        };
        let requestOptions = new QueryOptions(tableForRequests);
        requestOptions.flteq = {
          [linkField]: data['req_id'],
        };
        let _comp = this.pool.getComponentsType('tables', data['entity_code'], true);
        let FormOptions: IFormOptions = {
          showApproveForm: true,
          showCommentsForm: true,
          showFilesForm: true,
          showHistoryForm: true,
          showTimeline: true,
          showOrdersForm: true,
          showInfoBlock: true,
          formComponent: _comp,
          mainFormOptions: {},
          formComponentParams: {
            detailId: data['req_id'],
            user: this.user,
          },
          approveOptions: {
            showButtons: false,
            showApproveButtons: false,
            useUsersFilter: true,
            useDefaultPreSettings: false,
          },
          filesOptions: {
            multiple: true,
            tableToSave: tableForFiles,
            FilesSelectQueryOptions: FilesSelectQueryOptions,
            fieldForLink: linkField,
            saveHistory: true,
          },

          ordersOptions: {
            ordersLookupOptions  : `code=core_entities_flow_map_v2_main&flt$is_order$eq$=1&flt$is_actual$eq$=1&flt$entity_source_code$eq$=${data['entity_code']}`,
            requestLookupOptions : `code=core_entities_flow_map_v2_main&flt$is_request$eq$=1&flt$is_actual$eq$=1&flt$entity_source_code$eq$=${data['entity_code']}`,
            tableForRequests: tableForRequests,
            tableForOrders: tableForOrders,
            ordersOptions: requestOptions,
            requestsOptions: requestOptions,
            useRest: true

          },
          infoBlockOptions: {
            verticalInfoBlock: this.verticalInfoBlock,
            InfoBlockComponent : PureInfoBlockComponent,
            InfoBlockParams : this.infoBlockParams
          },
          requestFormOptions: {
            onSaveUpdateInfoBlock: true,
          },
          timelineOptions: {
            useCustomTimeline: true,
            customTimelineComponent: StepInfoComponent,
            customTimelineOptions: {
              inputParams: {
                detail: detail,
              },
            },
            defaultTimelineOptions: {
              statusesLookupQuery: timelineQueryOptions,
            },
          },
        };
        console.log('Form done', FormOptions);

        let compRef: ComponentRef<any>;
        compRef = this.factory.MountComponent(
          this.detailFormHolder,
          PureDetailFormComponent,
          {
            FormOptions: FormOptions,
            table_name: data['entity_code'],
            id: data['req_id'],
            user: this.user,
            title: '',
          }
        );
        compRef.instance.onClose.subscribe((val) => {
          this.detailFormHolder.clear();
          this.detailIsOpen = false;
        });
      });
  }


  bindApplic() {
    this.entity_code = "hre_all_treatments"
    // this.network.getQuery(new QueryOptions("hre_all_treatments")).subscribe((resp) => {
    //     this.applicType = resp.items;
    //   });
  }

  myApplic(){
    this.entity_code = "hre_treatments_work"
    // this.network.getQuery(new QueryOptions("hre_treatments_work")).subscribe((resp) => {
    //     this.applicType = resp.items; //у меня в работе
    //   });
  }
  applicInGroup(){
    this.entity_code = "hre_treatments_group"
    // this.network.getQuery(new QueryOptions("hre_treatments_work")).subscribe((resp) => {
    //     this.applicType = resp.items; //у меня в работе
    //   });
  }

  // openDetail(event){
  //   this.detailIsOpen = true;
  //   console.log("Out", event);
  //   console.log("Out",  this.detailIsOpen);
  //   if(event['application_type_id']==1996){
  //     this.factory.MountComponent(this.detailFormHolder,HreVacationComponent, {
  //       detailId: event['detail_id'],
  //       detail: event
  //     })

  //   }
  // }

}

import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-files-decree',
  templateUrl: './files-decree.component.html',
  styleUrls: ['./files-decree.component.less']
})
export class FilesDecreeComponent implements OnInit {

  @Input() decree_values: any [] = [];
  
  constructor() { }

  ngOnInit(): void {
  }

}

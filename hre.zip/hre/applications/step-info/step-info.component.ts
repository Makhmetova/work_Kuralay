import { Component, Input, OnInit } from '@angular/core';
import { DbQueryService } from '@app/_services';
import { BuilderSerice } from '@app/_services/builder.service';
import {EventEmitter} from 'events';
@Component({
  selector: 'app-step-info',
  templateUrl: './step-info.component.html',
  styleUrls: ['./step-info.component.less']
})
export class StepInfoComponent implements OnInit {
  @Input() table_name:string;
  @Input() id:number;
  @Input() parentEmitter:EventEmitter
  @Input() details: Object;
  @Input() detail: Object;
  status_lookup_id:number
  req_status = [];
  req_status_index: any;


  constructor(private network: DbQueryService,
    private factory:BuilderSerice,){

  }

  ngOnInit(){
    console.log("Step info here");
    // console.log(this.id);
    // console.log("FFFF",this.detail);



    if (this.id == 0){
      if(this.table_name && this.table_name=='hre_ind_plan' || this.table_name=='hre_ref_work' || this.table_name=='hre_thanks' || this.table_name=='hre_idea_center'){
        this.network.executeQuery(`code=req_statuses_lookups&flt$entity_code$eq$=${this.table_name}`,'get').subscribe(val=>{
          if(val['items'].length > 0){
            this.status_lookup_id = val['items'][0]['id']
            this.network.executeQuery(`code=req_statuses_lookups_step&flt$parent_lookup$eq$=${this.status_lookup_id}`,'get').subscribe(vals=>{
              if(vals['items'].length > 0){
                this.req_status = vals['items'];
                // this.req_status_index = this.req_status.findIndex(x => x.id == vals['items'][0]['id']);
                this.detail['stage_id'] = vals['items'][0]['id']
              }
            })
          }
        })
      }else {
        this.network.executeQuery(`code=req_statuses_lookups&flt$entity_code$eq$=hre_reqs`,'get').subscribe(val=>{
          if(val['items'].length > 0){
            this.status_lookup_id = val['items'][0]['id']
            this.network.executeQuery(`code=req_statuses_lookups_step&flt$parent_lookup$eq$=${this.status_lookup_id}`,'get').subscribe(vals=>{
              if(vals['items'].length > 0){
                this.req_status = vals['items'];
                // this.req_status_index = this.req_status.findIndex(x => x.id == vals['items'][0]['id']);
                this.detail['stage_id'] = vals['items'][0]['id']
              }
            })
          }
        })
      }

    } else {
      this.network.executeQuery(`code=req_statuses_lookups_step&flt$parent_lookup$eq$=${this.detail['stage']}`,'get').subscribe(vals=>{
        if(vals){
          console.log("Status",vals, this.details);

          this.req_status = vals['items'];
          // this.req_status_index = this.req_status.findIndex(x => x.id == this.detail['status']);
        }
      })
    }

  }

}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HreThanksComponent } from './hre-thanks.component';

describe('HreThanksComponent', () => {
  let component: HreThanksComponent;
  let fixture: ComponentFixture<HreThanksComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HreThanksComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HreThanksComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

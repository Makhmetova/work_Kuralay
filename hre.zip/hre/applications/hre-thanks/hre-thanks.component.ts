import { Location } from '@angular/common';
import { Component, ComponentRef, EventEmitter, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PureDetailFormComponent } from '@app/_components/PureDetailForm/pureDetailForm.component';
import { PureInfoBlockComponent } from '@app/_components/PureInfoBlock/pureInfoBlock.component';
import { QueryOptions } from '@app/_models';
import { IFormOptions } from '@app/_models/common';
import { AccountService, DbQueryService } from '@app/_services';
import { BuilderSerice } from '@app/_services/builder.service';
import { ComponentPoolService } from '@app/_services/componentPool.service';
import { MainService } from '@app/_services/main.service';
import { StepInfoComponent } from '../step-info/step-info.component';

@Component({
  selector: 'app-hre-thanks',
  templateUrl: './hre-thanks.component.html',
  styleUrls: ['./hre-thanks.component.less']
})
export class HreThanksComponent implements OnInit {

  entity_code: string = "hre_thanks";
  detailId: number;
  details: any;
  userId: string;
  user: Object;
  verticalInfoBlock: boolean = true;
  detailIsOpen: boolean;
  emitter: EventEmitter<any>;
  @ViewChild('detailFormHolder', {read:ViewContainerRef}) detailFormHolder:ViewContainerRef

  constructor(
    private location: Location,
    private dbQueryService: DbQueryService,
    private mainService: MainService,
    private accountService: AccountService,
    private route: ActivatedRoute,
    private factory:BuilderSerice,
    private pool: ComponentPoolService,
  ) {
    this.emitter = new EventEmitter();
  }

  ngOnInit(): void {
    this.user = this.accountService.userValue.sessioninfo;
    this.route.params.subscribe(params => {
      this.detailId = Number(params['id']);

      if (this.detailId) {
        this.getDetails(this.detailId);
      } else {
        this.userId = this.accountService.userValue.id;
        this.details = null;
      }
    });
  }

  getDetails(id: number) {
    let query = this.dbQueryService.getDetail(this.entity_code, id)
      .subscribe( res => {
        if (res) {
          this.details = res;
          this.userId = res[this.entity_code][0]['created_by'];
        }
        query.unsubscribe();
      });
  }

  back() {
    this.location.back();
  }

  openDetail(data) {

    console.log("Detail is open", data)
//data['title'] + '_requests';
    this.verticalInfoBlock = true;

    let table = "hre_thanks";
    let tableForFiles: string = table + '_files';
    let linkField = table + '_id';
    this.dbQueryService
      .getDetail(table, data['id'])
      .subscribe((det) => {
        let detail = det[table][0];
        this.detailFormHolder.clear();
        this.detailIsOpen = true;
        console.log('Out', data);


        let FilesSelectQueryOptions = new QueryOptions(tableForFiles);
        FilesSelectQueryOptions.flteq = {
          [linkField]: data['id'],
        };
        let timelineQueryOptions = new QueryOptions(
          'req_statuses_lookups_step'
        );
        timelineQueryOptions.flteq = {
          parent_lookup: 14,
        };

        let _comp = this.pool.getComponentsType('tables', table, true);
        let FormOptions: IFormOptions = {
          showApproveForm: true,
          showCommentsForm: true,
          showFilesForm: true,
          showHistoryForm: true,
          showTimeline: true,
          showOrdersForm: false,
          showInfoBlock: true,
          formComponent: _comp,
          mainFormOptions: {},
          formComponentParams: {
            detailId: data['id'],
            user: this.user,
          },
          approveOptions: {
            showButtons: false,
            showApproveButtons: false,
            useUsersFilter: true,
            useDefaultPreSettings: false,
          },
          filesOptions: {
            multiple: true,
            tableToSave: tableForFiles,
            FilesSelectQueryOptions: FilesSelectQueryOptions,
            fieldForLink: linkField,
            saveHistory: true,
          },

          ordersOptions: {
            disabled: true,
            useRest: true

          },
          infoBlockOptions: {
            verticalInfoBlock: this.verticalInfoBlock,
            InfoBlockComponent : PureInfoBlockComponent,
            InfoBlockParams : {},
            InfoBlockCustomParams : {
              showCancelButton : false,
              showEndingButton : false,
              showReassignationButton : false,
              showTakeButton : false,
              disableGroup : true,
              disableStatus : true,
              disablePriority : true,
              disableExecutor : true,
              disableParent : true
          }
          },
          requestFormOptions: {
            onSaveUpdateInfoBlock: true,
          },
          timelineOptions: {
            useCustomTimeline: true,
            customTimelineComponent: StepInfoComponent,
            customTimelineOptions: {
              inputParams: {
                detail: detail,
              },
            },
            defaultTimelineOptions: {
              statusesLookupQuery: timelineQueryOptions,
            },
          },
        };
        console.log('Form done', FormOptions);

        let compRef: ComponentRef<any>;
        compRef = this.factory.MountComponent(
          this.detailFormHolder,
          PureDetailFormComponent,
          {
            FormOptions: FormOptions,
            table_name: table,
            id: data['id'],
            user: this.user,
            title: '',
          }
        );
        compRef.instance.onClose.subscribe((val) => {
          this.detailFormHolder.clear();
          this.detailIsOpen = false;
        });
      });
  }

}

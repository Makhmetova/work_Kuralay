import { options } from '@amcharts/amcharts4/core';
import { DatePipe } from '@angular/common';
import { Component, ComponentFactoryResolver, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { PrsnaWidget, PrsnaWidgetForm } from '@app/business/prsna/prsna-desktop/prsna-widgets/widget.model';
import { WidgetWrapperComponent } from '@app/business/prsna/prsna-employee-card/widget-wrapper/widget-wrapper.component';
import { BarChartComponent } from '@app/_components/charts/bar-chart/bar-chart.component';
import { BarChartModel } from '@app/_components/charts/bar-chart/bar-chart.model';
import { QueryOptions } from '@app/_models';
import { DbQueryService, MainService } from '@app/_services';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.less']
})
export class DashboardComponent implements OnInit {

  by_statuses = [];
  constructor(
    private network: DbQueryService
  ) { }

  ngOnInit(): void {

   this.network.executeQuery(`code=hre_thanks_by_status`,'get').subscribe(res => {
     this.by_statuses = res['items'];
    let sum = 0;
     this.by_statuses.forEach(x => {
        sum += Number(x['number'])
     })
     this.by_statuses.push({
       'status_id$': "Все",
       "number": sum
     })
     this.by_statuses.reverse();

   })
  }





}

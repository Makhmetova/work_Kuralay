import { DatePipe } from '@angular/common';
import { Component, ComponentFactoryResolver, Input, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { PrsnaWidget } from '@app/business/prsna/prsna-desktop/prsna-widgets/widget.model';
import { BarChartComponent } from '@app/_components/charts/bar-chart/bar-chart.component';
import { BarChartModel } from '@app/_components/charts/bar-chart/bar-chart.model';
import { QueryOptions } from '@app/_models';
import { DbQueryService, MainService } from '@app/_services';

@Component({
  selector: 'app-top-ten',
  templateUrl: './top-ten.component.html',
  styleUrls: ['./top-ten.component.less']
})
export class TopTenComponent implements OnInit {
  instance: any;
  top10Data: BarChartModel;
  @Input() widget: PrsnaWidget;
  @ViewChild('barChartTemplate', {read: ViewContainerRef}) top10Template;
  constructor(
    private _componentFactoryResolver: ComponentFactoryResolver,
    private dbQueryService: DbQueryService,
    private mainService: MainService,
    private datePipe: DatePipe
  ) {

   }

  ngOnInit(): void {
    this.top10Data = {
      widgetId : 2,
      data: []
    };
    this.bindTopTenData();
  }
  bindTopTenData(){
    let options = new QueryOptions('hre_thanks_users');
    let query = this.dbQueryService.getQuery(options)
      .subscribe((res) => {
        if (res.items) {
          this.top10Data.data = [];
            let finded = res.items.reverse().slice(0,10);
            console.log("find", finded);

            if(finded) {
              finded.forEach(x => {
                this.top10Data.data.push({
                  category: x['to_whom$'],
                  value: x['number'],
                });
              })
          }
          console.log("TOP", this.top10Data);

        }

        this.loadBarChart();
        query.unsubscribe();
      });
  }
  loadBarChart() {
    // instantiate the component
    if (!this.instance) {
      let componentFactory = this._componentFactoryResolver.resolveComponentFactory(BarChartComponent);
      let componentRef = this.top10Template.createComponent(componentFactory);
      this.instance = componentRef.instance;
    }
    // set the props
    this.instance.chartData = this.top10Data;
  }



}

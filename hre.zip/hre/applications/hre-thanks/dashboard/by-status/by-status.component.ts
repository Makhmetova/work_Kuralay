import { DatePipe } from '@angular/common';
import { Component, ComponentFactoryResolver, Input, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { PrsnaWidget } from '@app/business/prsna/prsna-desktop/prsna-widgets/widget.model';
import { BarChartComponent } from '@app/_components/charts/bar-chart/bar-chart.component';
import { BarChartModel } from '@app/_components/charts/bar-chart/bar-chart.model';
import { QueryOptions } from '@app/_models';
import { DbQueryService, MainService } from '@app/_services';

@Component({
  selector: 'app-by-status',
  templateUrl: './by-status.component.html',
  styleUrls: ['./by-status.component.less']
})
export class ByStatusComponent implements OnInit {
  @ViewChild('statusChartTemplate', {read: ViewContainerRef}) statusTemplate;
  @Input() widget: PrsnaWidget;
  instance: any;
  statusData: BarChartModel;
  constructor(
    private _componentFactoryResolver: ComponentFactoryResolver,
    private dbQueryService: DbQueryService,
    private mainService: MainService,
    private datePipe: DatePipe
  ) { }

  ngOnInit(): void {
    this.statusData = {
      widgetId : 1,
      data: []
    };
    this.bindStatusData();
  }

  bindStatusData(){
    let options = new QueryOptions('hre_thanks_by_status');
    let query = this.dbQueryService.getQuery(options)
      .subscribe((res) => {
        if (res.items) {
          this.statusData.data = [];
            let finded = res.items;
            console.log("find", finded);

            if(finded) {
              finded.forEach(x => {
                this.statusData.data.push({
                  category: x['status_id$'],
                  value: x['number'],
                });
              })
          }
          console.log("TOP", this.statusData);

        }

        this.loadBarChart2();
        query.unsubscribe();
      });
  }


  loadBarChart2() {
    // instantiate the component
    if (!this.instance) {
      let componentFactory = this._componentFactoryResolver.resolveComponentFactory(BarChartComponent);
      let componentRef = this.statusTemplate.createComponent(componentFactory);
      this.instance = componentRef.instance;
    }
    // set the props
    this.instance.chartData = this.statusData;
  }
}

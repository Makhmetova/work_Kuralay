import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';

import { User, UserInfo } from '@app/_models';
import { AccountService, DbQueryService } from '@app/_services';
import { LookupService } from '@app/_services/lookupService.service';
import { MainService } from '@app/_services/main.service';
import { take } from 'rxjs/operators';

@Component({
  selector: 'app-thanks-detail-form',
  templateUrl: './thanks-detail-form.component.html',
  styleUrls: ['./thanks-detail-form.component.less'],
})
export class ThanksDetailFormComponent implements OnInit {
  detailId: number;
  detail: Object;
  entity_code = 'hre_thanks';
  details: Array<Object>;
  users: any[] = [];
  whom: Object;
  user: Object;
  @Output() onSave = new EventEmitter<Object>();
  @Output() onClose = new EventEmitter<Object>();
  @Output() openRoute = new EventEmitter<Object>();
  @Input() onAction = new EventEmitter<Object>();
  @Input() onStart = new EventEmitter<Object>();

  @Output() onApplicantChange = new EventEmitter<Object>();

  constructor(
    private mainService: MainService,
    private dbQueryService: DbQueryService,
    private lookup: LookupService,
    private accountService: AccountService
  ) {
    this.detail = {};
    this.whom = {};
  }

  ngOnInit(): void {
    let u = this.accountService.userValue;
    let id;
    this.lookup.getLookup('users_select').subscribe((res) => {
      this.users = res['items'];
    });
    if (this.detailId != 0){
      id = this.detail['to_whom'];
    }else {
     id = u.sessioninfo.id;
    }
    this.dbQueryService
    .executeQuery(
      `code=users&flt$id$eq$=${id}`,
      'get'
    )
    .pipe(take(1))
    .subscribe((res) => {
      this.whom = res.items[0];
      //console.log(this.user);
    });
    this.onStart.subscribe((res) => {
      this.onClose.emit({});
      this.mainService.toastSuccess('Заявка отправлена');
      this.detail['status_id'] = "3";
      this.dbQueryService
         .updateTable(this.entity_code, [this.detail])
         .subscribe((val) => {

         });
    });
    this.onAction.subscribe((val) => {
      console.log('after start log', val, this.detailId);

          if (val['approve_res_id'] == 1) {
            this.detail['status_id'] = '4';
            this.detail['stage_id'] = '78';
            this.dbQueryService
              .updateTable(this.entity_code, [this.detail])
              .subscribe((val) => {});
          } else if (val['approve_res_id'] == 2) {
            this.detail['status_id'] = '5';
            this.dbQueryService
              .updateTable(this.entity_code, [this.detail])
              .subscribe((val) => {});
          }
    });
  }

  ngAfterViewInit() {}
  getUserInfo(event) {
    console.log('апликант на модуль', event.data);

    if (event.data.id) {
      this.accountService.getById(event.data.id).subscribe((userInfo) => {
        this.whom = userInfo['users'][0];
        console.log(this.whom);
        this.onApplicantChange.emit(this.whom);
      });
    }
  }
  save() {
    if (this.detailId) {
      this.dbQueryService
        .updateTable(this.entity_code, [this.detail])
        .toPromise()
        .then((res) => {
          if (res['error']) {
            this.mainService.toastError(res['error_text']);
          } else {
            this.mainService.toastSuccess('Заявка успешна обновлена!');
          }
        });
    } else {
      this.detail['to_whom'] = this.whom['id'];
      this.detail['stage_id'] = '77';
      this.detail['status_id'] = '3';
      this.detail['stage'] = '18';
      this.detail['priority'] = '2';
      this.dbQueryService
        .insertTable(this.entity_code, [this.detail])
        .toPromise()
        .then((res) => {
          console.log(res, 'RES');

          if (res['error']) {
            this.mainService.toastError(res['error_text']);
          } else {
            this.detailId = res['items'][0]['last_insert_id'];
            this.detail['id'] = this.detailId;
            this.onSave.emit({
              data: this.detail,
              code: this.entity_code,
              id: this.detailId,
            });
            this.dbQueryService
              .bpRun('hre_new_req', {
                entity_code: this.entity_code,
                pk: res.items[0]['sys$uuid'],
                req_id: res.items[0]['last_insert_id'],
                action: 'new',
              })
              .subscribe((res) => {
                this.openRoute.emit({});
              });
          }
        });
    }
  }

  cancel() {}

  ngOnDestroy() {}
}

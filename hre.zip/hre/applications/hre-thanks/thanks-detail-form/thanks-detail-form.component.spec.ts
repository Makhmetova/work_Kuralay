import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ThanksDetailFormComponent } from './thanks-detail-form.component';

describe('ThanksDetailFormComponent', () => {
  let component: ThanksDetailFormComponent;
  let fixture: ComponentFixture<ThanksDetailFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ThanksDetailFormComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ThanksDetailFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

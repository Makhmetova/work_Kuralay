import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HreAnnScheduleComponent } from './hre-ann-schedule.component';

describe('HreAnnScheduleComponent', () => {
  let component: HreAnnScheduleComponent;
  let fixture: ComponentFixture<HreAnnScheduleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HreAnnScheduleComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HreAnnScheduleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

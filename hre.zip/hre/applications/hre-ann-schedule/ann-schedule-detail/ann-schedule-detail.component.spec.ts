import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AnnScheduleDetailComponent } from './ann-schedule-detail.component';

describe('AnnScheduleDetailComponent', () => {
  let component: AnnScheduleDetailComponent;
  let fixture: ComponentFixture<AnnScheduleDetailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AnnScheduleDetailComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AnnScheduleDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { RunTaskResponse } from '@app/_models';
import { AccountService, DbQueryService } from '@app/_services';
import { MainService } from '@app/_services/main.service';

@Component({
  selector: 'app-ann-schedule-detail',
  templateUrl: './ann-schedule-detail.component.html',
  styleUrls: ['./ann-schedule-detail.component.less']
})
export class AnnScheduleDetailComponent implements OnInit, OnChanges {

  @Input() detailId: number;
  entity_code= "hre_ann_sch";
  @Input() details: any;

  rowData: any [] = [];
  lm_id: number;
  month_arr: any[];
  statuses: any[] = [];
  sessionRoles: Object;
  sessioninfo: Object;
  tasks: any[];
  

  constructor(
    private dbQueryService: DbQueryService,
    private mainService: MainService,
    private router: Router,
    private accountService: AccountService
  ) { }

  ngOnInit(): void {    
    this.sessionRoles = this.accountService.sessionRoles;
    this.sessioninfo = this.accountService.userValue.sessioninfo;
  }

  
  ngOnChanges(changes: SimpleChanges): void {
    if (changes.details) {
      if (this.details) {
        this.lm_id = this.details[this.entity_code][0]['created_by'];

        this.getItemsSelect("tasks", "", { 'flteq': { manager_id: this.sessioninfo['id'], entity_id: "(select entity_id from entities where entity_code='"+this.entity_code+"')", entity_pk: this.detailId, status_id: "(select id from task_statuses where code='opened')" } })
          .subscribe(res => {
              if (res.items) {
                this.tasks = res.items;
              }
            });
      } else {
        this.lm_id = this.accountService.userValue.sessioninfo.id;
      }

      
      this.getItemsSelect("users", "", { 'flteq': {lm_user_id: this.lm_id } }).toPromise()
        .then(res => {
          if (res.items) {
            this.rowData = res.items;
            this.bind();
          }
        });
        
    }
  }


  ngAfterViewInit() {
    setTimeout(() => {
      this.getItemsSelect("hre_application_status_select", "").toPromise()
      .then((res) => {
        this.statuses = res.items;
        return this.getItemsSelect("months_cls_select", "").toPromise();
      }).then((res) => {
        this.month_arr = res.items;
      });

    });
  }


  bind() {
    this.rowData.forEach(d => {
      d['month_val'] = this.month_arr.map(m => {
        let find = this.details ? this.details['hre_ann_sch_month'].find(e => e.month == m.id && e.user_id == d.id) : null;
        if (find) {
          return { plan_day: find.plan_day, fact_day: find.fact_day };
        }
        return { plan_day: null, fact_day: null };
      });
    });

    console.log("Row data: ", this.rowData);
  }

  getItemsSelect(code: string, _query?: string, params?: Object) {
    return this.dbQueryService.getQuerySelect(code, _query, 100, params);
  }

  save() {
    if (this.detailId) {
      let values_update = this.details["hre_ann_sch_month"].filter( function(item) { return item._edited == 1 && item._inserted != 1 });
      if (values_update.length > 0) {
        this.dbQueryService.updateTable("hre_ann_sch_table",  values_update)
          .subscribe(res => {
            if (res['error']) {
              this.mainService.toastError(res['error_text']);
            } else {
              this.mainService.toastSuccess("Успешно обновлен");
            }
          });
      }

      let values_insert = this.details["hre_ann_sch_month"].filter( function(item) { return item._inserted == 1 && item._deleted != 1 });
      if (values_insert.length > 0) {
        this.dbQueryService.insertTable("hre_ann_sch_table", values_insert)
          .subscribe(res => {
            if (res['error']) {
              this.mainService.toastError(res['error_text']);
            } else {
              this.mainService.toastSuccess("Успешно добавлено!");
            }
          });
      }
     

      let values_delete = this.details["hre_ann_sch_month"].filter(  function(item) { return item._inserted != 1 && item._deleted == 1 });
      if (values_delete.length > 0) {
        this.dbQueryService.deleteBulk("hre_ann_sch_table", values_delete)
          .subscribe(res => {
            if (res['error']) {
              this.mainService.toastError(res['error_text']);
            } else {
              this.mainService.toastSuccess("Успешно удалено");
            }
          });
      }
      
    } else {
      this.dbQueryService.insertTable(this.entity_code, [{ title: "" }])
        .toPromise().then(res => {
          if (res['error']) {
            this.mainService.toastError(res['error_text']);
          } else {
            this.router.navigate(['/hre_ann_sch_details', { id: res['items'][0]['last_inserted_id']}])
          }
        });
    }
  }
  
  editRowDataMonth(row: any, index: number) {
    let find = this.details["hre_ann_sch_month"].find(e => e.month == (index+1));
    if (find) {
      if (row['month_val'][index].plan_day == '') {
        find._deleted = 1;
      } else {
        find._edited = 1;
      }
    } else {
      let index = this.addhre_ann_sch_month();
      find = this.details["hre_ann_sch_month"][index-1];
    }
    
    find.month = index + 1;
    find.user_id = row.id;
    find.plan_day = row['month_val'][index].plan_day;
    find.fact_day = row['month_val'][index].fact_day;
  } 

  addhre_ann_sch_month () {
    let last_index = this.details["hre_ann_sch_month"].push({ _inserted:1, hre_ann_sch_id: this.detailId });    
    return last_index
  }

  sendToFill() {
    this.dbQueryService.bpRun("hre_ann_to_fill", { pk: this.detailId, lm_id: this.lm_id })
      .subscribe((resp: RunTaskResponse) => {
        if(resp.ok) {
          if(resp.instanceIsFinished) {
              if(!resp.output.last_error) {
                this.mainService.toastSuccess('Успешно отправлено на заполнение!');
              } else {
                this.mainService.toastError(resp.output.last_error);
              }
          } else if(resp.task){
            // this.openBpModal();
            // this.getUserTaskData(resp.task);
          } else {
            this.mainService.toastInfo('BPM Run', 'Процесс запущен.');
          }
        } else {
          this.mainService.toastError('Ошибка! Что-то пошло не так.');
        }
      })
  }

  confirm() {
    // this.dbQueryService.bpRun()
  }

  cancel() {
    this.bind();
  }

  ngOnDestroy() {

  }

}

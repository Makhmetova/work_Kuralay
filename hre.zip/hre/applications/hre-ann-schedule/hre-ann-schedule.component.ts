import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { RunTaskResponse } from '@app/_models';
import { APPROVE_RESULT } from '@app/_models/commands';
import { AccountService, DbQueryService } from '@app/_services';
import { MainService } from '@app/_services/main.service';

@Component({
  selector: 'app-hre-ann-schedule',
  templateUrl: './hre-ann-schedule.component.html',
  styleUrls: ['./hre-ann-schedule.component.less']
})
export class HreAnnScheduleComponent implements OnInit {

  entity_code: string = "hre_ann_sch";
  detailId: number;
  details: any;
  userId: string;
  user: Object;

  displayEdsModal: boolean = false;
  task_manager_id: number;

  constructor(
    private location: Location,
    private dbQueryService: DbQueryService,
    private mainService: MainService,
    private accountService: AccountService,
    private route: ActivatedRoute
  ) { 
  }

  ngOnInit(): void {
    this.user = this.accountService.userValue.sessioninfo;
    this.route.params.subscribe(params => {
      this.detailId = Number(params['id']);

      if (this.detailId) {
        this.getDetails(this.detailId);
      } else {
        this.userId = this.accountService.userValue.id;
        this.details = null;
        // if (!this.accountService.sessionRoles['line_manager']) {
        //   this.back();
        // }
      }
    });
  }

  ngAfterViewInit() {
  }

  getDetails(id: number) {
    let query = this.dbQueryService.getDetail(this.entity_code, id)
      .subscribe( res => {
        if (res) {
          this.details = res;
          this.userId = res[this.entity_code][0]['created_by'];
        }
        query.unsubscribe();
      });
  }

  back() {
    this.location.back();
  }

  onApproveResult(data: any) {
    // approve_res_id: "1"
    // entity_code: "hre_vacation"
    // pk_uuid: "729f8b03-5f33-4564-8148-3af609377d2f"
    // step_nn: "1"
    // task_id: "3344"
    // user_id_s: "7165"
    console.log("After approve: ", data);
    if (data?.approve_res_id == APPROVE_RESULT.IS_APPROVED) {
      this.task_manager_id = data.user_id_s;
      this.displayEdsModal = true;
    }
  }

  onDocumentSigned(data: any) {
    this.bpRun("hre_application_approve", {'entity_code': this.entity_code, 'pk': this.detailId, signxml: data.sign });
  }

  bpRun(code: string, input: any) {
    this.dbQueryService.bpRun(code, input)
      .subscribe((resp: RunTaskResponse) => {
        console.log(code + ": ", resp);
        if(resp.ok) {
          if(resp.instanceIsFinished) {
              if(!resp.output.last_error) {
                  this.mainService.toastSuccess('Успешно');
                  this.getDetails(this.detailId);
              } else {
                  this.mainService.toastError(resp.output.last_error);
              }
          } else if(resp.task){
              // this.openBpModal();
              // this.getUserTaskData(resp.task);
          } else {
              this.mainService.toastInfo('BPM Run', 'Процесс запущен.');
          }
        } else {
          this.mainService.toastError('Ошибка! Что-то пошло не так.');
        }

        this.displayEdsModal = false;
      });
  }

  ngOnDestroy() {}

}

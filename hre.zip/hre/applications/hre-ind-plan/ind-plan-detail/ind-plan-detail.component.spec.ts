import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IndPlanDetailComponent } from './ind-plan-detail.component';

describe('IndPlanDetailComponent', () => {
  let component: IndPlanDetailComponent;
  let fixture: ComponentFixture<IndPlanDetailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IndPlanDetailComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(IndPlanDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

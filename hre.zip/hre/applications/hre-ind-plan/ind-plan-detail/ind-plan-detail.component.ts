import {
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  SimpleChanges,
  ViewChild,
  ViewContainerRef,
} from '@angular/core';
import { Router } from '@angular/router';
import { PureApproveFormComponent } from '@app/_components/PureApprove/pureApprove.component';
import { User } from '@app/_models';
import { COMMANDS_SUB } from '@app/_models/commands';
import { EntityClass } from '@app/_models/entity';
import {
  AccountService,
  ApproveClass,
  DbQueryService,
  IStage,
  ITask,
} from '@app/_services';
import { BuilderSerice } from '@app/_services/builder.service';
import { MainService } from '@app/_services/main.service';
import { TreeNode } from 'primeng/api';
import { take } from 'rxjs/operators';
import {IndPlanTablePartComponent} from './ind-plan-table-part/ind-plan-table-part.component';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
@Component({
  selector: 'app-ind-plan-detail',
  templateUrl: './ind-plan-detail.component.html',
  styleUrls: ['./ind-plan-detail.component.less'],
})
export class IndPlanDetailComponent implements OnInit {
  @Input() detailId: number;
  entity_code = 'hre_ind_plan';
  @Input() details: any;
  @Output() openRoute = new EventEmitter<Object>();
  entity_class: EntityClass;
  executors: any[] = [];
  statuses: any[] = [];
  sessionRoles: Object;
  sessioninfo: Object;
  user: Object;
  user2: Object;
  users: Array<Object> = [];
  userId: number;
  @Input() onAction = new EventEmitter<Object>();
  @Input() onStart = new EventEmitter<Object>();
  @Output() onClose = new EventEmitter<Object>();
  @Output() onSave = new EventEmitter<Object>();
  @Output() doStart: EventEmitter<Object> = new EventEmitter<Object>();
  @ViewChild('approveFormHolder', { read: ViewContainerRef })
  @ViewChild(IndPlanTablePartComponent) private _child: IndPlanTablePartComponent;
  approveFormHolder: ViewContainerRef;
  currentTask: Object;
  tasks: Array<TreeNode<Object>>;
  templateRawData: Object = {};
  indexer: number;
  ready: boolean;
  detail: Object;
  userSent: any;
  user22: User;
  constructor(
    private mainService: MainService,
    private dbQueryService: DbQueryService,
    private factory: BuilderSerice,
    private accountService: AccountService,
    private main: MainService,
    private formBuilder: FormBuilder,
  ) {
    this.tasks = [];
    this.indexer = 1;
    this.templateRawData = {};
    this.ready = false;
  }

  ngOnInit(): void {
    console.log('qwertyuiop', this.detailId);
    this.sessionRoles = this.accountService.sessionRoles;
    //this.user = this.accountService.userValue.sessioninfo;
    this.userId = this.user['id'];
    this.main.usersObservable.subscribe((x) => {
      console.log('users_select', this.user);
      this.users = x;
    });
    this.getItemsSelect('users_select_by_roles', '', { param1: 'hr_manager' })
      .toPromise()
      .then((res) => {
        this.executors = res.items;
        return this.getItemsSelect(
          'hre_application_status_select',
          ''
        ).toPromise();
      })
      .then((res) => {
        this.statuses = res.items;
        this.getEntityAttrs(this.entity_code);
      });
    this.dbQueryService
      .executeQuery(
        `code=users&flt$id$eq$=${this.accountService.userValue.sessioninfo.id}`,
        'get'
      )
      .pipe(take(1))
      .subscribe((res) => {
        console.log('Res', res);

        this.user = res.items[0];
        this.userId = this.user['id'];
        //console.log(this.user);
      });

      this.lmVisible();

    this.onAction.subscribe((val) => {
      console.log('after start log', val, this.detailId);
      this.dbQueryService
        .getDetail('hre_ind_plan', this.detailId)
        .subscribe((res) => {
          console.log('params', res);
          if (val['approve_res_id'] == 1) {
            res['hre_ind_plan'][0]['status_id'] = 4;
            res['hre_ind_plan'][0]['stage_id'] = 81;
            this.dbQueryService
              .updateTable(this.entity_code, [res['hre_ind_plan'][0]])
              .subscribe((res) => {});
          } else if (val['approve_res_id'] == 4) {
            this.dbQueryService.bpRun('hre_application_close', {
              entity_code: this.entity_code,
              pk: this.detailId,
              pk_uuid: res['hre_ind_plan'][0]['sys$uuid'],
              task_id: val.task_id,
            });
          }
        });
    });
    this.onStart.subscribe(val =>{
      this.onClose.emit({});
      this.mainService.toastSuccess('Заявка отправлена!');
    })
    this._child.disablefunction();


  }

  ngAfterViewInit() {}

  lmVisible(){
    console.log("ind_plan")
    this.accountService.getById(this.details['hre_ind_plan'][0]['sent_by']).subscribe(namesurname=>{
      this.userSent = namesurname.users[0];
      let lm_sent_by = namesurname.users[0]["lm_user_id"]

    this.user22 = this.accountService.userValue;
    console.log("wertyui",this.user22.sessioninfo.id)
    this.accountService.getById(this.user22.sessioninfo.id).subscribe(value=>{
    if(this.detailId !=0){
      console.log("manager", this.entity_class.form.controls);



      if(this.user22.sessioninfo.id != lm_sent_by){


        this.entity_class.form.controls['security_feedback'].disable();
        this.entity_class.form.controls['security_manager_grade'].disable();
        this.entity_class.form.controls['quality_feedback'].disable();
        this.entity_class.form.controls['quality_manager_grade'].disable();
        this.entity_class.form.controls['init_feedback'].disable();
        this.entity_class.form.controls['init_manager_grade'].disable();
        this.entity_class.form.controls['team_feedback'].disable();
        this.entity_class.form.controls['team_manager_grade'].disable();






       }
      }

     });
    });
     }

  proverka() {
    console.log('input proverka', this.entity_class.form);
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.details && this.entity_class) {
      this.bind();
    }
  }

  bind() {
    if (this.entity_class) {
      this.entity_class.form = this.entity_class.createForm();
      if (this.details) {
        this.entity_class.bindForm(
          this.entity_class.form,
          this.details[this.entity_code][0]
        );
      }
      console.log('entity', this.entity_class);
      console.log('entity', this.entity_class.form);
    }
  }

  getEntityAttrs(code: string) {
    this.dbQueryService.getEntityAttrsByCode(code).subscribe((res) => {
      if (res.items) {
        this.entity_class = new EntityClass(this.entity_code);
        this.entity_class.setEntityAttrs(res.items);
        this.bind();
      }
    });
  }

  getItemsSelect(code: string, _query?: string, params?: Object) {
    return this.dbQueryService.getQuerySelect(code, _query, 100, params);
  }

  save() {
    if (this.detailId != 0) {
      // this.dbQueryService
      //   .updateTable(this.entity_code, [this.entity_class.form.getRawValue()])
      //   .toPromise()
      //   .then((res) => {
      //     if (res['error']) {
      //       this.mainService.toastError(res['error_text']);
      //     } else {
      //       this.mainService.toastSuccess('Заявка успешно обновлена!');
      //       this.mainService.commandSub.next({
      //         cmd: COMMANDS_SUB.SAVE_IND_TABLE,
      //         data: { detailId: this.detailId },
      //       });
      //     }
      //   });

      this.dbQueryService
      .updateTable(this.entity_code, [this.detail])
      .subscribe((val) => {
        if (val['items'] && val['items'].length > 0) {
          console.log(val);
          this.onSave.emit({
            data: this.detail,
            code: this.entity_code,
            id: this.detailId,
          });
        }
      });

    } else {



      // this.dbQueryService
      // .insertTable(this.entity_code, [this.detail])
      // .subscribe((val) => {
      //   if (val['items'] && val['items'].length > 0) {
      //     console.log(val);
      //     this.detailId = val['items'][0]['last_insert_id'];
      //     this.detail['id'] = this.detailId;
      //     this.onSave.emit({
      //       data: this.detail,
      //       code: this.entity_code,
      //       id: this.detailId,
      //     });
      //     console.log("bp ruuuuunnn")

      //   }
      // });
      //this.entity_class.form.controls.status.setValue(52);
      this.entity_class.form.controls['status_id'].setValue(1);
      this.entity_class.form.controls['priority'].setValue(2);
      this.entity_class.form.controls['user_group'].setValue(1);
      this.entity_class.form.controls['stage'].setValue(19); //stage
      this.entity_class.form.controls['stage_id'].setValue(80);
      this.entity_class.form.controls['title'].setValue(" ");
      this.dbQueryService
        .insertTable(this.entity_code, [this.entity_class.form.getRawValue()])
        .toPromise()
        .then((res) => {
          if (res['error']) {
            this.mainService.toastError(res['error_text']);
          } else {
            this.mainService.commandSub.next({
              cmd: COMMANDS_SUB.SAVE_IND_TABLE,
              data: { detailId: res['items'][0]['last_insert_id'] },
            });

            this.onSave.emit({
              data: this.entity_class.form.getRawValue(),
              code: this.entity_code,
              id: res.items[0]['last_insert_id'],
            });
            this.dbQueryService.bpRun('hre_new_req', {
              entity_code: this.entity_code,
              pk: res.items[0]['sys$uuid'],
              req_id: res.items[0]['last_insert_id'],
              action: 'new',
            }).subscribe(res => {
              this.openRoute.emit({});
            });

            // this.router.navigate(['/hre/services'])

            // console.log('айди', res['items'][0]['last_insert_id']);
          }
          })
        }




      }
  cancel() {
    this.onClose.emit({});
  }

  ngOnDestroy() {}

}

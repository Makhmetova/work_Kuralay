import { Component, Input, OnInit, SimpleChanges } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { UpdateParams, UpdateAction, User } from '@app/_models';
import { COMMANDS_SUB } from '@app/_models/commands';
import { EntityClass } from '@app/_models/entity';
import { DbQueryService, AccountService } from '@app/_services';
import { MainService } from '@app/_services/main.service';
import { forkJoin } from 'rxjs';
import { Subscription } from 'rxjs';
import { filter } from 'rxjs/operators';

@Component({
  selector: 'app-ind-plan-table-part',
  templateUrl: './ind-plan-table-part.component.html',
  styleUrls: ['./ind-plan-table-part.component.less']
})
export class IndPlanTablePartComponent implements OnInit {
  formGroup: FormGroup;
  @Input() detailId: number;
  @Input() details: any;
  @Input() entity_code: string = 'hre_ind_optimization';
  @Input() caption: string;
  @Input() disabled = true
  entity_attrs: any[] = [];
  entity_class: EntityClass;
  sessionRoles: Object;

  deleted_values: any[] = [];
  commandSub: Subscription;

  detail: Object;
  form: FormGroup;
  userSent: any;
  user: User;

  constructor(
    private mainService: MainService,
    private dbQueryService: DbQueryService,
    private formBuilder: FormBuilder,
    private accountService: AccountService
  ) { 
    }

  ngOnInit(): void {
    this.sessionRoles = this.accountService.sessionRoles;
    // this.formGroup = this.formBuilder.group({
		// 	emp_comment: new FormControl({ value: '', disabled: this.disabled })
		// });
        //console.log("fariza0",this.detailId);
    
    this.getEntityAttrs(this.entity_code);
    console.log("THIS22", this);
  }

  ngAfterViewInit() {
    this.commandSub = this.mainService.commandSub
      .pipe(
        filter(cmd => cmd.cmd === COMMANDS_SUB.SAVE_IND_TABLE)
      ).subscribe( (res) => {
        this.saveTableParts(res.data);
      });
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.details && this.entity_class) {
      this.bind();
    }
  }

  bind() {
    // let patchVal = {};
    // for (let param of Object.keys(this.form.getRawValue())) {
    //   // if (param == 'start_date' || param == 'end_date') {
    //   //   patchVal[param] = new Date(this.details[this.entity_code][0][param]);
    //   // } else {
    //   //   patchVal[param] = this.details[this.entity_code][0][param];
    //   // }
    // }
    // this.form.patchValue(patchVal);
    console.log("dates");
    this.entity_class.form = this.formBuilder.group({
      tableRowArray: this.formBuilder.array([])
    });
    console.log("Fooorm",  this.entity_class.form);

    if (this.details) {
      console.log("Detsil", this.details);
      
     
      this.details[this.entity_code].forEach((element, index) => {

        // this.entity_class.addRow();
        let form = this.entity_class.createForm();
        console.log("Fooorm", form);
        
        this.entity_class.tableRowArray.push(form);
        this.entity_class.bindForm(form, element);
      });
      this.entity_class.tableRowArray.controls.forEach( x =>{
        x['controls']['emp_comment'].disable();
        x['controls']['emp_weight'].disable();
        x['controls']['mng_comment'].disable();
        x['controls']['mng_weight'].disable();
        x['controls']['emp_comment_year'].disable();
        x['controls']['emp_weight_year'].disable();
        x['controls']['mng_comment_year'].disable();
        x['controls']['mng_weight_year'].disable();
      })

        let date = new Date(this.details['hre_ind_plan'][0]['created_at'] )
        let sixmonth = new Date();
        let oneyear = new Date();
        let current = new Date();
        sixmonth = new Date(sixmonth.setMonth(date.getMonth()+6));
        oneyear = new Date(oneyear.setFullYear(date.getFullYear() + 1));
       
        console.log("шесть мес", date)
        console.log("шесть мес", sixmonth)


        this.accountService.getById(this.details['hre_ind_plan'][0]['sent_by']).subscribe(namesurname=>{
          this.userSent = namesurname.users[0];
          let lm_sent_by = namesurname.users[0]["lm_user_id"]
        
        this.user = this.accountService.userValue;
        this.accountService.getById(this.user.sessioninfo.id).subscribe(value=>{
          
            console.log("досвидания")

            this.entity_class.tableRowArray.controls.forEach( x =>{
              
              if(current > sixmonth  ){
                if(value.users[0].id == this.userSent['id'] ){
                  x['controls']['emp_comment'].enable();
                  x['controls']['emp_weight'].enable();
                }
                

                if(value.users[0].id != lm_sent_by){
                  x['controls']['mng_comment'].disable();
                  x['controls']['mng_weight'].disable();
                }
              }  
      
              if(current > oneyear){
                if(value.users[0].id == this.userSent['id'] ){
                x['controls']['emp_comment_year'].enable();
                x['controls']['emp_weight_year'].enable();
              }
                if(value.users[0].id != lm_sent_by){
               
                x['controls']['mng_comment_year'].disable();
                x['controls']['mng_weight_year'].disable();
              }
            }
              
            })
          
        });
      })

       
        
       
        // console.log( "created_at",this.entity_class.tableRowArray.controls[0]['created_at'])
        
     
       
    }

   
    console.log("entity2",this.form);
    this.disablefunction();

  }
  
  disablefunction(){
    console.log("THIS", this);
    
    if(this.detailId == 0){
      this.entity_class.tableRowArray.controls.forEach( x =>{
      x['controls']['emp_comment'].disable();
      x['controls']['mng_comment'].disable();
      x['controls']['emp_comment_year'].disable();
      x['controls']['mng_comment_year'].disable();
      });
		};
    
  
    console.log("diasable",this.entity_class)
    // console.log("diasable",this.formGroup.controls['emp_weight'])
    
    
    
  }


  getEntityAttrs(code: string) {
    // let query = this.dbQueryService
      // .getEntityAttrsByCode(code)
      // .subscribe((res) => {
      //   console.log('Ent', res);

      //   this.entity_attrs = res.items;
      //   this.formControls();
      //   query.unsubscribe();
      // });
    this.dbQueryService.getEntityAttrsByCode(code)
      .subscribe( res => {
        if (res.items) {
          
          this.entity_class = new EntityClass(this.entity_code);
          this.entity_class.setEntityAttrs(res.items);
          this.bind();
          console.log("Reeees", this.entity_class);
        }
        
      
      })
      console.log( "created_at",this.details)
      console.log( "created_at", this.entity_class)
  }
 
  formControls() {
    this.form = new FormGroup({});
    for (let item of this.entity_attrs) {
      let control: FormControl = new FormControl(null);
      let validators = [];
      if (Number(item['rq'])) {
        validators.push(Validators.required);
      }
      control.setValidators(validators);
      this.form.addControl(item['code'], control);
    }

    // console.log(this.details);
    if (this.details) {
      this.bind();
    }
    console.log('Foorm', this.form);

    if (this.detail['id']) {
      // this.makeDisable();
      // this.form.controls['mat_help_amount'].enable();
      // this.form.controls['graphic_type'].enable();
      // this.form.controls['work_start'].enable();
      //this.getDetails(this.detail['id']);
    }
    if (this.detail['decree_id']) {
      // this.makeDisable();
    }
  }

 

  create() {
    this.entity_class.addRow();
    console.log("After create: ", this.entity_class.form);
    console.log("After create: ", this.entity_class.tableRowArray.controls);
    this.disablefunction()
    console.log( "created_at22222", this.entity_class)
    // let inserted_element = this.entity_class.tableRowArray.at(this.entity_class.tableRowArray.length - 1);
    // this.inserted_values.push({ ...inserted_element.value });
  }

  delete(index: number) {
    let deleted_element = this.entity_class.tableRowArray.at(index);
    if (deleted_element.get('id')) {
      this.deleted_values.push({ ...deleted_element.value });
    }

    this.entity_class.deleteRow(index);
  }

  saveTableParts(data: { detailId: number }) {
    console.log("Save table parts: ", this.entity_class.tableRowArray.value);
    let observable_arr = [];
    let insert_values = this.entity_class.tableRowArray.value.filter(v => v.id == null).map(e => { return {...e, ind_plan_id: data.detailId } });
    let updated_values = this.entity_class.tableRowArray.value.filter(v => v.id != null);

    if (insert_values.length > 0) {
      observable_arr.push(this.dbQueryService.insertTable(this.entity_code, insert_values));
    } if (this.deleted_values.length > 0) {
      observable_arr.push(this.dbQueryService.deleteBulk(this.entity_code, this.deleted_values));
    } if (updated_values.length > 0) {
      observable_arr.push(this.dbQueryService.updateTable(this.entity_code, updated_values));
    }

    forkJoin(observable_arr)
      .subscribe((resp) => {
        let hasError = [];
        resp.forEach(r => {
          if (r['error']) {
            hasError.push(r['error_text']);
          }
        });

        if (hasError.length == 0) {
          // this.mainService.toastSuccess("Табличная часть успешно обновлено!");
        } else {
          this.mainService.toastError(hasError.join("\n"));
        }
      });
  }

  ngOnDestroy() {
    this.commandSub.unsubscribe();
  }


}

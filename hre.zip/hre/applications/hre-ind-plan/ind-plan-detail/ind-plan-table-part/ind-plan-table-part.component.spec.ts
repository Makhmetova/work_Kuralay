import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IndPlanTablePartComponent } from './ind-plan-table-part.component';

describe('IndPlanTablePartComponent', () => {
  let component: IndPlanTablePartComponent;
  let fixture: ComponentFixture<IndPlanTablePartComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IndPlanTablePartComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(IndPlanTablePartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

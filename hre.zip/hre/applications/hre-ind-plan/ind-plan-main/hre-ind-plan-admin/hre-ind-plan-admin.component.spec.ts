import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HreIndPlanAdminComponent } from './hre-ind-plan-admin.component';

describe('HreIndPlanAdminComponent', () => {
  let component: HreIndPlanAdminComponent;
  let fixture: ComponentFixture<HreIndPlanAdminComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HreIndPlanAdminComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HreIndPlanAdminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

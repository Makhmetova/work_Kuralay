import { Component, ComponentRef, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PureDetailFormComponent } from '@app/_components/PureDetailForm/pureDetailForm.component';
import { QueryOptions } from '@app/_models';
import { IFormOptions } from '@app/_models/common';
import { AccountService, DbQueryService } from '@app/_services';
import { BuilderSerice } from '@app/_services/builder.service';
import { ComponentPoolService } from '@app/_services/componentPool.service';
import { take } from 'rxjs/operators';
import { StepInfoComponent } from '../../../step-info/step-info.component';
import { PureInfoBlockComponent } from '@app/_components/PureInfoBlock/pureInfoBlock.component';

@Component({
  selector: 'app-hre-ind-plan-admin',
  templateUrl: './hre-ind-plan-admin.component.html',
  styleUrls: ['./hre-ind-plan-admin.component.less']
})
export class HreIndPlanAdminComponent implements OnInit {
  display: boolean;
  infoUser: Object;
  detailIsOpen: boolean;
  userId: string;
  user: Object;
  @ViewChild('detailFormHolder', { read: ViewContainerRef })
  detailFormHolder: ViewContainerRef;
  sessionRoles: Object;

  constructor(private accountService: AccountService,
    private factory: BuilderSerice,
    private pool: ComponentPoolService,
    private network: DbQueryService,) { }

  ngOnInit(): void {
    this.sessionRoles = this.accountService.sessionRoles;
    this.accountService.getSession().subscribe((res) => {
      this.userId = res.sessioninfo['id'];
      this.user = res.sessioninfo;
      //this.buildStatus();
    });
  }
  openDetail(data) {
    if (data == undefined) { data = {}; data['id'] = 0, data['created_by'] = this.user['id']};
    console.log("Detail is open", data)
//data['title'] + '_requests';
    let tableForOrders: string = data['title'] + '_orders';
    let tableForRequests: string = data['title'] + '_requests';
    let tableForFiles: string ='hre_ind_plan_files';
    let linkField = 'hre_ind_plan_id';
    this.network
      .executeQuery(`code=users&flt$id$eq$=${data.created_by}`, 'get')
      .pipe(take(1))
      .subscribe((res) => {
        this.infoUser = res.items[0];
      });
    this.network
      .getDetail('hre_ind_plan', data['id'])
      .subscribe((det) => {
        let detail = det["hre_ind_plan"][0];
        this.detailFormHolder.clear();
        this.detailIsOpen = true;
        console.log('Out', data);


        let FilesSelectQueryOptions = new QueryOptions(tableForFiles);
        FilesSelectQueryOptions.flteq = {
          [linkField]: data['id'],
        };
        let timelineQueryOptions = new QueryOptions(
          'req_statuses_lookups_step'
        );
        timelineQueryOptions.flteq = {
          parent_lookup: 17,
        };
        let ordersOptions = new QueryOptions(tableForOrders);
        ordersOptions.flteq = {
          entity_pk: data['id'],
        };
        let requestOptions = new QueryOptions(tableForRequests);
        requestOptions.flteq = {
          entity_pk: data['id'],
        };
        let _comp = this.pool.getComponentsType('tables', "hre_ind_plan", true);
        let FormOptions: IFormOptions = {
          showApproveForm: true,
          showCommentsForm: true,
          showFilesForm: true,
          showHistoryForm: true,
          showTimeline: true,
          showOrdersForm: false,
          showInfoBlock: true,
          formComponent: _comp,
          mainFormOptions: {},
          formComponentParams: {
            detailId: data['id'],
            user: this.user,
          },
          approveOptions: {
            showButtons: false,
            showApproveButtons: false,
            useUsersFilter: true,
            useDefaultPreSettings: false,
          },
          filesOptions: {
            multiple: true,
            tableToSave: tableForFiles,
            FilesSelectQueryOptions: FilesSelectQueryOptions,
            fieldForLink: linkField,
            saveHistory: true,
          },

          ordersOptions: {
            tableForRequests: tableForOrders,
            tableForOrders: tableForRequests,
            ordersOptions: requestOptions,
            requestsOptions: requestOptions,
            useRest: true,
            requestsLinkField: 'entity_pk',
            ordersLinkField: 'entity_pk'

          },
          infoBlockOptions: {
            verticalInfoBlock: true,
            InfoBlockComponent: PureInfoBlockComponent,
            InfoBlockParams: {
              
            },
          },
          timelineOptions: {
            useCustomTimeline: true,
            customTimelineComponent: StepInfoComponent,
            customTimelineOptions: {
              inputParams: {
                detail: detail,
                table_name: 'hre_ind_plan'
              },
            },
            defaultTimelineOptions: {
              statusesLookupQuery: timelineQueryOptions,
            },
          },
        };
        console.log('Form done', FormOptions);

        let compRef: ComponentRef<any>;
        compRef = this.factory.MountComponent(
          this.detailFormHolder,
          PureDetailFormComponent,
          {
            FormOptions: FormOptions,
            table_name: "hre_ind_plan",
            id: data['id'],
            user: this.user,
            title: '',
          }
        );
        compRef.instance.onClose.subscribe((val) => {
          this.detailFormHolder.clear();
          this.detailIsOpen = false;
        });
      });
  }
}

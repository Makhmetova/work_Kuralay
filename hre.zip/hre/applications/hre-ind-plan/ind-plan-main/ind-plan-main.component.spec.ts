import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IndPlanMainComponent } from './ind-plan-main.component';

describe('IndPlanMainComponent', () => {
  let component: IndPlanMainComponent;
  let fixture: ComponentFixture<IndPlanMainComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IndPlanMainComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(IndPlanMainComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

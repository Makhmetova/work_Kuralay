import { formatDate, Location } from '@angular/common';
import { Component, ComponentRef, Input, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AccountService, DbQueryService } from '@app/_services';
import { BuilderSerice } from '@app/_services/builder.service';
import { MainService } from '@app/_services/main.service';
import { filter, take } from 'rxjs/operators';
import { EventEmitter } from 'events'
import { QueryOptions } from '@app/_models';
import { IFormOptions } from '@app/_models/common';
import { PureDetailFormComponent } from '@app/_components/PureDetailForm/pureDetailForm.component';
import { ComponentPoolService } from '@app/_services/componentPool.service';
import { InitiatorInfoComponent } from '../../initiator-info/initiator-info.component';
import { StepInfoComponent } from '../../step-info/step-info.component';
import { EntityListTableComponent } from '@app/_components/entity-list-table/entity-list-table.component';
import { IColumns } from '@app/business/toir/_models/ToirModels';
@Component({
  selector: 'app-ind-plan-main',
  templateUrl: './ind-plan-main.component.html',
  styleUrls: ['./ind-plan-main.component.less']
})
export class IndPlanMainComponent implements OnInit {

  entity_code: string = 'hre_ind_plan';
  detailIsOpen: boolean;
  detailId: number;
  details: any;
  userId: string;
  user: Object;
  @Input() detail: Object;
  emitter: EventEmitter<any>;
  doStart = new EventEmitter<Object>();
  doAction = new EventEmitter<Object>();
  tasks: Array<Object>;
  currentTask: Object;
  approve_res: Array<Object>;
  dispatcher: EventEmitter;
  display: boolean;
  infoUser: Object;
  ipr: Array<Object>;
  iprAll: Array<Object>;
  fields: Array<Object>;
  perPage: number = 10;
  rowsPerPageOptions: number;
  @ViewChild('detailFormHolder', { read: ViewContainerRef })
  detailFormHolder: ViewContainerRef;
  @ViewChild('admin', { read: ViewContainerRef })
  admin: ViewContainerRef;
  @Input() parentEmitter: EventEmitter;
  currentPage='';
  constructor(
    private location: Location,

    private mainService: MainService,
    private accountService: AccountService,
    private factory: BuilderSerice,
    private route: ActivatedRoute,
    private pool: ComponentPoolService,
    private network: DbQueryService,
  ) {
    this.emitter = new EventEmitter();
    this.detail = {};
    this.detailIsOpen = false;
    this.dispatcher = new EventEmitter;

    this.fields = [
      { title: 'Отправитель', alias: 'created_by$', checked: true },
      { title: 'Номер', alias: 'code', checked: true },
      { title: 'Дата создания', alias: 'created_at', checked: true },
      { title: 'Наименование', alias: 'title', checked: true },
      { title: 'Статус', alias: 'status_hr$', checked: true },
    ];
  }


  ngOnInit(): void {
    // this.route.params.subscribe((params) => {
    //   this.detailId = Number(params['id']);
    //   console.log(this.detailId);
    // })
    console.log(this.detailId);
    if (this.detailId) {
      this.getDetails(this.detailId);
    } else {
      this.accountService.getSession().subscribe((res) => {
        this.userId = res.sessioninfo['id'];
        this.user = res.sessioninfo;
        //this.buildStatus();
      });

    }


    this.network.executeQuery(`code=hre_ind_plan_all`,'get').subscribe(res => {
      if (res.items && res.items.length >0) {
        this.iprAll = res.items;
        this.ipr = res.items;
      }
    })
  }
  openAdminTab() {
    this.currentPage='admin';
  }
  openArchieveTab(){
    this.currentPage='';
  }
  openMain() {
    this.currentPage='';
  }
  openDetail(data) {
    if (data == undefined) { data = {}; data['id'] = 0, data['created_by'] = this.user['id']};
    console.log("Detail is open", data)
//data['title'] + '_requests';
    let tableForOrders: string = data['title'] + '_orders';
    let tableForRequests: string = data['title'] + '_requests';
    let tableForFiles: string ='hre_ind_plan_files';
    let linkField = 'hre_ind_plan_id';
    this.network
      .executeQuery(`code=users&flt$id$eq$=${data.created_by}`, 'get')
      .pipe(take(1))
      .subscribe((res) => {
        this.infoUser = res.items[0];
      });
    this.network
      .getDetail('hre_ind_plan', data['id'])
      .subscribe((det) => {
        let detail = det["hre_ind_plan"][0];
        this.detailFormHolder.clear();
        this.detailIsOpen = true;
        console.log('Out', data);


        let FilesSelectQueryOptions = new QueryOptions(tableForFiles);
        FilesSelectQueryOptions.flteq = {
          [linkField]: data['id'],
        };
        let timelineQueryOptions = new QueryOptions(
          'req_statuses_lookups_step'
        );
        timelineQueryOptions.flteq = {
          parent_lookup: 17,
        };
        let ordersOptions = new QueryOptions(tableForOrders);
        ordersOptions.flteq = {
          entity_pk: data['id'],
        };
        let requestOptions = new QueryOptions(tableForRequests);
        requestOptions.flteq = {
          entity_pk: data['id'],
        };
        let _comp = this.pool.getComponentsType('tables', "hre_ind_plan", true);
        let FormOptions: IFormOptions = {
          showApproveForm: true,
          showCommentsForm: true,
          showFilesForm: true,
          showHistoryForm: true,
          showTimeline: true,
          showOrdersForm: false,
          showInfoBlock: true,
          formComponent: _comp,
          mainFormOptions: {},
          formComponentParams: {
            detailId: data['id'],
            user: this.user,
          },
          approveOptions: {
            showButtons: false,
            showApproveButtons: false,
            useUsersFilter: true,
            useDefaultPreSettings: false,
          },
          filesOptions: {
            multiple: true,
            tableToSave: tableForFiles,
            FilesSelectQueryOptions: FilesSelectQueryOptions,
            fieldForLink: linkField,
            saveHistory: true,
          },

          ordersOptions: {
            tableForRequests: tableForOrders,
            tableForOrders: tableForRequests,
            ordersOptions: requestOptions,
            requestsOptions: requestOptions,
            useRest: true,
            requestsLinkField: 'entity_pk',
            ordersLinkField: 'entity_pk'

          },
          infoBlockOptions: {
            verticalInfoBlock: true,
            InfoBlockComponent: InitiatorInfoComponent,
            InfoBlockParams: {
              userId: data['created_by'],
              detail: detail,
            },
          },
          timelineOptions: {
            useCustomTimeline: true,
            customTimelineComponent: StepInfoComponent,
            customTimelineOptions: {
              inputParams: {
                detail: detail,
                table_name: 'hre_ind_plan'
              },
            },
            defaultTimelineOptions: {
              statusesLookupQuery: timelineQueryOptions,
            },
          },
        };
        console.log('Form done', FormOptions);

        let compRef: ComponentRef<any>;
        compRef = this.factory.MountComponent(
          this.detailFormHolder,
          PureDetailFormComponent,
          {
            FormOptions: FormOptions,
            table_name: "hre_ind_plan",
            id: data['id'],
            user: this.user,
            title: '',
          }
        );
        compRef.instance.onClose.subscribe((val) => {
          this.detailFormHolder.clear();
          this.detailIsOpen = false;
        });
      });
  }


  getDetails(id: number) {
    let query = this.network
      .getDetail(this.entity_code, id)
      .subscribe((res) => {
        if (res) {
          this.details = res;
          this.detail = res[this.entity_code][0];
          this.userId = res[this.entity_code][0]['created_by'];
          this.detailId = res[this.entity_code][0]['id'];
          // this.network
          //   .executeQuery(`code=users&flt$id$eq$=${this.userId}`, 'get')
          //   .pipe(take(1))
          //   .subscribe((res) => {
          //     this.user = res.items[0];

          //   });


          let approveRes: any;
          // approveRes = this.factory.MountComponent(
          //   this.approveFormHolder,
          //   PureApproveFormComponent,
          //   {
          //     table_name: this.entity_code,
          //     uuid: this.detail['sys$uuid'],
          //     user: this.user,
          //     id: this.detailId,
          //     showButtons: true,
          //     showApproveButtons: true,
          //     parentEmitter: this.emitter,
          //     detail: this.detail,
          //     templateId: 72,
          //   }
          // );

          // approveRes.instance.doStart = this.doStart;
          // approveRes.instance.doAction = this.doAction;
          // approveRes.instance.onTasksLoaded.subscribe(res => {
          //   console.log("OnTasksLOad", res);
          //   this.tasks = res.all_tasks;
          //   this.currentTask = res.tasks.filter(x => x['status_id$code'] == 'opened')[0];
          //   console.log("currennt",this.currentTask);

          //   this.approve_res = res.task_approve_res;

          // })

          // this.factory.MountComponent(this.status, StepInfoComponent, {
          //   table_name: this.entity_code,
          //   id: this.detailId,
          //   detail: this.detail,
          // });
        }
        query.unsubscribe();
      });
  }

  calendarOnSelect(created_at){
    let dueDateTime = formatDate((new Date(created_at)), "yyyy-MM-dd",'ru') ;
    let t = this.ipr.filter((x) => {
      return formatDate((new Date(x['created_at'])), "yyyy-MM-dd",'ru') === dueDateTime;
    });
    this.iprAll = t;
  }
  calendarClear(created_at) {
    created_at = null;
    this.iprAll = this.ipr;
  }

}

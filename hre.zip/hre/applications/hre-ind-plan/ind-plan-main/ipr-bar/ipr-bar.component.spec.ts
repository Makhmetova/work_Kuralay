import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IprBarComponent } from './ipr-bar.component';

describe('IprBarComponent', () => {
  let component: IprBarComponent;
  let fixture: ComponentFixture<IprBarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IprBarComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(IprBarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

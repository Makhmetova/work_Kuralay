import {
  Component,
  ComponentFactoryResolver,
  Input,
  OnInit,
  ViewChild,
  ViewContainerRef,
} from '@angular/core';
import { PrsnaWidget } from '@app/business/prsna/prsna-desktop/prsna-widgets/widget.model';
import { BarChartComponent } from '@app/_components/charts/bar-chart/bar-chart.component';
import { BarChartModel } from '@app/_components/charts/bar-chart/bar-chart.model';
import { QueryOptions } from '@app/_models';
import { AccountService, DbQueryService } from '@app/_services';

@Component({
  selector: 'app-ipr-bar',
  templateUrl: './ipr-bar.component.html',
  styleUrls: ['./ipr-bar.component.less'],
})
export class IprBarComponent implements OnInit {
  instance: any;
  data: BarChartModel;
  @Input() widget: PrsnaWidget;
  user: Object;
  @ViewChild('barChartTemplate', { read: ViewContainerRef }) dataTemplate;
  constructor(
    private _componentFactoryResolver: ComponentFactoryResolver,
    private dbQueryService: DbQueryService,
    private accountService: AccountService
  ) {}

  ngOnInit(): void {
    this.data = {
      widgetId: 1,
      data: [],
    };



    this.accountService.getSession().subscribe((res) => {
      this.user = res.sessioninfo;
      console.log("User", this.user);
      this.bindData();
      //this.buildStatus();
    });

  }

  bindData() {
    let options = new QueryOptions('hre_ind_plan_by_status');
    // let query = this.dbQueryService.getQuery(options).subscribe((res) => {
    //   if (res.items) {
    //     this.data.data = [];
    //     let finded = res.items;
    //     console.log('find', finded);
    //     if (finded) {
    //       finded.forEach((x) => {
    //         this.data.data.push({
    //           category: x['task_status$'],
    //           value: x['count'],
    //         });
    //       });
    //     }

    //   }

      this.dbQueryService.restapiPost("hre_ind_for_dash", {company_id: this.user['company_id']}).subscribe(res => {
        let deps = res['deps'];
        let users = res['users'];
        let ind = res['ind'];
        this.data.data.push({
          category: "Количество подразделений",
          value: deps[0]['number'],
        });
        this.data.data.push({
          category: "Количество сотрудников",
          value: users[0]['number'],
        });
        ind.forEach((x) => {
          this.data.data.push({
            category: x['task_status$'],
            value: x['count'],
          });
        });
        this.loadBarChart();
      })

      console.log('TOP', this.data);

     // query.unsubscribe();


    //});
  }
  loadBarChart() {
    // instantiate the component
    if (!this.instance) {
      let componentFactory =
        this._componentFactoryResolver.resolveComponentFactory(
          BarChartComponent
        );
      let componentRef = this.dataTemplate.createComponent(componentFactory);
      this.instance = componentRef.instance;
    }
    // set the props
    this.instance.chartData = this.data;
  }
}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HreIndPlanComponent } from './hre-ind-plan.component';

describe('HreIndPlanComponent', () => {
  let component: HreIndPlanComponent;
  let fixture: ComponentFixture<HreIndPlanComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HreIndPlanComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HreIndPlanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

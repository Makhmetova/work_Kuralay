import { Location } from '@angular/common';
import { Component, ComponentRef, Input, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AccountService, DbQueryService } from '@app/_services';
import { BuilderSerice } from '@app/_services/builder.service';
import { MainService } from '@app/_services/main.service';
import { take } from 'rxjs/operators';
import { StepInfoComponent } from '../step-info/step-info.component';
import { EventEmitter } from 'events'
import { QueryOptions } from '@app/_models';
import { IFormOptions } from '@app/_models/common';
import { InitiatorInfoComponent } from '../initiator-info/initiator-info.component';
import { PureDetailFormComponent } from '@app/_components/PureDetailForm/pureDetailForm.component';
import { ComponentPoolService } from '@app/_services/componentPool.service';
@Component({
  selector: 'app-hre-ind-plan',
  templateUrl: './hre-ind-plan.component.html',
  styleUrls: ['./hre-ind-plan.component.less']
})
export class HreIndPlanComponent implements OnInit {
  detailIsOpen: boolean;
  entity_code: string = "hre_ind_plan";
  detailId: number;
  details: any;
  userId: string;
  user: Object;
  @Input() detail: Object;
  emitter: EventEmitter<any>;
  doStart = new EventEmitter<Object>();
  doAction = new EventEmitter<Object>();
  tasks: Array<Object>;
  currentTask: Object;
  approve_res: Array<Object>;
  dispatcher: EventEmitter;
  display: boolean;
  @ViewChild('detailFormHolder', { read: ViewContainerRef })
  detailFormHolder: ViewContainerRef;
  @Input() parentEmitter: EventEmitter
  constructor(
    private location: Location,
    private dbQueryService: DbQueryService,
    private mainService: MainService,
    private accountService: AccountService,
    private factory: BuilderSerice,
    private route: ActivatedRoute,
    private pool: ComponentPoolService,
  ) { 
    this.emitter = new EventEmitter();
    this.detail = {};
    this.detailIsOpen = false;
    this.dispatcher = new EventEmitter;
  } 

  ngOnInit(): void {
    
    
    this.user = this.accountService.userValue.sessioninfo;
    // this.route.params.subscribe(params => {
    //   this.detailId = Number(params['id']);});

      if (this.detailId) {
        this.getDetails(this.detailId);
      } else {
        this.userId = this.accountService.userValue.id;
        this.details = null;
      }
    
  }
 


  getDetails(id: number) {
    let query = this.dbQueryService.getDetail(this.entity_code, id)
      .subscribe( res => {
        if (res) {
          this.details = res;
          this.userId = res[this.entity_code][0]['created_by'];
        }
        query.unsubscribe();
      });
  }

  back() {
    this.location.back();
  }

}

import { DatePipe } from '@angular/common';
import {
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  SimpleChanges,
} from '@angular/core';
import { FormGroup } from '@angular/forms';
import { AccountService, DbQueryService } from '@app/_services';
import { LookupService } from '@app/_services/lookupService.service';
import { MainService } from '@app/_services/main.service';

@Component({
  selector: 'app-trip-detail-form',
  templateUrl: './trip-detail-form.component.html',
  styleUrls: ['./trip-detail-form.component.less'],
})
export class TripDetailFormComponent implements OnInit {
  @Input() detailId: number;
  entity_code = 'hre_business_trip';
  @Input() details: any;

  @Output() onSave = new EventEmitter<Object>();
  @Output() onClose = new EventEmitter<Object>();
  @Input() onAction = new EventEmitter<Object>();
  @Input() onStart = new EventEmitter<Object>();
  @Output() openRoute = new EventEmitter<Object>();
  sessionRoles: Object;
  user: Object;
  userId: string;
  detail: Object;
  delegators: Array<Object>;
  users: Array<Object>;
  delegate_users;
  entityOneActions: Array<Object>;
  form: FormGroup;
  minimumDate: Date;
  decree_values: Array<Object>;
  onec_start_front: boolean;
  enable: boolean;
  constructor(
    private mainService: MainService,
    private dbQueryService: DbQueryService,
    private accountService: AccountService,
    private lookup: LookupService,
    public datepipe: DatePipe
  ) {
    this.detail = {};
    this.decree_values = [];
    this.onec_start_front = true;
    // this.enable = true;
  }

  ngOnInit(): void {
    this.sessionRoles = {};
    this.accountService.userValue.session_roles.forEach((r) => {
      this.sessionRoles[r.code] = true;
      this.minimumDate = new Date();
    });
    this.sessionRoles = {};
    this.accountService.userValue.session_roles.forEach((r) => {
      this.sessionRoles[r.code] = true;
    });
    this.user = this.accountService.userValue.sessioninfo;
    this.delegators = [];

    this.lookup.getLookup('users_select').subscribe((us) => {
      if (us['items'] && us['items'].length > 0) {
        this.users = us['items'];
      }
    });
    this.detailId == 0 ? (this.enable = false) : (this.enable = true);
    if (
      this.detail['onec_start'] == 'undefined' ||
      this.detail['onec_start'] == null ||
      this.detail['onec_start'] == '0'
    ) {
      this.onec_start_front = true;
    } else {
      this.onec_start_front = false;
    }
    this.entityOneActions = [
      {
        label: 'Отправить в 1С',
        disabled: this.onec_start_front,
        command: () => {
          this.onecSend();
        },
      },
    ];
    if (this.details) {
      let del = this.details['hre_business_delegate'];
      console.log('DEl', del);

      del.forEach((x) => {
        this.accountService.getById(x['delegate_to']).subscribe((value) => {
          console.log(value);
          let tempUs = value['users'][0];
          this.delegators.push(tempUs);
          console.log(this.delegators);
        });
      });

      let length = this.details['hre_business_trip_decree'].length;
      console.log('Length', length);
      length == 0
        ? (this.decree_values = this.details['hre_business_trip_decree'])
        : this.decree_values.push(
            this.details['hre_business_trip_decree'][length - 1]
          );
      console.log('Decree', this.delegators);
    }

    this.onStart.subscribe((res) => {
      this.onClose.emit({});
      this.mainService.toastSuccess('Ваша заявка принята!');
      this.dbQueryService
        .getDetail(this.entity_code, this.detailId)
        .subscribe((resp) => {
          this.delegators.forEach((x) => {
            let params = {
              req_id: resp[this.entity_code][0]['id'],
              delegate_from: resp[this.entity_code][0]['sent_by'],
              delegate_to: x['id'],
            };
            this.dbQueryService
              .insertTable('hre_business_trip_delegat', [params])
              .subscribe((res) => {});
          });
        });
    });
    this.onAction.subscribe((val) => {
      if (val['approve_res_id'] == 1) {
        //soglasovana
        this.dbQueryService
          .bpRun('hre_new_req', {
            entity_code: this.entity_code,
            pk: this.details[this.entity_code][0]['sys$uuid'],
            req_id: this.detailId,
            action: 'approveEnd',
          })
          .subscribe((res) => {});
        this.dbQueryService.bpRun('hre_business_trip', {
          entity_code: 'hre_business_trip',
          pk: this.details[this.entity_code][0]['id'],
          draft: true,
        }).subscribe(res => {

        });
      } else if (val['approve_res_id'] == 2) {
        this.detail['status_id'] = '5';
        this.dbQueryService
          .updateTable(this.entity_code, [this.detail])
          .subscribe((val) => {});
      }
    });
  }

  ngAfterViewInit() {}
  getItemsSelect(code: string, _query?: string, params?: Object) {
    return this.dbQueryService.getQuerySelect(code, _query, 100, params);
  }
  onChangeSwitch(e) {
    if (e.checked == true) {
      this.detail['is_delegate'] = true;
    } else {
      this.detail['is_delegate'] = false;
      this.delegators = [];
    }
  }
  setEndDate(event) {
    this.detail['trip_start_date'] = this.datepipe.transform(
      new Date(event),
      'yyyy-MM-dd'
    );
    console.log('start_date', this.detail['trip_start_date']);
    console.log('Controld', this.form);
    let total = this.detail['day_count'];
    let start = this.detail['trip_start_date'];
    let end = new Date(start);
    end.setDate(end.getDate() + Number(total) - 1);
    this.detail['trip_end_date'] = end;
    this.detail['trip_start_date'] = this.datepipe.transform(
      this.detail['trip_start_date'],
      'yyyy-MM-dd'
    );
    this.detail['trip_end_date'] = this.datepipe.transform(
      this.detail['trip_end_date'],
      'yyyy-MM-dd'
    );

    console.log('AftEEER', this.form.controls);
  }
  addDelegate() {
    let tempUs = {};
    console.log(this.delegate_users);

    this.accountService.getById(this.delegate_users).subscribe((value) => {
      console.log(value);

      tempUs = value['users'][0];
      console.log('ddd', this.delegators.indexOf(tempUs));

      this.delegators.some((x) => x['id'] == tempUs['id']) == true
        ? this.mainService.toastError('Вы уже добавили данного пользователя')
        : this.delegators.push(tempUs);
      console.log(this.delegators);
    });

    this.delegate_users = null;
  }
  delDelegate(user) {
    this.delegators.indexOf(user) > -1
      ? this.delegators.splice(this.delegators.indexOf(user), 1)
      : console.log();
  }
  editForm() {
    this.enable = false;
    console.log('Enable', this.enable);

    this.ngOnInit();
  }

  onecSend() {
    if (this.detail['onec_start'] == 1) {
      this.dbQueryService
        .bpRun('hre_btr_request', {
          id: this.detail['id'],
        })
        .subscribe((res) => {
          if (res['errorText'] == '') {
            this.mainService.toastSuccess('Успешно отправилась в 1С ');
          } else {
            this.mainService.toastWarning('Не удалось отправить в 1С ');
          }
        });
    } else {
      this.mainService.toastWarning('Не удалось отправить в 1С ');
    }
  }

  save() {
    if (this.detailId) {
      this.dbQueryService
        .updateTable(this.entity_code, this.form.getRawValue())
        .toPromise()
        .then((res) => {
          if (res['error']) {
            this.mainService.toastError(res['error_text']);
          } else {
            this.mainService.toastSuccess('Заявка успешно обновлено!');
          }
        });
    } else {
      this.detail['status_id'] = 1;
      this.detail['priority'] = 2;
      this.detail['user_group'] = 1;
      this.detail['stage'] = 14;
      this.detail['stage_id'] = 52;
      this.dbQueryService
        .insertTable(this.entity_code, [this.detail])
        .toPromise()
        .then((res) => {
          if (res['error']) {
            this.mainService.toastError(res['error_text']);
          } else {
            this.detailId = res.items[0]['last_insert_id'];
            this.onSave.emit({
              data: this.detail,
              code: this.entity_code,
              id: this.detailId,
            });
            this.mainService.toastSuccess('Ваша заявка принята!');
            // this.onClose.emit({});
            this.dbQueryService
              .bpRun('hre_new_req', {
                entity_code: this.entity_code,
                pk: res.items[0]['sys$uuid'],
                req_id: res.items[0]['last_insert_id'],
                action: 'new',
              })
              .subscribe((res) => {
                this.openRoute.emit({});
              });
          }
        });
    }
  }
  getDetails(id: number) {
    let query = this.dbQueryService
      .getDetail(this.entity_code, id)
      .subscribe((res) => {
        if (res) {
          this.details = res;
          this.detail = res[this.entity_code][0];
          this.userId = res[this.entity_code][0]['created_by'];

          console.log('Form', this.form);
        }
        query.unsubscribe();
      });
  }
  cancel() {
    this.onClose.emit({});
  }

  ngOnDestroy() {}
}

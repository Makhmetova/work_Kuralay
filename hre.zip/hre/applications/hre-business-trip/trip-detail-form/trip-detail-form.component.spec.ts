import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TripDetailFormComponent } from './trip-detail-form.component';

describe('TripDetailFormComponent', () => {
  let component: TripDetailFormComponent;
  let fixture: ComponentFixture<TripDetailFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TripDetailFormComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TripDetailFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

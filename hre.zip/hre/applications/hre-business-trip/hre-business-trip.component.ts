import { Location } from '@angular/common';
import { Component, EventEmitter, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { RunTaskResponse } from '@app/_models';
import { APPROVE_RESULT } from '@app/_models/commands';
import { AccountService, DbQueryService } from '@app/_services';
import { MainService } from '@app/_services/main.service';

@Component({
  selector: 'app-hre-business-trip',
  templateUrl: './hre-business-trip.component.html',
  styleUrls: ['./hre-business-trip.component.less']
})
export class HreBusinessTripComponent implements OnInit {

  entity_code: string = "hre_busines_trip";
  detailId: number;
  details: any;
  userId: string;
  user: Object;

  emitter: EventEmitter<any>;

  displayEdsModal: boolean = false;
  task_manager_id: number;

  constructor(
    private location: Location,
    private dbQueryService: DbQueryService,
    private mainService: MainService,
    private accountService: AccountService,
    private route: ActivatedRoute
  ) {
    this.emitter = new EventEmitter();
  }

  ngOnInit(): void {
    this.user = this.accountService.userValue.sessioninfo;
    this.route.params.subscribe(params => {
      this.detailId = Number(params['id']);

      if (this.detailId) {
        this.getDetails(this.detailId);
      } else {
        this.userId = this.accountService.userValue.id;
        this.details = null;
      }
    });
  }

  getDetails(id: number) {
    let query = this.dbQueryService.getDetail(this.entity_code, id)
      .subscribe( res => {
        if (res) {
          this.details = res;
          this.userId = res[this.entity_code][0]['created_by'];
        }
        query.unsubscribe();
      });
  }
  bpRun(code: string, input: any) {
    this.dbQueryService.bpRun(code, input)
      .subscribe((resp: RunTaskResponse) => {
        console.log(code + ": ", resp);
        if(resp.ok) {
          if(resp.instanceIsFinished) {
              if(!resp.output.last_error) {
                  this.mainService.toastSuccess('Успешно');
                  this.getDetails(this.detailId);
              } else {
                  this.mainService.toastError(resp.output.last_error);
              }
          } else if(resp.task){
              // this.openBpModal();
              // this.getUserTaskData(resp.task);
          } else {
              this.mainService.toastInfo('BPM Run', 'Процесс запущен.');
          }
        } else {
          this.mainService.toastError('Ошибка! Что-то пошло не так.');
        }

        this.displayEdsModal = false;
      });
  }

  back() {
    this.location.back();
  }

}

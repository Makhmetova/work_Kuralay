import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OrderForPaymentComponent } from './order-for-payment.component';

describe('OrderForPaymentComponent', () => {
  let component: OrderForPaymentComponent;
  let fixture: ComponentFixture<OrderForPaymentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OrderForPaymentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OrderForPaymentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

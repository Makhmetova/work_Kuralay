import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HreBusinessTripComponent } from './hre-business-trip.component';

describe('HreBusinessTripComponent', () => {
  let component: HreBusinessTripComponent;
  let fixture: ComponentFixture<HreBusinessTripComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HreBusinessTripComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HreBusinessTripComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

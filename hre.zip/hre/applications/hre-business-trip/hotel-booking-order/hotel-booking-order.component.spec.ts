import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HotelBookingOrderComponent } from './hotel-booking-order.component';

describe('HotelBookingOrderComponent', () => {
  let component: HotelBookingOrderComponent;
  let fixture: ComponentFixture<HotelBookingOrderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HotelBookingOrderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HotelBookingOrderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BusinessTripOrderComponent } from './business-trip-order.component';

describe('BusinessTripOrderComponent', () => {
  let component: BusinessTripOrderComponent;
  let fixture: ComponentFixture<BusinessTripOrderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BusinessTripOrderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BusinessTripOrderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

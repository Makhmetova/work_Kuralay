import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { DbQueryService, MainService } from '@app/_services';

@Component({
  selector: 'app-business-trip-order',
  templateUrl: './business-trip-order.component.html',
  styleUrls: ['./business-trip-order.component.less'],
})
export class BusinessTripOrderComponent implements OnInit {
  detail: Object;
  table = 'hre_bor';
  sent_by: Object;
  dec_id: number;
  decree_values = [];
  id: number;
  @Output() openRoute = new EventEmitter<Object>();
  @Output() onSave = new EventEmitter<Object>();
  @Output() onClose = new EventEmitter<Object>();
  @Output() onAction = new EventEmitter<Object>();
  @Output() onStart = new EventEmitter<Object>();

  constructor(private network: DbQueryService, private main: MainService) {
    this.dec_id = null;
  }

  ngOnInit(): void {
    console.log('THISSS', this);
    if (this['parentDetail']) {
      this.detail['sender'] = this['parentDetail']['sent_by'];
      this.detail['city'] = this['parentDetail']['city'];
      this.detail['company'] = this['parentDetail']['company'];
      this.detail['day_count'] = this['parentDetail']['day_count'];
      this.detail['trip_start_date'] = this['parentDetail']['trip_start_date'];
      this.detail['trip_end_date'] = this['parentDetail']['trip_end_date'];
      this.detail['purpose'] = this['parentDetail']['purpose'];
      this.dec_id = this['parentDetail']['decree_id'];
      this.id = this['parentDetail']['id'];
      this.getDecree();
    } else {
      this.network
        .getDetail('hre_business_trip', this.detail['parent_id'])
        .subscribe((res) => {
          let det = res['hre_business_trip'][0];
          this.id = det['id'];
          this.dec_id = det['decree_id'];
          this.getDecree();
        });
    }
    this.network
      .executeQuery(`code=users&flt$id$eq$=${this.detail['sender']}`, 'get')
      .subscribe((res) => {
        this.sent_by = res.items[0];
        console.log(this.sent_by);
      });
    this.onStart.subscribe((res) => {
      this.main.toastSuccess('Заказ успешно отправлен!');
      this.onClose.emit({});
    });

    this.onAction.subscribe((val) => {
      console.log('Arrrr', val);

      if (val['approve_res_id'] == 5) {
        //soglasovana
        this.network
          .bpRun('hre_business_trip', {
            entity_code: 'hre_business_trip',
            pk: this.detail['parent_id'],
            ord_id: this.detail['id'],
            ord_uuid  : this.detail['sys$uuid'],
            draft: false
          })
          .subscribe((res) => {
            //this.decree_id = res['output']['decree_id'];
            this.network
              .bpRun('hre_update_order', {
                entity_code: this.table,
                req_id: this.detail['id'],
                status_id: 4,
              })
              .subscribe((res) => {
              });
          });
      } else if (val['approve_res_id'] == 2) {
        this.network
          .bpRun('hre_update_order', {
            entity_code: this.table,
            req_id: this.detail['id'],
            status_id: 5,
          })
          .subscribe((res) => {});
      }
    });
  }
  getDecree() {
    this.network
      .executeQuery(
        `code=hre_business_trip_decree&flt$entity_pk$eq$=${this.id}&flt$id$eq$=${this.dec_id}`,
        'get'
      )
      .subscribe((res) => {
        this.decree_values = res.items;
      });
  }
  send() {
    this.detail['status_id'] = 1;
    this.detail['priority'] = 2;
    // this.detail['stage'] = 14; //stage
    // this.detail['stage_id'] = 52;
    this.detail['req_code'] = 'hre_business_trip';

    this.network.insertTable(this.table, [this.detail]).subscribe((res) => {
      console.log(res);
      this.onSave.emit({
        data: this.detail,
        code: this.table,
        id: res.items[0]['last_insert_id'],
      });
      this.network
        .getDetail('hre_bor', res.items[0]['last_insert_id'])
        .subscribe((res) => {
          this.openRoute.emit({});
        });
    });
  }
  cancel() {
    this.onClose.emit({});
  }
}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RequestDetailFormComponent } from './request-detail-form.component';

describe('RequestDetailFormComponent', () => {
  let component: RequestDetailFormComponent;
  let fixture: ComponentFixture<RequestDetailFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RequestDetailFormComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RequestDetailFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, EventEmitter, Input, OnInit, Output, ViewChild, ViewContainerRef } from '@angular/core';
import { Router } from '@angular/router';
import { RunTaskResponse, User } from '@app/_models';
import { HRE_APPLICATIONS } from '@app/_models/commands';
import { AccountService, DbQueryService } from '@app/_services';
import { BuilderSerice } from '@app/_services/builder.service';
import { MainService } from '@app/_services/main.service';
import { ConfirmationService } from 'primeng/api';

@Component({
  selector: 'app-request-detail-form',
  templateUrl: './request-detail-form.component.html',
  styleUrls: ['./request-detail-form.component.less']
})
export class RequestDetailFormComponent implements OnInit {

  @ViewChild('approveFormHolder', { read: ViewContainerRef }) approveFormHolder: ViewContainerRef;

  @Input() rowData: any;
  @Output() onClose = new EventEmitter<any>();

  request: any;
  details: any;
  detail: any;
  decree: any;
  entity_code: string;
  executors: any[] = [];
  statuses: any[] = [];
  sessionRoles: Object;
  user: User;
  edited: Object = {};

  bp_input: { id: number; entity_code: string; pk: number; is_birthplace?: boolean };

  constructor(
    private mainService: MainService,
    private dbQueryService: DbQueryService,
    private accountService: AccountService,
    private confirmationService: ConfirmationService,
    private factory: BuilderSerice) { }

  ngOnInit(): void {
    this.sessionRoles = {};
    this.user = this.accountService.userValue;
    this.user['session_roles'].forEach(r => {
      this.sessionRoles[r.code] = true;
    });

    this.getItemsSelect("users_select_by_roles", "", { param1: 'hr_manager' }).toPromise()
    .then((res) => {
      this.executors = res.items;
      return this.getItemsSelect("hre_application_status_select", "").toPromise();
    }).then((res) => {
      this.statuses = res.items;
      this.entity_code = this.rowData.title;
      this.getDetails(this.rowData);
    });

  }

  getDetails(rowData: any) {
    this.dbQueryService.getDetail(this.entity_code, rowData.id)
      .subscribe( res => {
        if (res) {
          this.details = res;
          this.detail = res[this.entity_code][0];
          this.request = res[this.entity_code.concat('_requests')].find(rq => rq.code == rowData.rq_code);
          this.decree = res[this.entity_code.concat('_decree')][res[this.entity_code.concat('_decree')].length - 1];
        }
      })
  }

  getItemsSelect(code: string, _query?: string, params?: Object) {
    return this.dbQueryService.getQuerySelect(code, _query, 100, params);
  }

  edit(attr: string) {
    this.edited[attr] = true;
  }

  save() {
    if (this.edited['status_id']) {
      this.updateRequest();
    }

    if (this.edited['manager_id']) {
      this.updateTask();
    }
  }

  updateRequest() {
    this.dbQueryService.updateTable(this.entity_code.concat("_requests"), [{ id: this.request.id, status_id: this.request.status_id }])
      .subscribe(res => {
        if(!res['error']) {
          this.mainService.toastSuccess("Статус успешно обновлен!");
        }
        console.log("Update request: ", res);
      });
  }

  updateTask() {
    this.dbQueryService.updateTable("tasks", [ {id: this.request.task_id, manager_id: this.request.manager_id} ])
      .subscribe(res => {
        if(!res['error']) {
          this.mainService.toastSuccess("Успешно назначено!");
        }
        console.log("Update task: ", res);
      })
  }

  completeRequest() {
    this.bp_input = {
      id: this.request.task_id,
      entity_code: this.entity_code,
      pk: this.detail.id
    };

    if (this.entity_code == HRE_APPLICATIONS.BUSINESS_TRIP && this.request.role_code == 'hr_manager') {
      this.confirmationService.confirm({
        message: 'Командировка на месторождение?',
        header: '',
        icon: 'pi pi-exclamation-triangle',
        accept: () => {
          this.bp_input.is_birthplace = true;
          this.bp_run();
        },
        reject: (type) => {
          this.bp_input.is_birthplace = false;
          this.bp_run();
        }
      });
    } else {
      this.bp_run();
    }
  }

  bp_run() {
    this.dbQueryService.bpRun(this.request['bp_process'], this.bp_input)
      .subscribe((resp: RunTaskResponse) => {
        console.log("Complete request: ", resp);
        if(resp.ok) {
          if(resp.instanceIsFinished) {
              if(!resp.output.last_error) {
                  this.mainService.toastSuccess('Успешно завершен.');
              } else {
                  this.mainService.toastError(resp.output.last_error);
              }
          } else if(resp.task){
              // this.openBpModal();
              // this.getUserTaskData(resp.task);
          } else {
              this.mainService.toastInfo('BPM Run', 'Процесс запущен.');
          }
        } else {
          this.mainService.toastError('Ошибка! Что-то пошло не так.');
        }
      });
  }

  cancel() {
    this.onClose.emit(true);
  }

  ngOnDestroy() {
  }
}

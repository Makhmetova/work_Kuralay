import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-requests',
  templateUrl: './requests.component.html',
  styleUrls: ['./requests.component.less']
})
export class RequestsComponent implements OnInit {

  @Input() request_values: any[];

  constructor() { }

  ngOnInit(): void {
  }

}

import { DatePipe } from '@angular/common';
import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges } from '@angular/core';
import { RunTaskResponse } from '@app/_models';
import { EntityClass } from '@app/_models/entity';
import { AccountService, DbQueryService } from '@app/_services';
import { MainService } from '@app/_services/main.service';

@Component({
  selector: 'app-idea-detail',
  templateUrl: './idea-detail.component.html',
  styleUrls: ['./idea-detail.component.css']
})
export class IdeaDetailComponent implements OnInit {

  // @Input() entity_code: string = "hre_idea_center";
  details: any;
  @Output() onClose = new EventEmitter<Object>()
  @Output() onSend = new EventEmitter<Object>()
  @Output() onSave = new EventEmitter<Object>()
  @Output() openRoute = new EventEmitter<Object>()
  @Output() doStart = new EventEmitter<Object>();
  @Output() doAction = new EventEmitter<Object>();
  @Output() doSave = new EventEmitter<Object>();
  @Output() doReload = new EventEmitter<Object>();
  @Output() onStatusChanged = new EventEmitter<Object>();
  @Output() onUpdate = new EventEmitter<Object>();
  @Input() onAction = new EventEmitter<Object>();
  @Output() onTasksLoaded = new EventEmitter<Object>();
  @Input() onStart = new EventEmitter<Object>();
  title:string;
  entity_code:any;
  entity_class: EntityClass;
  categories: any[] = [];
  priorities: any[] = [];
  executors: any[] = [];
  statuses: any[] = [];
  sessionRoles: Object;
  reqTitle:any;
  id:any;
  user:any;
  detailItem:any;
  suid:any;
  newDetail:any;
  hr_managers:any[] = [];
  date14:any;
  isCreated:any;
  isSaved:boolean;
  isAgreed:boolean=false;
  isSended:boolean;
  isExecutor:boolean;
  isSender:boolean;
  status_ice:number=0;
  firstSaved:boolean=false;
  cur_user_get:any;
  isEditing:boolean;
  dateDue:any;
  dateAdded:boolean;
  isNew:boolean;
  tehe:any;
  maxYear:any;
  minYear:any;
  rangeY:any;
  approveId:any;
  currentTime:any;
  new_detail:Object[]=[];
  detailId:number;
  detail: Object;
  constructor(
    private mainService: MainService,
    private dbQueryService: DbQueryService,
    private accountService: AccountService,
    public datepipe: DatePipe
  ) {
    this.isSaved=false;
    this.dateAdded=false;
    this.currentTime = new Date();
    this.dateDue=this.datepipe.transform(this.currentTime, 'dd.mm.yy');
    this.minYear=(this.currentTime.getFullYear()).toString();
    console.log("cur year",this.minYear);
    this.maxYear= new Date(this.currentTime.setFullYear(this.currentTime.getFullYear()+30)).getFullYear().toString();

   }

  ngOnInit(): void {
    console.log("id",this.detailId)
    console.log("detial",this.detail);
    console.log("detials",this.details);
    console.log("cur date + executor",this.dateDue,this.isExecutor);
    this.sessionRoles = this.accountService.sessionRoles;
    this.user = this.accountService.userValue.sessioninfo;

    // this.checkExecutor(this.sessionRoles,this.approveId);
    console.log(this.id,this.isSender,this.isExecutor,this.status_ice,this.cur_user_get);
    // this.entity_class.form.controls['approve_start'].setValue(0)
      this.onStart.subscribe(res => {
        console.log(res,"ans")
          this.bpRun('hre_idea_bp', {
            id : this.id,
            entity_code : this.entity_code,
            user : this.cur_user_get['id'],
          });
          this.status_ice=2;
          this.onClose.emit({})

        console.log("getrawvalue", this.entity_class.form.getRawValue());


        // this.entity_class.form.controls['approve_start'].setValue('true');
        // this.detail['approve_start'] = 1
        // this.detail['req_title'] = 'tupoooi'
        // //req_title
        // this.dbQueryService.updateTable(this.entity_code, [this.detail])
        //   .subscribe(res => {
        //     console.log("update",res)
        //   });

         console.log("start", this.entity_class.form.controls['approve_start']);
      })
    this.onAction.subscribe(val=>{
      console.log("on action value",val);
        if (val['approve_res_id'] == 1) {
            this.bpRun('hre_idea_bp_accept', {
              id : this.id,
              entity_code : this.entity_code,
              user : this.cur_user_get['id']
            });
            this.status_ice=3;
        } else if (val['approve_res_id'] == 2) {
          this.bpRun('hre_idea_bp_decline', {
            id : this.id,
            entity_code : this.entity_code,
            user : this.cur_user_get['id']
          });
          this.status_ice=5;
        }
    })
    this.getItemsSelect("users_select_by_roles", "", { param1: 'hr_manager' }).toPromise()
      .then((res) => {
        this.hr_managers = res.items;
        return this.getItemsSelect("core_status_select", "").toPromise();
      }).then((res) => {
        this.statuses = res.items;
        return this.getItemsSelect("hre_idea_category_select", "").toPromise();
      }).then((res) => {
        this.categories = res.items;
        return this.getItemsSelect("core_priority_select", "").toPromise();
      }).then((res) => {
        this.priorities = res.items;
        this.getEntityAttrs(this.entity_code);
      });
    }

  ngAfterViewInit() {
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.details && this.entity_class) {
      this.bind();
    }
  }

  bind() {
    this.entity_class.form = this.entity_class.createForm();
    if (this.details) {
      if(this.detail['status_id'] == '2'){
         this.entity_class.form.disable();

      }
      this.entity_class.bindForm(this.entity_class.form, this.details[this.entity_code][0]);
     this.firstSaved = true;
      // this.entity_class.form.controls['due_date'].enable()
      this.checkExecutor(this.user,this.entity_class.form.controls['category'].value);
    }
  }

  getEntityAttrs(code: string) {
    this.dbQueryService.getEntityAttrsByCode(code)
      .subscribe( res => {
        if (res.items) {
          this.entity_class = new EntityClass(this.entity_code);
          this.entity_class.setEntityAttrs(res.items);
          this.bind();
        }
      })
  }

  getItemsSelect(code: string, _query?: string, params?: Object) {
    return this.dbQueryService.getQuerySelect(code, _query, 100, params);
  }

  getNewDetail(detail_id:number){
    this.dbQueryService.getDetail(this.entity_code, detail_id)
      .subscribe(resp=>{
        this.new_detail=resp[this.entity_code][0];
      })
  }
  checkExecutor(user:object, approveId:any){
    this.dbQueryService.restapiPost("get_idea_executor",{user_id:user['id'],approve_id:approveId}).subscribe(rrt=>{
      console.log("check save",user, approveId,rrt);
      if((rrt['items'][1] && rrt['items'][1]['is_executor']=="0") || rrt['items']['is_executor']=="0"  || (rrt['items'][0] && rrt['items'][0]['is_executor']=="0")){
        this.isExecutor=false;
        console.log("check save",this.isExecutor, rrt);
      }else if(rrt['items'][0]['is_executor']=="1"){
        this.isExecutor=true;
        console.log("check save",this.isExecutor, rrt);
      }
    });
  }
  save() {
    // console.log("check save",this.status_ice, this.isSaved);
    // this.isEditing=true;
    // // this.entity_class.form.disable();
    //   if (this.status_ice==1 ||  this.firstSaved==true) {
    //     this.entity_class.form.patchValue({ status_id: 1,due_date:this.currentTime,stage_id:21 });
    //     console.log("edit id",this.id);
    //     (this.firstSaved==true)?this.entity_class.form.patchValue({ id: this.id }):'';
    //     this.dbQueryService.updateTable(this.entity_code, [this.entity_class.form.getRawValue()])
    //       .subscribe(res => {
    //         if (res['error']) {
    //           this.mainService.toastError(res['error_text']);
    //         } else {
    //           this.mainService.toastSuccess("Заявка успешно изменена!");
    //           this.isSaved=!this.isSaved
    //           this.id=res['items'][0]['last_insert_id'];
    //            this.onSave.emit({reqId:res['items'][0]['last_insert_id'],id:res['items'][0]['last_insert_id'],tempId:this.tehe});
    //            this.doSave.emit({id:res['items'][0]['last_insert_id']})
    //            this.doReload.emit({templateId:this.tehe})
    //            this.checkExecutor(this.user,this.entity_class.form.controls['category'].value);
    //         }
    //       });
    //   } else if (this.status_ice==2 || this.status_ice==3){
    //     this.dbQueryService.updateTable(this.entity_code, [this.entity_class.form.getRawValue()])
    //       .toPromise().then(res => {
    //         if (res['error']) {
    //           this.mainService.toastError(res['error_text']);
    //         } else {
    //           this.dateAdded=true;
    //           this.entity_class.form.controls['due_date'].enable()
    //           this.isSaved=!this.isSaved
    //           this.mainService.toastSuccess("Срок выполнения успешно добавлен!");
    //         }
    //       });
    //   }else if(this.status_ice==0 && this.firstSaved==false){
    //     this.entity_class.form.patchValue({ status_id: 1, due_date:this.currentTime,stage:76, priority:2,stage_id:21});
    //     this.dbQueryService.insertTable(this.entity_code, [this.entity_class.form.getRawValue()])
    //       .toPromise().then(res => {
    //         if (res['error']) {
    //           this.mainService.toastError(res['error_text']);
    //         } else {
    //           console.log("doSave on Save strart");
    //           this.id=res['items'][0]['last_insert_id'];
    //           this.onSave.emit({reqId:res['items'][0]['last_insert_id'],id:res['items'][0]['last_insert_id'],tempId:this.tehe});
    //           this.doSave.emit({id:res['items'][0]['last_insert_id']});
    //           this.doReload.emit({templateId:this.tehe})
    //           this.checkExecutor(this.user,this.entity_class.form.controls['category'].value);
    //           this.dbQueryService.bpRun('hre_new_req', {
    //             entity_code: this.entity_code,
    //             pk: res.items[0]['sys$uuid'],
    //             req_id: res.items[0]['last_insert_id'],
    //             action: 'new',
    //           }).subscribe(res => {
    //           });
    //           this.isSaved=!this.isSaved;
    //           this.firstSaved=true;
    //           console.log("is saved after first save",this.isSaved);
    //           this.isCreated=res['items'][0]['last_insert_id'];
    //           this.mainService.toastSuccess("Заявка успешно добавлена!");
    //         }
    //       });
    //   }

    if(this.id){

            this.entity_class.form.patchValue({ status_id: 1,stage_id: 86});
            console.log("edit id",this.id);
            (this.firstSaved==true) ? this.entity_class.form.patchValue({ id: this.id }):'';
            this.dbQueryService.updateTable(this.entity_code, [this.entity_class.form.getRawValue()])
              .subscribe(res => {
                if (res['error']) {
                  this.mainService.toastError(res['error_text']);
                } else {
                  this.mainService.toastSuccess("Заявка успешно изменена!");
                  this.isSaved=!this.isSaved
                  this.id=res['items'][0]['last_insert_id'];
                   this.onSave.emit({reqId:res['items'][0]['last_insert_id'],id:res['items'][0]['last_insert_id'],tempId:this.tehe});
                   this.doSave.emit({id:res['items'][0]['last_insert_id']})
                   this.doReload.emit({templateId:this.tehe})
                   this.checkExecutor(this.user,this.entity_class.form.controls['category'].value);
                }
              });

    }else{
      this.entity_class.form.patchValue({ status_id: 1, due_date:this.currentTime,stage:22, priority:2,stage_id:86});
        this.dbQueryService.insertTable(this.entity_code, [this.entity_class.form.getRawValue()])
          .toPromise().then(res => {
            if (res['error']) {
              this.mainService.toastError(res['error_text']);
            } else {
              console.log("doSave on Save strart");
              this.id=res['items'][0]['last_insert_id'];
              this.onSave.emit({reqId:res['items'][0]['last_insert_id'],id:res['items'][0]['last_insert_id'],tempId:this.tehe});
              // this.doSave.emit({id:res['items'][0]['last_insert_id']});

              this.doReload.emit({templateId:this.tehe})
              this.checkExecutor(this.user,this.entity_class.form.controls['category'].value);
              this.dbQueryService
              .bpRun('hre_new_req', {
                entity_code: this.entity_code,
                pk: res.items[0]['sys$uuid'],
                req_id: res.items[0]['last_insert_id'],
                action: 'new',
              })
              .subscribe((res) => {
                // this.openRoute.emit({});
              });
              this.isSaved=!this.isSaved;
              this.firstSaved=true;

              console.log("is saved after first save",this.isSaved);
              this.isCreated=res['items'][0]['last_insert_id'];
              this.mainService.toastSuccess("Заявка успешно добавлена!");
            }
          });

    }




  }
  send(){
    this.mainService.toastSuccess("Заявка успешно отправлена!");
  }
  openApprove(){
    this.openRoute.emit({});
  }
  sendApprove(){
    this.dbQueryService.updateTable(this.entity_code, [this.entity_class.form.getRawValue()])
    .subscribe(res => {
      console.log("обновляйся")
    })

    this.openRoute.emit({});
  }

  complete(){
    this.bpRun('hre_idea_bp_end', {
      entity_code: this.entity_code,
      id: this.id,
      user: this.cur_user_get['id']
    });
  }
  getExecutors(){
    this.dbQueryService.getDetail('hre_idea_category',this.entity_class.form.controls['category'].value)
      .subscribe(rrr=>{
        console.log("on select",rrr,this.entity_class.form.controls['category'].value);
        this.tehe=rrr['hre_idea_category'][0]['approve_id']
          console.log("get tehe",this.tehe);
      })
  }
  dateChange(){
    this.dateAdded=false;
  }
  bpRun(code: string, input: any) {
    this.dbQueryService
      .bpRun(code, input)
      .subscribe((resp: RunTaskResponse) => {
        console.log(code + ': ', resp);
        if (resp.ok) {
          if (resp.instanceIsFinished) {
              console.log(resp.output.last_error);
          } else if (resp.task) {
          } else {
            console.log('BPM Run', code, 'Процесс запущен.');
          }
          this.onSave.emit({id:this.id});
          this.doSave.emit({id:this.id});
          // if(code=="hre_idea_bp_end"){

          // }
          this.doReload.emit({});

          // this.onClose.emit({});
        } else {
          console.log('Ошибка! Что-то пошло не так.');
        }
      });
  }
  editIdea(){
    this.isEditing=false;
    this.isSaved=!this.isSaved;
    this.entity_class.form.enable();
  }

  cancel() {
    this.onClose.emit({})
    // this.bind();
  }

  ngOnDestroy() {

  }

}

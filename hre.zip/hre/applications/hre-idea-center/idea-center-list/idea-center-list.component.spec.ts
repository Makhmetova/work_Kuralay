import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IdeaCenterListComponent } from './idea-center-list.component';

describe('IdeaCenterListComponent', () => {
  let component: IdeaCenterListComponent;
  let fixture: ComponentFixture<IdeaCenterListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IdeaCenterListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(IdeaCenterListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { options } from '@amcharts/amcharts4/core';
import { Component, OnInit } from '@angular/core';
import { QueryOptions } from '@app/_models';
import { DbQueryService } from '@app/_services';

@Component({
  selector: 'app-idea-center-list',
  templateUrl: './idea-center-list.component.html',
  styleUrls: ['./idea-center-list.component.less']
})
export class IdeaCenterListComponent implements OnInit {

  entity_code: string = 'hre_idea_center';
  ideas: any[] = [];
  statistics: any[] = [];
  filterValue: string;
  filterOptions: any [];
  options: QueryOptions;

  constructor(
    private dbQueryService: DbQueryService
  ) { 
    this.filterOptions = [{label: 'Новые / В работе', value: 'new,inprogress'}, {label: 'Внедренные', value: 'agreed'}];
    this.options = new QueryOptions(this.entity_code);
  }

  ngOnInit(): void {
    this.bind();
    this.getStatistics();
  }

  bind() {
    this.dbQueryService.getQuery(this.options)
      .subscribe(resp => {
        if (resp.items) {
          this.ideas = resp.items;
        }
      })
  }

  getStatistics() {
    let options = new QueryOptions('hre_idea_center_stats');
    this.dbQueryService.getQuery(options)
      .subscribe(resp => {
        if (resp.items) {
          resp.items.forEach(item => {
            if (['new', 'inprogress'].includes(item['code'])) {
              this.statistics.push(item);
            } else if (['agreed'].includes(item['code'])) {
              item['title'] = 'Внедренные';
              this.statistics.push(item);
            }
          })
        }
      })
  }

  filterChange() {
    this.options.fltin = {
      status_id: this.statistics.filter(s => this.filterValue.split(',').includes(s.code) ).map(v => v.id)
    }

    this.ideas = [];
    this.bind();
  }

  onOptionClick(event: { originalEvent: Event, option: Object, index: number}) {
    // console.log('onOptionClick event: ', event);
    
    // if (this.filterValue == event.option['value']) {
    //   this.options.fltin = {};
    //   this.filterValue = '';
    // } else {
    //   this.filterValue = event.option['value'];
    //   this.options.fltin = {
    //     status_id: this.statistics.filter(s => this.filterValue.split(',').includes(s.code) ).map(v => v.id)
    //   }
    // }

    // this.ideas = [];
    // this.bind();
  }

}

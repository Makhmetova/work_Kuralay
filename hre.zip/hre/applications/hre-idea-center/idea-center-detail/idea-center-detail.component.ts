import { Component, Input, OnInit, SimpleChanges } from '@angular/core';
import { Router } from '@angular/router';
import { EntityClass } from '@app/_models/entity';
import { AccountService, DbQueryService } from '@app/_services';
import { MainService } from '@app/_services/main.service';

@Component({
  selector: 'app-idea-center-detail',
  templateUrl: './idea-center-detail.component.html',
  styleUrls: ['./idea-center-detail.component.less']
})
export class IdeaCenterDetailComponent implements OnInit {

  @Input() detailId: number;
  @Input() entity_code: string = "hre_idea_center";
  @Input() details: any;

  entity_class: EntityClass;
  categories: any[] = [];
  priorities: any[] = [];
  executors: any[] = [];
  statuses: any[] = [];
  sessionRoles: Object;

  constructor(
    private mainService: MainService,
    private dbQueryService: DbQueryService,
    private router: Router,
    private accountService: AccountService
  ) { }

  ngOnInit(): void {
    this.sessionRoles = this.accountService.sessionRoles;

    this.getItemsSelect("users_select_by_roles", "", { param1: 'hr_manager' }).toPromise()
      .then((res) => {
        this.executors = res.items;
        return this.getItemsSelect("hre_application_status_select", "").toPromise();
      }).then((res) => {
        this.statuses = res.items;
        return this.getItemsSelect("hre_idea_category_select", "").toPromise();
      }).then((res) => {
        this.categories = res.items;
        return this.getItemsSelect("hre_idea_priority_select", "").toPromise();
      }).then((res) => {
        this.priorities = res.items;
        this.getEntityAttrs(this.entity_code);
      });
  }

  ngAfterViewInit() {
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.details && this.entity_class) {
      this.bind();
    }
  }

  bind() {
    this.entity_class.form = this.entity_class.createForm();
    if (this.details) {
      this.entity_class.bindForm(this.entity_class.form, this.details[this.entity_code][0]);
    }
  }

  getEntityAttrs(code: string) {
    this.dbQueryService.getEntityAttrsByCode(code)
      .subscribe( res => {
        if (res.items) {
          this.entity_class = new EntityClass(this.entity_code);
          this.entity_class.setEntityAttrs(res.items);
          this.bind();
        }
      })
  }

  getItemsSelect(code: string, _query?: string, params?: Object) {
    return this.dbQueryService.getQuerySelect(code, _query, 100, params);
  }

  save() {
    if (this.detailId) {
      this.dbQueryService.updateTable(this.entity_code, [this.entity_class.form.getRawValue()])
        .toPromise().then(res => {
          if (res['error']) {
            this.mainService.toastError(res['error_text']);
          } else {
            this.mainService.toastSuccess("Заявка успешно обновлено!");
          }
        });
    } else {
      this.entity_class.form.patchValue({ status_id: 1 });
      this.dbQueryService.insertTable(this.entity_code, [this.entity_class.form.getRawValue()])
        .toPromise().then(res => {
          if (res['error']) {
            this.mainService.toastError(res['error_text']);
          } else {
            this.router.navigate(['../hre_idea_center_details', { id: res['items'][0]['last_inserted_id']}])
          }
        });
    }
  }

  cancel() {
    this.bind();
  }

  ngOnDestroy() {

  }

}

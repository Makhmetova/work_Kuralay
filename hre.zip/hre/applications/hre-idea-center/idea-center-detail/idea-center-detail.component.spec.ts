import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IdeaCenterDetailComponent } from './idea-center-detail.component';

describe('IdeaCenterDetailComponent', () => {
  let component: IdeaCenterDetailComponent;
  let fixture: ComponentFixture<IdeaCenterDetailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IdeaCenterDetailComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(IdeaCenterDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

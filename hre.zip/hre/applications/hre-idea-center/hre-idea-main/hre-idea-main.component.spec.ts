import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HreIdeaMainComponent } from './hre-idea-main.component';

describe('HreIdeaMainComponent', () => {
  let component: HreIdeaMainComponent;
  let fixture: ComponentFixture<HreIdeaMainComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HreIdeaMainComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HreIdeaMainComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import {Component, EventEmitter, Input, OnDestroy, OnInit, Output} from '@angular/core'
import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import am4themes_animated from "@amcharts/amcharts4/themes/animated";
import { DbQueryService, MainService } from '@app/_services';
import { Datasource, QueryOptions } from '@app/_models';
import am4themes_dataviz from "@amcharts/amcharts4/themes/dataviz";
import { take } from 'rxjs/operators';


@Component({
  selector: 'app-hre-idea-main',
  templateUrl: './hre-idea-main.component.html',
  styleUrls: ['./hre-idea-main.component.css']
})
export class HreIdeaMainComponent implements OnInit {
  @Output() newIdeaOpen = new EventEmitter<any>();
  // @Output() id;
  HreList : Datasource
  ideas_list:any;
  HreIdeaLikes : Datasource
  filters : Array<Object> = []
  directionsFilter = {}
  funnelFilter = {}
  StatusFilter = {}
  SourcesFilter = {}
  CompaniesFilter = {}
  reHreIdeaLikes:any;
  constructor(private network : DbQueryService, private main : MainService){
      this.HreList = new Datasource(new QueryOptions('hre_idea_center'),'id','code',this.network)
      this.HreIdeaLikes = new Datasource(new QueryOptions('hre_idea_center_like'),'hre_idea_center_id','hre_idea_center_id$',this.network)
      this.filters = [
          {
              id : 1,
              name : 'За неделю'
          },
          {
              id : 2,
              name : 'За месяц'
          },
          {
              id : 3,
              name : 'За год'
          }
      ];
    //   this.initDetail();
  }
  ngOnInit(){
      this.initDetail();
      this.reHreIdeaLikes=setInterval( ()=> {
        this.HreIdeaLikes.Init();
        this.HreIdeaLikes.Bind().subscribe(val=>{
        this.buildBarChartByCompany()
      })
      }, 2*60000)
      }
      initDetail(){
        this.network.getQuery(new QueryOptions('hre_idea_center'))
        .pipe(take(1))
        .subscribe(resp => {
          if (resp.items) {
            this.ideas_list=resp.items;
            console.log('ideassss',this.ideas_list);
            this.HreList.Init();
            //   this.ideas_list=this.HreList.getData();
              this.HreIdeaLikes.Init();
              this.HreIdeaLikes.Bind().subscribe(val=>{
                //   this.ideas_list=this.HreList.getData();
                  this.buildBarChartByCompany()
                })
              this.HreList.Bind().subscribe(val=>{
                  this.buildDealStatusesChart();
                  this.buildDealsDirectionsChart();
              })
              this.reHreIdeaLikes=setInterval( ()=> {
                  this.HreIdeaLikes.Init();
                  this.HreIdeaLikes.Bind().subscribe(val=>{
                  this.buildBarChartByCompany()
                })
                }, 2*60000)
          }
        })
      }
      ngOnDestroy(){
        this.HreList.destroy();
        if (this.reHreIdeaLikes) {
          clearInterval(this.reHreIdeaLikes);
          this.HreIdeaLikes.destroy();
        }
        // this.Leadds.destroy();
      }
      buildDealStatusesChart(){
          am4core.useTheme(am4themes_dataviz);
          am4core.useTheme(am4themes_animated);
          let chart = am4core.create('chartdiv2',am4charts.PieChart)
          chart.legend = new am4charts.Legend();
          let nonFiltratingData = this.HreList.getData();
          if(this.StatusFilter['id'] == 1 || !this.StatusFilter['id']){
              nonFiltratingData = nonFiltratingData.filter(item=>{
                  return new Date(item['created_at']) >= new Date(new Date().getTime() - 7* 24*60*60*1000)
              })
          }
          else if(this.StatusFilter['id'] == 2){
              nonFiltratingData = nonFiltratingData.filter(item=>{
                  return new Date(item['created_at']) >= new Date(new Date().getTime() - 30 * 24*60*60*1000)
              })
          }
          else if(this.StatusFilter['id'] == 3){
              nonFiltratingData = nonFiltratingData.filter(item=>{
                  return new Date(item['created_at']) >= new Date(new Date().getTime() - 365 * 24*60*60*1000)
              })
          }
          let sortedData = Datasource.groupBy(nonFiltratingData,'category','category$',true,0,'Без Категории')
          chart.data = sortedData
          let pieSeries = chart.series.push(new am4charts.PieSeries());
          pieSeries.dataFields.value = 'count';
          pieSeries.dataFields.category = 'title';
          pieSeries.slices.template.stroke = am4core.color("#fff");
          pieSeries.slices.template.strokeWidth = 2;
          // pieSeries.slices.template.strokeOpacity = 0.9;
          pieSeries.slices.template.fillOpacity = 0.9;
          

          pieSeries.hiddenState.properties.opacity = 1;
          pieSeries.hiddenState.properties.endAngle = -90;
          pieSeries.hiddenState.properties.startAngle = -90;
      }
      buildDealsDirectionsChart(){
        
          let BarChart = am4core.create("chartdiv", am4charts.XYChart);
          BarChart.padding(40, 40, 40, 40);
          let categoryAxisBarChart = BarChart.yAxes.push(new am4charts.CategoryAxis());
          categoryAxisBarChart.renderer.grid.template.location = 0;
          categoryAxisBarChart.dataFields.category = "title";
          categoryAxisBarChart.renderer.minGridDistance = 1;
          categoryAxisBarChart.renderer.inversed = true;
          categoryAxisBarChart.renderer.grid.template.disabled = true;

          let valueAxisBarChart = BarChart.xAxes.push(new am4charts.ValueAxis());
          valueAxisBarChart.min = 0;
          

          let seriesBarChart = BarChart.series.push(new am4charts.ColumnSeries3D());
          seriesBarChart.dataFields.categoryY = "title";
          seriesBarChart.dataFields.valueX = "count";
          // seriesBarChart.dataFields.valueX.renderer.labels.template.adapter.add("count", function(count, target) {
          //   return text.match(/\./) ? "" : count;
          // });
          seriesBarChart.tooltipText = "{valueX.value}"
          // seriesBarChart.columns.template.strokeOpacity = 0.8;
          seriesBarChart.columns.template.fillOpacity = 0.8;
          // seriesBarChart.columns.template.column.cornerRadiusBottomRight = 5;
          // seriesBarChart.columns.template.column.cornerRadiusTopRight = 5;

          let labelBullet = seriesBarChart.bullets.push(new am4charts.LabelBullet())
          labelBullet.label.horizontalCenter = "left";
          labelBullet.label.dx = 10;
          labelBullet.label.text = "{values.valueX.workingValue}";
          labelBullet.locationX = 1;

          seriesBarChart.columns.template.adapter.add("fill", function(fill, target){
          return BarChart.colors.getIndex(target.dataItem.index);
          });
          let nonFiltratingData = this.HreList.getData();
          if(this.directionsFilter['id'] == 1 || !this.directionsFilter['id']){
              nonFiltratingData = nonFiltratingData.filter(item=>{
                  return new Date(item['created_at']) >= new Date(new Date().getTime() - 7* 24*60*60*1000)
              })
          }
          else if(this.directionsFilter['id'] == 2){
              nonFiltratingData = nonFiltratingData.filter(item=>{
                  return new Date(item['created_at']) >= new Date(new Date().getTime() - 30 * 24*60*60*1000)
              })
          }
          else if(this.directionsFilter['id'] == 3){
              nonFiltratingData = nonFiltratingData.filter(item=>{
                  return new Date(item['created_at']) >= new Date(new Date().getTime() - 365 * 24*60*60*1000)
              })
          }
          let sortedData = Datasource.groupBy(nonFiltratingData,'status_id','status_id$',true,'','Без статуса')

          BarChart.data = sortedData
      }
      buildBarChartByCompany(){
          am4core.useTheme(am4themes_dataviz);
          var chart = am4core.create("chartdiv3", am4charts.XYChart3D);
          chart.hiddenState.properties.opacity = 0; // this creates initial fade-in
          
          let nonFiltratingData = this.HreIdeaLikes.getData();
          if(this.CompaniesFilter['id'] == 1 || !this.CompaniesFilter['id']){
              nonFiltratingData = nonFiltratingData.filter(item=>{
                  return new Date(item['created_at']) >= new Date(new Date().getTime() - 7* 24*60*60*1000)
              })
          }
          else if(this.CompaniesFilter['id'] == 2){
              nonFiltratingData = nonFiltratingData.filter(item=>{
                  return new Date(item['created_at']) >= new Date(new Date().getTime() - 30 * 24*60*60*1000)
              })
          }
          else if(this.CompaniesFilter['id'] == 3){
              nonFiltratingData = nonFiltratingData.filter(item=>{
                  return new Date(item['created_at']) >= new Date(new Date().getTime() - 365 * 24*60*60*1000)
              })
          }
          let sortedData = Datasource.groupBy(nonFiltratingData,'hre_idea_center_id','hre_idea_center_id$',true,'','Без номера заявки')
          const newar=sortedData.sort(function(a, b) {
            if (a.count < b.count) {
            return 1;
            }
            else if (a.count > b.count) {
            return -1
            }
            else {
            return 0;
            }
          })
          console.log("sorted likes",newar);
          let ch_data= newar.slice(0,5);
          chart.data=ch_data;
          console.log(this.ideas_list);
          chart.data=ch_data.map(tr=>{
              console.log(tr,this.ideas_list.filter(x=>x['code']===tr['title']),this.ideas_list.find(x=>x['code']===tr['title']))
            // let ideaDet=this.ideas_list.find(x=>x['code']==tr['title']);
            tr['id_idea']=this.ideas_list.find(x=>x['code']===tr['title'])['id'];
            tr['title_idea']=this.ideas_list.find(x=>x['code']===tr['title'])['title'];
            tr['url_idea']=this.ideas_list.find(x=>x['code']===tr['title'])['url'];
            return tr
          })


          var categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
          categoryAxis.renderer.grid.template.location = 0;
          categoryAxis.dataFields.category = "title";
          categoryAxis.renderer.minGridDistance = 30;
          // categoryAxis.renderer.minLabelPosition = 10;
          categoryAxis.fontSize = 11;
          // categoryAxis.renderer.labels.template.dy = 5;
          categoryAxis.renderer.labels.template.rotation = 75;



          var valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
          valueAxis.min = 0;
          // valueAxis.max = chart.data.length;
          // valueAxis.strictMinMax = true;
          // valueAxis.renderer.minGridDistance = 30;
          // valueAxis.renderer.baseGrid.disabled = true;
          // valueAxis.label.text = "{values.valueX.workingValue}";
          // valueAxis.renderer.labels.template.adapter.add("text", function(text, target) {
          //     return text && text.match(/\./) ? "" : text;
          // });

          valueAxis.maxPrecision = 0;
          valueAxis.events.on("ready", function(ev) {
            ev.target.min = ev.target.min;
            ev.target.max = ev.target.max;
          })
        //   valueAxis.renderer.labels.template.events.on("over", function(ev) {
        //     console.log("hover on ", ev.target);
        //   }, this);



          var series = chart.series.push(new am4charts.ColumnSeries3D());
          

          series.dataFields.categoryX = "title";
          series.dataFields.valueY = "count";
        //   let ideaDet=this.ideas_list.find(x=>x['code']==chart.data['title'])
          console.log("ch am4charts",nonFiltratingData,"ch",chart, "ch.data",chart.data,"series",series,"catx",['categoryX'],chart.data['title'],['title']);
          var tooltipHTML = `<center><strong>Номер заявки: {title}</strong></center>
          <hr />
          <table>
          <tr>
            <th colspan="2" align="center">{title_idea}</th>
          </tr>
          <tr>
            <th align="left">Кол-во лайков</th>
            <td>{count}</td>
          </tr>
          </table>`;
        //   series.columns.template.tooltipText = "[b]{valueY.value}[/]";
          series.columns.template.tooltipY = 0;
          series.columns.template.fillOpacity = .8;
        //   series.tooltipText = "{title}: [b]{valueY}[/]";
          series.tooltipHTML = tooltipHTML;
          series.tooltip.label.interactionsEnabled = true;
        //   series.columns.template.events.on("over", function(ev) {
        //       console.log("hover on ", ev.target);
        //     }, this);
            series.columns.template.events.on("hit", function(ev) {
              console.log("clikes on ",ev.target.dataItem.component.tooltipDataItem.dataContext);
              this.openModalById(ev.target.dataItem.component.tooltipDataItem.dataContext['id_idea']);
            }, this);
          // series.columns.template.column = 10;
          // series.columns.template.column.cornerRadiusTopLeft = 10;
          
          series.columns.template.adapter.add("fill", function(fill, target) {
          return chart.colors.getIndex(target.dataItem.index);
          });
          chart.zoomOutButton.disabled = false;
          // chart.zoomOutButton.dispatchImmediately("hit");
           
          // series.renderer.labels.template.adapter.add("text", function(text, target) {
          //   return text.match(/\./) ? "" : text;
          // });
          // chart.legend = new am4charts.Legend();
          chart.cursor = new am4charts.XYCursor();

      }
      FilterChart(ev,filter){
          this[filter] = ev.value;
          // console.log()
          if(filter == 'StatusFilter'){
              this.buildDealStatusesChart()
          }
          else if(filter == 'directionsFilter'){
              this.buildDealsDirectionsChart()
          }
          else if(filter == 'CompaniesFilter'){
              this.buildBarChartByCompany()
          }
      }
      openModalById(item:any){
        console.log("emit",this.ideas_list.find(it=>it.id==item));
          this.newIdeaOpen.emit(this.ideas_list.find(it=>it.id==item));

      }
      getImgLink(imItem?: string) {
        return 'https://devportal.ekpd.kz/restapi/getfile?code=' + imItem;
    }
    }

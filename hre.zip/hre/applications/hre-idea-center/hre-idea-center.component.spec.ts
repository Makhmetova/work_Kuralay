import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HreIdeaCenterComponent } from './hre-idea-center.component';

describe('HreIdeaCenterComponent', () => {
  let component: HreIdeaCenterComponent;
  let fixture: ComponentFixture<HreIdeaCenterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HreIdeaCenterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HreIdeaCenterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

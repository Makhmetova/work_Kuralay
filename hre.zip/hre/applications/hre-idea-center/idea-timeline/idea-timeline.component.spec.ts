import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IdeaTimelineComponent } from './idea-timeline.component';

describe('IdeaTimelineComponent', () => {
  let component: IdeaTimelineComponent;
  let fixture: ComponentFixture<IdeaTimelineComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IdeaTimelineComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(IdeaTimelineComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

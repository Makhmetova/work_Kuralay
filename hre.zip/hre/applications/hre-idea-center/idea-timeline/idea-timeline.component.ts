import { Component,EventEmitter, Input, OnInit } from '@angular/core';
import { DbQueryService } from '@app/_services';
import { BuilderSerice } from '@app/_services/builder.service';
// import {EventEmitter} from 'events';
@Component({
  selector: 'app-idea-timeline',
  templateUrl: './idea-timeline.component.html',
  styleUrls: ['./idea-timeline.component.less']
})
export class IdeaTimelineComponent implements OnInit {
  table_name:string;
  id:number;
  @Input() doReload  = new EventEmitter<Object>();
  detail:any;
  private _detail: Object;
  
  // @Input()
  // set detail(item){

  //   console.log('setted')
  //   this._detail = item
  // }
  // get detail():Object{
  //   return this._detail;
  // }



  status_lookup_id:number
  req_status = [];
  req_status_index: any; 
  cur_stats_stage;


  constructor(private network: DbQueryService,
    private factory:BuilderSerice,){

  }

  ngOnInit(){
    console.log("Step info here");
    // console.log(this.id);
    // console.log("FFFF",this.detail);
    this.doReload.subscribe(val => {
      if(val.detail['id'] && val.detail['id']>0){
        this.detail = val.detail;
        this.id = val.detail['id'];
      }
    })
  }
  ngAfterViewInit(){
    if (this.id == 0){
      if(this.table_name && this.table_name=='hre_idea_center'){
        this.network.executeQuery(`code=req_statuses_lookups&flt$entity_code$eq$=hre_idea_custom_statuses`,'get').subscribe(val=>{
          if(val['items'].length > 0){
            this.status_lookup_id = val['items'][0]['id']
            this.network.executeQuery(`code=req_statuses_lookups_step&flt$parent_lookup$eq$=${this.status_lookup_id}`,'get').subscribe(vals=>{
              if(vals['items'].length > 0){
                this.req_status = vals['items'];
                console.log("check status",this.req_status);
                // this.req_status_index = this.req_status.findIndex(x => x.id == vals['items'][0]['id']);
                this.detail['stage'] = vals['items'][0]['id']
              }
            })
          }
        })
      }else {
        this.network.executeQuery(`code=req_statuses_lookups&flt$entity_code$eq$=hre_idea_custom_statuses`,'get').subscribe(val=>{
          if(val['items'].length > 0){
            this.status_lookup_id = val['items'][0]['id']
            console.log("check status 0 ",this.status_lookup_id);
            this.network.executeQuery(`code=req_statuses_lookups_step&flt$parent_lookup$eq$=${this.status_lookup_id}`,'get').subscribe(vals=>{
              if(vals['items'].length > 0){
                this.req_status = vals['items'];
                console.log("check status",this.req_status);
                // this.req_status_index = this.req_status.findIndex(x => x.id == vals['items'][0]['id']);
                this.detail['stage'] = vals['items'][0]['id']
              }
            })
          }
        })
      }

    } else {
     
        
        
        console.log("check stage",this.detail['stage']);
        this.network.executeQuery(`code=req_statuses_lookups_step&flt$parent_lookup$eq$=${this.detail['stage_id']}`,'get').subscribe(vals=>{
          if(vals){
            this.req_status = vals['items'];
            console.log("Status",vals, this.detail,this.req_status);

            // this.req_status_index = this.req_status.findIndex(x => x.id == this.detail['status']);
          }
        
      })
    }
  
  }



}

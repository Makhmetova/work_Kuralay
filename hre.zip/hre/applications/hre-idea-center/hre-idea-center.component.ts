import { ActivatedRoute } from '@angular/router';
import {
  Component,
  OnInit,
  EventEmitter,
  ComponentRef,
  ViewChild,
  ViewContainerRef,
} from '@angular/core';
import { CusInfoBlockComponent } from '@app/business/cus/components/infoBlock/cusInfoBlock.component';
import { SlsRmpInnerRequestComponent } from '@app/business/sls/components/RPM/InnerRequest/slsRpmInner.component';
import { PureDetailFormComponent } from '@app/_components/PureDetailForm/pureDetailForm.component';
import { QueryOptions } from '@app/_models';
import { IFormOptions } from '@app/_models/common';
import { AccountService, DbQueryService, MainService } from '@app/_services';
import { BuilderSerice } from '@app/_services/builder.service';
import { ComponentPoolService } from '@app/_services/componentPool.service';
import { take } from 'rxjs/operators';
import { IdeaDetailComponent } from './idea-detail/idea-detail.component';
import { connectableObservableDescriptor } from 'rxjs/internal/observable/ConnectableObservable';
import { PureInfoBlockComponent } from '@app/_components/PureInfoBlock/pureInfoBlock.component';
import { StepInfoComponent } from '../step-info/step-info.component';
import { IdeaTimelineComponent } from './idea-timeline/idea-timeline.component';

@Component({
  selector: 'app-hre-idea-center',
  templateUrl: './hre-idea-center.component.html',
  styleUrls: ['./hre-idea-center.component.css'],
  providers: [BuilderSerice, DbQueryService, ComponentPoolService],
})
export class HreIdeaCenterComponent implements OnInit {
  valueTest: [{ title: string }];
  detailIsOpen: boolean;
  ideas: any[] = [];
  table_name: string = 'hre_idea_center';
  users: Array<Object> = [];
  statistics: any[] = [];
  user: Object;
  myIdeasList: any[] = [];
  ideaCount: number;
  myStatistics: any[] = [];
  myIdeaCount: number;
  allNewIdeas: any[] = [];
  myNewIdeas: any[] = [];
  allInWorkIdeas: any[] = [];
  myInWorkIdeas: any[] = [];
  allAgreedIdeas: any[] = [];
  myAgreedIdeas: any[] = [];
  allIdeas: any[] = [];
  myDraftIdeas: any[] = [];
  adminIdeas: any[] = [];
  fields: Array<Object>;
  perPage: number = 10;
  rowsPerPageOptions: number;
  perPage1: number = 10;
  rowsPerPageOptions1: number;
  likes: number = 0;
  dislikes: number = 0;
  curUser: Object;
  temp_id: any;
  saved_id: any;
  isLikedIdea: boolean;
  isExecutor: boolean;
  isAdmin: boolean = false;
  pureDetailComponent;
  adminItems: any;
  detail: any;
  sessionRoles: any;
  @ViewChild('detailFormHolder', { read: ViewContainerRef })
  detailFormHolder: ViewContainerRef;
  constructor(
    private network: DbQueryService,
    private account: AccountService,
    private factory: BuilderSerice,
    private pool: ComponentPoolService,
    private main: MainService
  ) {
    this.detailIsOpen = false;
    this.fields = [
      {
        title: 'Отправитель',
        table_code: 'created_by',
        alias: 'created_by$',
        checked: true,
      },
      { title: 'Номер', table_code: 'code', alias: 'code', checked: true },
      {
        title: 'Дата создания',
        table_code: 'created_at',
        alias: 'created_at',
        checked: true,
      },
      {
        title: 'Наименование',
        table_code: 'title',
        alias: 'title',
        checked: false,
      },
      {
        title: 'Назначено',
        table_code: 'category',
        alias: 'category$',
        checked: true,
      },
      {
        title: 'Статус',
        table_code: 'status_id',
        alias: 'status_id$',
        checked: true,
      },
      {
        title: 'Приоритет',
        table_code: 'priority',
        alias: 'priority$',
        checked: true,
      },
      {
        title: 'Дата изменения',
        table_code: 'updated_at',
        alias: 'updated_at',
        checked: true,
      },
      {
        title: 'Исполнитель',
        table_code: 'executor',
        alias: 'executor$',
        checked: true,
      },
      {
        title: 'Закрыл',
        table_code: 'closed_by',
        alias: 'closed_by$',
        checked: true,
      },
    ];
  }
  getSum(ideaSum): number {
    let sum = 0;
    ideaSum.forEach((x) => {
      sum += parseInt(x.count);
    });
    return sum;
  }

  ngOnInit(): void {
    this.main.usersObservable.pipe(take(1)).subscribe((val) => {
      this.users = val;
    });
    this.user = this.account.userValue.sessioninfo;
    this.sessionRoles = this.account.sessionRoles;
    this.initDetail();
  }
  initDetail() {
    this.network
      .getQuery(
        new QueryOptions('hre_idea_center&orderBy=created_at&orderAsc=0')
      )
      .pipe(take(1))
      .subscribe((resp) => {
        if (resp.items) {
          this.allIdeas = resp.items;
          this.allIdeas.forEach((cz, ind) => {
            this.network
              .restapiPost('hre_get_likes', {
                idea_id: cz['id'],
                cur_user: this.user['id'],
              })
              .subscribe((resd) => {
                this.allIdeas[ind]['new_attr'] = +resd['items']['is_liked'];
              });
          });
          this.ideas = this.allIdeas;
          this.getExecutors(this.user);
        }
      });
  }
  getImgLink(imItem?: Object) {
    return 'https://devportal.ekpd.kz/restapi/getfile?code=' + imItem['url'];
  }

  filterIdeas(ideaFilter: string) {
    if (ideaFilter == 'NewIdeas') {
      this.ideas = this.allIdeas.filter(
        (it) => it['status_id'] == 1 || it['status_id'] == 2
      );
    } else if (ideaFilter == 'IdeasInWork') {
      this.ideas = this.allIdeas.filter((it) => it['status_id'] == 3);
    } else if (ideaFilter == 'EmbedIdeas') {
      this.ideas = this.allIdeas.filter((it) => it['status_id'] == 4);
    } else if (ideaFilter == 'MyDraftIdeas') {
      this.myIdeasList = this.allIdeas.filter(
        (it) => it['status_id'] == 1 && it['created_by'] == this.user['id']
      );
    } else if (ideaFilter == 'MyNewIdeas') {
      this.myIdeasList = this.allIdeas.filter(
        (it) => it['status_id'] == 2 && it['created_by'] == this.user['id']
      );
    } else if (ideaFilter == 'MyIdeasInWork') {
      this.myIdeasList = this.allIdeas.filter(
        (it) => it['status_id'] == 3 && it['created_by'] == this.user['id']
      );
    } else if (ideaFilter == 'MyEmbedIdeas') {
      this.myIdeasList = this.allIdeas.filter(
        (it) => it['status_id'] == 4 && it['created_by'] == this.user['id']
      );
    } else if (ideaFilter == 'AllIdeas') {
      this.ideas = this.allIdeas;
    } else if (ideaFilter == 'AllmyIdeas') {
      this.myIdeasList = this.allIdeas.filter(
        (x) => x['created_by'] == this.user['id']
      );
    } else if (ideaFilter == 'Alladmin') {
      this.initDetail();
    }
  }

  openDetail() {
    this.detailIsOpen = true;
    let entityQuery = new QueryOptions('entities');
    entityQuery.flteq = {
      code: this.table_name,
    };
    let queryOpts = new QueryOptions(this.table_name);
    queryOpts.flteq = {
      id: this.temp_id ? this.saved_id : 0,
    };
    let timelineQueryOptions = new QueryOptions('req_statuses_lookups_step');
    timelineQueryOptions.flteq = {
      parent_lookup: 21,
    };
    let options: IFormOptions = {
      showApproveForm: true,
      showCommentsForm: true,
      showFilesForm: true,
      showHistoryForm: true,
      showTimeline: true,
      showOrdersForm: false,
      showInfoBlock: true,
      formComponent: IdeaDetailComponent,
      infoBlockOptions: {
        verticalInfoBlock: true,
        InfoBlockComponent: PureInfoBlockComponent,
        InfoBlockParams: {},
      },
      timelineOptions: {
        useCustomTimeline: true,
        customTimelineComponent: IdeaTimelineComponent,
        customTimelineOptions: {},
        defaultTimelineOptions: {
          statusesLookupQuery: timelineQueryOptions,
        },
      },
      requestFormOptions: {
        onSaveUpdateInfoBlock: true,
        onSaveUpdateTimeline: true,
        onSaveReloadApprove: true,
      },
      formComponentParams: {
        isSender: true,
        status_ice: 0,
        id: 0,
        entity_code: 'hre_idea_center',
        cur_user_get: this.user,
        approveId: 0,
      },
      mainFormOptions: {
        title: 'Добавление новой идеи',
        formStyle: {
          'margin-top': '0rem',
        },
        mainCardStyle: {
          width: '75%',
          'margin-left': '1.5rem',
        },
        formStyleClass: ['p-4'],
      },
      approveOptions: {
        templateId: this.temp_id,
        showButtons: true,
        showApproveButtons: true,
        useUsersFilter: true,
        useDefaultPreSettings: true,
      },
      filesOptions: {
        multiple: true,
        tableToSave: `${'hre_idea_center'}_files`,
        fieldForLink: `${'hre_idea_center'}_id`,
        saveHistory: true,
      },
    };
    let compRef: ComponentRef<any>;
    let user = this.users.find((x) => x['id'] == this.user['id']);
    compRef = this.factory.MountComponent(
      this.detailFormHolder,
      PureDetailFormComponent,
      {
        FormOptions: options,
        table_name: 'hre_idea_center',
        code: 'hre_idea_center',
        id: this.temp_id ? this.saved_id : 0,
        user: user,
        sender: true,
      }
    );
    compRef.instance.onClose.subscribe((val) => {
      this.detailFormHolder.clear();
      this.detailIsOpen = false;
      this.saved_id = 0;

    });
    compRef.instance.onSave.subscribe((val) => {
      this.temp_id = +val.tempId;
      this.saved_id = +val.reqId;
      console.log('8', val);
      compRef.instance.templateId = +val.data.approve_id;
      compRef.instance.FormOptions.approveOptions.templateId =
        +val.data.approve_id;
      // compRef.instance.FormOptions.formComponentParams.approveId=this.temp_id;
      compRef.instance.id = val.id;
      // compRef.instance.FormOptions.showTimeline=true;
      // compRef.instance.FormOptions.timelineOptions.verticalInfoBlock=false;
      // compRef.instance.FormOptions.timelineOptions.customTimelineComponent=IdeaTimelineComponent;
    });
  }
  openIdeaDetail(item) {
    // if(n_id){
    //   this.id=n_id;
    // }

    this.network.getDetail(this.table_name, item['id']).subscribe((det) => {
      let detail = det[this.table_name][0];
      this.detailIsOpen = true;
      let filesQueryOptions = new QueryOptions('hre_idea_center_files');
      filesQueryOptions.flteq = {
        hre_idea_center_id: item.id,
      };
      let entityQuery = new QueryOptions('entities');
      entityQuery.flteq = {
        code: this.table_name,
      };
      let timelineQueryOptions = new QueryOptions('req_statuses_lookups_step');
      timelineQueryOptions.flteq = {
        parent_lookup: 22,
      };
      let queryOpts = new QueryOptions(this.table_name);
      queryOpts.flteq = {
        id: item.id,
      };
      console.log(
        'after check evec res + detaolsilisli',
        this.isExecutor,
        item
      );
      let options: IFormOptions = {
        showApproveForm: true,
        showCommentsForm: true,
        showFilesForm: true,
        showHistoryForm: true,
        showTimeline: true,
        showOrdersForm: false,
        showInfoBlock: true,
        formComponent: IdeaDetailComponent,
        infoBlockOptions: {
          verticalInfoBlock: true,
          InfoBlockComponent: PureInfoBlockComponent,
          InfoBlockParams: {},
        },
        // timelineOptions: {
        //   useCustomTimeline: true,
        //   customTimelineComponent: IdeaTimelineComponent,
        //   customTimelineOptions: {
        //     // inputParams: {
        //     //   detail_list: item
        //     // },
        //   },
        //   defaultTimelineOptions: {
        //     statusesLookupQuery: timelineQueryOptions,
        //   },
        // },
        timelineOptions: {
          useCustomTimeline: true,
          customTimelineComponent: StepInfoComponent,
          defaultTimelineOptions: {
            statusesLookupQuery: timelineQueryOptions,
          },
        },
        formComponentParams: {
          isSender: this.user['id'] == item.created_by ? true : false,
          status_ice: item.status_id,
          cur_user_get: this.user,
          entity_code: 'hre_idea_center',
          id: item.id,
          detailItem: item,
          approveId: item.category,
        },
        mainFormOptions: {
          title: 'Центр идей',
          // formStyle: {
          //   "margin-top": "0rem"
          // },
          // mainCardStyle:{
          //   "width":"75%",
          //   "margin-left":"1.5rem"
          // },
          // formStyleClass: ['p-4']
        },
        approveOptions: {
          templateId: item.approve_id,
          showButtons: true,
          showApproveButtons: true,
          useUsersFilter: false,
          useDefaultPreSettings: false,
        },
        requestFormOptions: {
          onSaveUpdateInfoBlock: true,
          onSaveUpdateTimeline: true,
          onSaveReloadApprove: true,
        },
        filesOptions: {
          multiple: true,
          tableToSave: `${'hre_idea_center'}_files`,
          fieldForLink: `${'hre_idea_center'}_id`,
          saveHistory: true,
          FilesSelectQueryOptions: filesQueryOptions,
        },
      };
      let compRef: ComponentRef<any>;
      let user = this.users.find((x) => x['id'] == this.user['id']);
      compRef = this.factory.MountComponent(
        this.detailFormHolder,
        PureDetailFormComponent,
        {
          FormOptions: options,
          table_name: 'hre_idea_center',
          code: 'hre_idea_center',
          id: item.id,
          user: user,
          reqTitle: item.title,
          uuid: detail['sys$uuid'],
          detail: item,
        }
      );
      compRef.instance.onClose.subscribe((val) => {
        this.detailFormHolder.clear();
        this.detailIsOpen = false;
      });
      compRef.instance.onSave.subscribe((val) => {
        console.log('8', val);
        this.temp_id = +val.tempId;
        compRef.instance.templateId = this.temp_id;
        compRef.instance.FormOptions.approveOptions.templateId =
          +val.data.approve_id;
        // compRef.instance.FormOptions.formComponentParams.approveId=this.temp_id;
        compRef.instance.id = val.id;
        // compRef.instance.FormOptions.showTimeline=true;
        // compRef.instance.FormOptions.timelineOptions.verticalInfoBlock=false;
        // compRef.instance.FormOptions.timelineOptions.customTimelineComponent=IdeaTimelineComponent;
      });
    });
  }
  getExecutors(user: object, approveId?: number) {
    this.isAdmin = this.sessionRoles['hr_head'] ? true : false;
    if (!this.sessionRoles['hr_head']) {
      this.network
        .restapiPost('get_hre_group', { user_id: user['id'] })
        .subscribe((rrrr) => {
          console.log('checkadmin network', rrrr);
          if (rrrr[2]['res']) {
            this.isAdmin = true;
            this.adminItems = [rrrr[2]['res']];
            this.adminIdeas = [];
            console.log('need concat', this.adminItems);
            for (let obj of Object.keys(this.adminItems[0])) {
              let its = this.adminItems[0][obj];
              var super_array = [];
              super_array = this.allIdeas.filter(
                (c) => c['category'] === its['value']
              );
              this.adminIdeas = [...this.adminIdeas, ...super_array];
              console.log('check is sdhjehdjuradmin', this.isAdmin,this.adminIdeas);
              // this.adminIdeas=this.adminIdeas.map(x=>{x.updated_at=new Date(x.updated_at).toString();return x})
              // this.adminIdeas=this.adminIdeas.sort((a:Object,b:Object)=>{return new Date(b['updated_at'])-new Date(a.['upadtes_at'])})
            }
          } else {
            this.isAdmin = false;

          }
          console.log('check is admin', this.isAdmin,this.adminIdeas);
        });
    } else {
      this.adminIdeas = this.allIdeas
    }
  }

  likeActions(item, like_type): any {
    if (item.new_attr == like_type) {
      console.log('delete like');
      this.network
        .bpRun('hre_idea_like_remove', {
          idea_id: item.id,
          user_id: this.user['id'],
        })
        .subscribe((ped) => {
          console.log('delete bp ');
          if (item.new_attr == 1) {
            item.likes_id = parseInt(item.likes_id) - 1;
            item.new_attr = 0;
          } else {
            item.dislikes_id = parseInt(item.dislikes_id) - 1;
            item.new_attr = 0;
          }
        });

      return;
    }

    if (item.new_attr != like_type && item.new_attr != 0) {
      console.log('update like');
      let new_ltype = like_type;
      this.network
        .bpRun('hre_idea_draft', {
          id: item.id,
          user: this.user['id'],
          entity_code: 'hre_idea_center_like',
          like_type: new_ltype == 1 ? 1 : 0,
        })
        .subscribe((ped) => {
          console.log('update bp', ped);

          if (item.new_attr == 1) {
            item.likes_id = parseInt(item.likes_id) - 1;
            item.dislikes_id = parseInt(item.dislikes_id) + 1;
            item.new_attr = like_type;
          } else {
            item.dislikes_id = parseInt(item.dislikes_id) - 1;
            item.likes_id = parseInt(item.likes_id) + 1;
            item.new_attr = like_type;
          }
        });
    } else if (like_type == 1) {
      console.log('insertt poss like');

      this.network
        .insertTable('hre_idea_center_like', [
          {
            hre_idea_center_id: item.id,
            user_id: this.user['id'],
            is_liked: 1,
          },
        ])
        .subscribe((ree) => {
          if (!ree['error']) {
            console.log('insert bp', ree);
            item.new_attr = 1;
            item.likes_id = parseInt(item.likes_id) + 1;
          }
        });
    } else if (like_type == -1) {
      // new negative like
      console.log('insert neg  like');
      this.network
        .insertTable('hre_idea_center_like', [
          {
            hre_idea_center_id: item.id,
            user_id: this.user['id'],
            is_liked: 0,
          },
        ])
        .subscribe((ree) => {
          if (!ree['error']) {
            console.log('insert bp', ree);
            item.new_attr = -1;
            item.dislikes_id = parseInt(item.dislikes_id) + 1;
          }
        });
    }
  }

  // actionLike(ideaI){
  // if(this.ideas.find(ff=>ff['id']==ideaI)['new_attr']==1){
  //   this.network.bpRun('hre_idea_like_remove',{idea_id:ideaI, user_id:this.user['id']})
  //     .subscribe(ped=>{
  //       this.ideas.find(cv=>cv.id==ideaI)['new_attr']=0;
  //       this.ideas.find(cv=>cv.id==ideaI)['likes_id']=parseInt(this.ideas.find(cv=>cv.id==ideaI)['likes_id'])-1
  //     })
  // }else{
  //   this.network.insertTable('hre_idea_center_like',[{hre_idea_center_id:ideaI, user_id:this.user['id'],is_liked:1}])
  //   .subscribe(ree=>{
  //     if (!ree['error']){
  //       this.ideas.find(cv=>cv.id==ideaI)['new_attr']=1;
  //       this.ideas.find(cv=>cv.id==ideaI)['likes_id']=parseInt(this.ideas.find(cv=>cv.id==ideaI)['likes_id'])+1;
  //     }
  //   })
  //   if(this.ideas.find(ff=>ff['id']==ideaI)['new_attr']==0){
  //     this.addAction(ideaI,true);
  //     this.ideas.find(cv=>cv.id==ideaI)['new_attr']=1;
  //   }else if(this.ideas.find(ff=>ff['id']==ideaI)['new_attr']==-1){
  //     this.removeAction(ideaI,false);
  //     this.addAction(ideaI,true);
  //     this.ideas.find(cv=>cv.id==ideaI)['new_attr']=1;
  //   }else if(this.ideas.find(ff=>ff['id']==ideaI)['new_attr']==1){
  //     this.removeAction(ideaI,false);
  //     this.ideas.find(cv=>cv.id==ideaI)['new_attr']=1;
  //   }

  // }
  // actionDislike(ideaI){
  //   if(this.ideas.find(ff=>ff['id']==ideaI)['new_attr']==0){
  //     this.addAction(ideaI,false);
  //     this.ideas.find(cv=>cv.id==ideaI)['new_attr']=-1;
  //   }else if(this.ideas.find(ff=>ff['id']==ideaI)['new_attr']==1){
  //     this.removeAction(ideaI,true);
  //     this.addAction(ideaI,false);
  //     this.ideas.find(cv=>cv.id==ideaI)['new_attr']=-1;
  //   }else if(this.ideas.find(ff=>ff['id']==ideaI)['new_attr']==-1){
  //     this.removeAction(ideaI,false);
  //     this.ideas.find(cv=>cv.id==ideaI)['new_attr']=0;
  //   }

  // }
  // removeAction(ideaI,typeL:boolean){
  //   console.log("remove like",typeL,ideaI);
  //   this.network.bpRun('hre_idea_like_remove',{idea_id:ideaI, user_id:this.user['id']})
  //       .subscribe(ped=>{
  //         console.log("remove like network",ped);
  //         if(ped['ok']){
  //           (typeL==true)?(this.ideas.find(cv=>cv.id==ideaI)['likes_id']=parseInt(this.ideas.find(cv=>cv.id==ideaI)['likes_id'])-1):(this.ideas.find(cv=>cv.id==ideaI)['dislikes_id']=parseInt(this.ideas.find(cv=>cv.id==ideaI)['dislikes_id'])-1);
  //         }
  //       })
  // }
  // addAction(ideaI,typeL:boolean){
  //   console.log("put like",typeL,ideaI);
  //   this.network.insertTable('hre_idea_center_like',[{hre_idea_center_id:ideaI, user_id:this.user['id'],is_liked:(typeL==true)?1:0}])
  //     .subscribe(ree=>{
  //       console.log("put like network",ree);
  //       if (!ree['error']){
  //         (typeL==true)?(this.ideas.find(cv=>cv.id==ideaI)['likes_id']=parseInt(this.ideas.find(cv=>cv.id==ideaI)['likes_id'])+1):(this.ideas.find(cv=>cv.id==ideaI)['dislikes_id']=parseInt(this.ideas.find(cv=>cv.id==ideaI)['dislikes_id'])+1);

  //       }
  //     })
  // }
}

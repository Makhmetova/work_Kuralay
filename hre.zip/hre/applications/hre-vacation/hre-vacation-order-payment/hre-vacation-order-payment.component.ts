import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { AccountService, DbQueryService, MainService } from '@app/_services';

@Component({
  selector: 'app-hre-vacation-order-payment',
  templateUrl: './hre-vacation-order-payment.component.html',
  styleUrls: ['./hre-vacation-order-payment.component.less']
})
export class HreVacationOrderPaymentComponent implements OnInit {
  detail: Object = {};
  order_detail: Object;
  decree_values = [];
  sent_by : Object;
  new_order =false;
  dec_id: number;
  id: number;
  table = 'hre_vpy';
  @Output() onSave = new EventEmitter<Object>();
  @Output() onStart= new EventEmitter<Object>();
  @Output() onAction= new EventEmitter<Object>();
  @Output() openRoute = new EventEmitter<Object>();
  @Output() onClose = new EventEmitter<Object>();
  constructor(private network: DbQueryService,
    private accountService: AccountService,
    private main: MainService) {
      this.detail = {};
      this.decree_values = [];
    }
 order_id:number;
  ngOnInit(): void {
    this.order_id = this.detail['id'];
    console.log('RR', this);
    if (this['parentDetail']) {
      this.detail['sender'] = this['parentDetail']['sent_by'];
      this.detail['day_count'] = this['parentDetail']['day_count'];
      this.detail['start_date'] = this['parentDetail']['start_date'];
      this.detail['end_date'] = this['parentDetail']['end_date'];
      this.dec_id = this['parentDetail']['decree_id'];
      this.id = this['parentDetail']['id'];
      this.getData();
    } else {
      console.log("FFF");
      this.new_order = false;
      this.order_detail = this.detail;
      this.network.getDetail("hre_vacation_new", this.detail['parent_id']).subscribe(res => {
        let det = res['hre_vacation_new'][0];
        this.id = det['id'];
        this.dec_id = det['decree_id'];
        this.getData();

      })
    }
    this.network.executeQuery(`code=users&flt$id$eq$=${this.detail['sender']}`,'get').subscribe(res =>{
      this.sent_by = res.items[0];
        console.log( this.sent_by);

    })

    this.onAction.subscribe((val) => {

      if (val['approve_res_id'] == 2) {
        this.network
          .bpRun('hre_update_order', {
            entity_code: this.table,
            req_id: this.detail['id'],
            status_id: 5,
          })
          .subscribe((res) => {});
      } else {
        this.network
          .bpRun('hre_update_order', {
            entity_code: this.table,
            req_id: this.detail['id'],
            status_id: 4,
          })
          .subscribe((res) => {});
      }
    });
    this.onStart.subscribe(val => {
      this.onClose.emit({});
      this.main.toastSuccess("Заказ отправлен!")
    })

  }

  getData() {
    this.network
      .executeQuery(
        `code=hre_vacation_new_decree&flt$entity_pk$eq$=${this.id}&flt$id$eq$=${this.dec_id}`,
        'get'
      )
      .subscribe((res) => {
        this.decree_values = res.items;
      });
  }
  send() {
    this.detail['status_id']  = 1;
    this.detail['priority'] = 2;
    // this.order_detail['stage'] = 14; //stage
    // this.order_detail['stage_id'] = 52;
    this.detail['req_code'] = "hre_vacation_new";
    this.detail['req_id'] = this.detail['id'];
    // this.order_detail['division'] = 182;
    this.network
      .insertTable('hre_vpy', [this.detail])
      .subscribe((res) => {
        console.log(res);
        this.onSave.emit({
          data : this.detail,
          code : "hre_vpy",
          id : res.items[0]['last_insert_id']
        });
        this.network
        .getDetail('hre_vpy', res.items[0]['last_insert_id'])
        .subscribe((res) => {
          this.openRoute.emit({});
        });

      });
  }
  close(){
    this.onClose.emit({})
  }
}

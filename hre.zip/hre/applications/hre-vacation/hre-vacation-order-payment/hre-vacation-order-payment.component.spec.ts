import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HreVacationOrderPaymentComponent } from './hre-vacation-order-payment.component';

describe('HreVacationOrderPaymentComponent', () => {
  let component: HreVacationOrderPaymentComponent;
  let fixture: ComponentFixture<HreVacationOrderPaymentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HreVacationOrderPaymentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HreVacationOrderPaymentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VacationAddInfoComponent } from './vacation-add-info.component';

describe('VacationAddInfoComponent', () => {
  let component: VacationAddInfoComponent;
  let fixture: ComponentFixture<VacationAddInfoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VacationAddInfoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(VacationAddInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

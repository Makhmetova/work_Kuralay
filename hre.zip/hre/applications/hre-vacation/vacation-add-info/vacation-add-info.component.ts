import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-vacation-add-info',
  templateUrl: './vacation-add-info.component.html',
  styleUrls: ['./vacation-add-info.component.less']
})
export class VacationAddInfoComponent implements OnInit, OnChanges {

  @Input() details: any;
  @Input() vacation_balance: any[];
  vacation_balance_table: any[] = [];
   isDisabled: boolean = false;
  minimumDate: Date;
  constructor(
  ) {
    this.minimumDate = new Date();
   }


  ngOnInit(): void {
  }

  ngAfterViewInit() {
    if(this.details['hre_vacation_new'][0]['decree_id']) {
      this.isDisabled = true;
    }

  }

  ngOnChanges(changes: SimpleChanges): void {
    console.log("Vacation add info: ", changes);
    if (changes.vacation_balance) {
      this.bind();
    }
  }

  bind() {
    this.vacation_balance_table = [];
    this.vacation_balance.forEach(item => {
      let find = this.details ? this.details["hre_vacation_table"].find(vt => vt.guid == item["ГуидВидЕжегодногоОтпуска"]) : null;

      this.vacation_balance_table.push({
          type: item["ВидЕжегодногоОтпуска"].toLowerCase(),
          guid: item["ГуидВидЕжегодногоОтпуска"],
          startPeriod: item["ДатаНачала"],
          endPeriod: item["ДатаОкончания"],
          day_count: item["КоличествоДней"],
          is_main: item["ОсновнойОтпуск"],
          customer: item["Сотрудник"],
          startDate: find ? new Date(find.start_date) : null,
          endDate: find ? new Date(find.end_date) : null,
          dayCount: find ? find.day_count : null,
          checked: find ? true : false
      });
    });
    console.log("Bind Vacation balance table: ", this.vacation_balance_table);
  }

  onChangeCheckbox(data) {
    console.log("Data: ", data);
    console.log("Vacation table: ", this.details["hre_vacation_table"]);
    let find = this.details["hre_vacation_table"].find(vt => vt.guid == data.guid);
    if (data.checked == '1') {
        if (find) {
            find._deleted = 0;
            find.day_count = data.dayCount;
            find.end_date = data.endDate;
            find.end_period = data.endPeriod;
            find.guid = data.guid;
            find.start_date = data.startDate;
            find.start_period = data.startPeriod;
            find.title = data.type;

            console.log("Val: ", find);
        } else {
            this.addhre_vacation_table();
            let val = this.details["hre_vacation_table"][this.details["hre_vacation_table"].length - 1];
            val.title = data.type;
            val.day_count = data.dayCount;
            val.end_date = data.endDate;
            val.end_period = data.endPeriod;
            val.guid = data.guid;
            val.start_date = data.startDate;
            val.start_period = data.startPeriod;

            console.log("Val: ", val);
        }

    } else {
        this.delhre_vacation_table(find);
    }
  }

  addhre_vacation_table () {
    this.details["hre_vacation_table"].push({ _inserted:1, vacation_id: this.details['hre_vacation_new'][0]['id'] });
  }

  delhre_vacation_table (item) {
    item._deleted = 1;
  }

  edithre_vacation_table (item) {
    console.log(item, 'cakebdar');
    let find = this.details["hre_vacation_table"].find(vt => vt.guid == item.guid);
    find.day_count = item.dayCount;
    find.end_date = item.endDate;
    find.start_date = item.startDate
    console.log(find);

    find._edited = 1;
  }
}

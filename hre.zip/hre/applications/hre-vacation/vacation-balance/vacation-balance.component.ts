import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-vacation-balance',
  templateUrl: './vacation-balance.component.html',
  styleUrls: ['./vacation-balance.component.less']
})
export class VacationBalanceComponent implements OnInit, OnChanges {

  @Input() vacation_balance: any[];
  vacation_balance_group: any[] = [];

  constructor() { }

  ngOnChanges(changes: SimpleChanges): void {
    if(changes.vacation_balance) {
      this.bind();
    }
  }

  ngOnInit(): void {
  }

  ngAfterViewInit() {
  }

  bind() {
    this.vacation_balance_group = [];
    this.vacation_balance.forEach(item => {
      let find_period = this.vacation_balance_group.find(vt => {
          return (new Date(vt.startPeriod).getFullYear() == new Date(item["ДатаНачала"]).getFullYear());
      });

      if (!find_period) {
          this.vacation_balance_group.push({
              type: "Оплачиваемый ежегодный трудовой отпуск",
              startPeriod: item["ДатаНачала"],
              endPeriod: item["ДатаОкончания"],
              day_count: item["КоличествоДней"]
          });
      } else {
          find_period.day_count += item["КоличествоДней"];
      }
    });
  }
}

import {
  Component,
  EventEmitter,
  Input,
  OnChanges,
  OnInit,
  Output,
  SimpleChanges,
  ViewChild,
  ViewContainerRef,
} from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { RunTaskResponse,} from '@app/_models';
import { AccountService,  DbQueryService } from '@app/_services';
import { LookupService } from '@app/_services/lookupService.service';
import { MainService } from '@app/_services/main.service';
import { DatePipe } from '@angular/common';
@Component({
  selector: 'app-detail-form',
  templateUrl: './detail-form.component.html',
  styleUrls: ['./detail-form.component.less'],
})
export class DetailFormComponent implements OnInit, OnChanges {
  @Input() detailId: number;
  entity_code = 'hre_vacation_new';
  @Input() details: any;
  @Output() onSave = new EventEmitter<Object>();
  @Output() openRoute = new EventEmitter<Object>();
  @Output() onUpdate = new EventEmitter<Object>();
  @Output() onClose = new EventEmitter<Object>();
  @Input() onAction = new EventEmitter<Object>();
  @Input() onStart = new EventEmitter<Object>();
  entity_attrs: any[] = [];
  executors: any[] = [];
  vacation_types: any[] = [];
  statuses: any[] = [];
  sessionRoles: Object;
  detail: Object;
  form: FormGroup;
  showForExecutor = true;
  userId: string;
  user: Object;
  vacation_balance: any[] = [];

  approve_res: Array<Object>;
  minimumDate: Date;
  decree_id: number;
  decree_values = [];
  users: Array<Object>;
  toDelegate: boolean = false;
  delegate_users;
  delegators = [];
  entityOneActions: Array<Object>;
  showSaveBtn: boolean = false;
  last_id: number;
  onec_start_front: boolean;

  constructor(
    private main: MainService,
    private dbQueryService: DbQueryService,
    private accountService: AccountService,
    private lookup: LookupService,
    public datepipe: DatePipe
  ) {
    this.delegators = [];
    this.details = {};
    this.users = [];
    this.minimumDate = new Date();
    this.showForExecutor = true;
    this.showSaveBtn = false;
    this.onec_start_front = false;

  }

  ngOnInit(): void {
    if(this.detail['onec_start'] == 'undefined' || this.detail['onec_start'] == null || this.detail['onec_start'] == '0'){
      this.onec_start_front = true;
    }
    else{
      this.onec_start_front = false;
    }
    console.log("onec_start",this.onec_start_front);


    this.entityOneActions = [
      {
        label: 'Изменить',
        disabled:  this.onec_start_front == false,
        command: () => {
          this.editForm();
        },

      },
      {
        label: 'Отправить в 1С',
        disabled:  this.onec_start_front ,
        command: () => {
          this.onecSend();
        },

      },
    ];

    this.delegators = [];
    console.log("Id", this.detailId);


    this.lookup.getLookup('users_select').subscribe((us) => {
      if (us['items'] && us['items'].length > 0) {
        this.users = us['items'];
      }
        this.detailId == 0
          ? ( this.accountService.getSession().subscribe(val=>{
            this.userId = val['sessioninfo']['id'];
          }) )
          : (this.userId = this.detail['sent_by'] );
        this.getVacationBalance();
        if (this.details) {
          let del = this.details['hre_vacation_delegate'];

          this.detail['executor']
            ? (this.showForExecutor = true)
            : (this.showForExecutor = false);
          console.log('DEl', del);

          del.forEach((x) => {
            this.accountService.getById(x['delegate_to']).subscribe((value) => {
              console.log(value);
              let tempUs = value['users'][0];
              this.delegators.push(tempUs);
              console.log(this.delegators);
            });
          });

          let length = this.details['hre_vacation_decree'].length;
          console.log('Length', length);
          length == 0
            ? (this.decree_values = this.details['hre_vacation_decree'])
            : this.decree_values.push(
                this.details['hre_vacation_decree'][length - 1]
              );
          console.log('Decree', this.delegators);
        }

    });

    console.log('DDD', this.details, this.detailId);

    this.sessionRoles = {};
    this.accountService.userValue.session_roles.forEach((r) => {
      this.sessionRoles[r.code] = true;
    });
    this.user = this.accountService.userValue.sessioninfo;

    this.getItemsSelect('hre_vacation_types_select', '')
      .toPromise()
      .then((res) => {
        this.vacation_types = res.items;
        this.getEntityAttrs(this.entity_code);
      });
    this.onStart.subscribe((res) => {
      this.onClose.emit({});
      this.main.toastSuccess('Ваша заявка принята!');
      this.dbQueryService
        .getDetail(this.entity_code, this.last_id)
        .subscribe((resp) => {
          this.delegators.forEach((x) => {
            let params = {
              vacation_id: resp[this.entity_code][0]['id'],
              delegate_from: resp[this.entity_code][0]['sent_by'],
              delegate_to: x.id,
              title: x.id,
            };
            this.dbQueryService
              .insertTable('hre_delegate_list', [params])
              .subscribe((res) => {});
          });
        });
    });
    this.onAction.subscribe((val) => {

          if (val['approve_res_id'] == 1) {
            //soglasovana
            this.bpRun('hre_new_req', {
              entity_code: this.entity_code,
              pk: this.details[this.entity_code][0]['sys$uuid'],
              req_id: this.detailId,
              action: 'approveEnd',
            });
          }else if (val['approve_res_id'] == 2) {
            this.detail["status_id"] = "5"
            this.dbQueryService
            .updateTable(this.entity_code, [this.detail])
            .subscribe((val) => {
            });
          }
    });
  }

  ngAfterViewInit() {}

  ngOnChanges(changes: SimpleChanges): void {
    console.log('On changes: ', changes);
    if (changes.details && this.form) {
      if (!changes.details.currentValue) {
        this.formControls();
      } else {
        this.bind();
      }
    }
  }
  onChangeSwitch(e) {
    if (e.checked == true) {
      this.toDelegate = true;
    } else {
      this.toDelegate = false;
      this.delegators = [];
    }
  }
  convert(event){
    // this.detail['end_date'] = this.datepipe.transform(new Date(event), 'yyyy-mm-dd');
    // console.log("end_date", this.detail['end_date']);

  }
  setEndDate(event) {
    this.detail['start_date'] = this.datepipe.transform(new Date(event), 'yyyy-MM-dd');
    console.log("start_date", this.detail['start_date']);
    console.log('Controld', this.form);
    let total = this.form.controls.day_count.value;
    let start = this.form.controls.start_date.value;
    let end = new Date(start);
    end.setDate(end.getDate() + Number(total) - 1);
    this.form.controls.end_date.setValue(end);
    this.form.controls.start_date.setValue(this.datepipe.transform(new Date(event), 'yyyy-MM-dd'));
    this.form.controls.end_date.setValue(this.datepipe.transform(new Date(end), 'yyyy-MM-dd'));

    console.log("AftEEER",  this.form.controls );

  }
  editForm() {
    Object.keys(this.form.controls).forEach((key) => {
      this.form.controls[key].enable();
    });
    this.toDelegate = true;
    this.showSaveBtn = true;
  }



  onecSend(){



    if(this.detail['onec_start'] == 1){
    this.dbQueryService
              .bpRun('hre_vacation_request', {

               id : this.detail['id']
              })
              .subscribe((res) => {
              if(res['errorText'] == ""){
                this.main.toastSuccess("Успешно удалость отправить в 1С ");
              } else{
                this.main.toastWarning("Не удалость отправить в 1С ");
              }

           });

  }else{
    this.main.toastWarning("Не удалость отправить в 1С ");
  }

  }
  addDelegate() {
    let tempUs = {};
    console.log(this.delegate_users);

    this.accountService.getById(this.delegate_users).subscribe((value) => {
      console.log(value);

      tempUs = value['users'][0];
      console.log('ddd', this.delegators.indexOf(tempUs));

      this.delegators.some((x) => x['id'] == tempUs['id']) == true
        ? this.main.toastError('Вы уже добавили данного пользователя')
        : this.delegators.push(tempUs);
      console.log(this.delegators);
    });

    this.delegate_users = null;
  }
  delDelegate(user) {
    this.delegators.indexOf(user) > -1
      ? this.delegators.splice(this.delegators.indexOf(user), 1)
      : console.log();
  }

  bind() {
    let patchVal = {};
    for (let param of Object.keys(this.form.getRawValue())) {
      if (param == 'start_date' || param == 'end_date') {
        patchVal[param] = new Date(this.details[this.entity_code][0][param]);
      } else {
        patchVal[param] = this.details[this.entity_code][0][param];
      }
    }
    this.form.patchValue(patchVal);
    console.log("dates");

  }

  getEntityAttrs(code: string) {
    let query = this.dbQueryService
      .getEntityAttrsByCode(code)
      .subscribe((res) => {
        console.log('Ent', res);

        this.entity_attrs = res.items;
        this.formControls();
        query.unsubscribe();
      });
  }

  formControls() {
    this.form = new FormGroup({});
    for (let item of this.entity_attrs) {
      let control: FormControl = new FormControl(null);
      let validators = [];
      if (Number(item['rq'])) {
        validators.push(Validators.required);
      }
      control.setValidators(validators);
      this.form.addControl(item['code'], control);
    }

    // console.log(this.details);
    if (this.details) {
      this.bind();
    }
    console.log('Foorm', this.form);

    if (this.detail['id']) {
      this.makeDisable();
      this.form.controls['mat_help_amount'].enable();
      this.form.controls['graphic_type'].enable();
      this.form.controls['work_start'].enable();
      //this.getDetails(this.detail['id']);
    }
    if (this.detail['decree_id']) {
      this.makeDisable();
    }
  }

  getItemsSelect(code: string, _query?: string, params?: Object) {
    return this.dbQueryService.getQuerySelect(code, _query, 100, params);
  }

  save() {
    if (this.detailId) {
      //update
      this.showSaveBtn = false;
      this.showForExecutor = false;
      let observable_arr = [];

      console.log("ddddd",this.form.get('start_date').value);

      this.form.controls.start_date.setValue(this.datepipe.transform(new Date(this.form.get('start_date').value), 'yyyy-MM-dd'));
      this.form.controls.end_date.setValue(this.datepipe.transform(new Date(this.form.get('end_date').value), 'yyyy-MM-dd'));

      console.log("Befor upd",this.form.getRawValue());

      observable_arr.push(
        this.dbQueryService
          .updateTable(this.entity_code, [this.form.getRawValue()])
          .subscribe((val) => {
            console.log('getform', this.form.getRawValue());
            if (val['error_text'] === 'OK') {
              this.main.toastSuccess('Заявка обновлена!');

              if (this.detail['executor']) {
                this.dbQueryService
                  .bpRun('hre_application_approve', {
                    entity_code: this.entity_code,
                    pk: this.detailId,
                    pk_uuid: this.detail['sys$uuid'],
                    ord_id: ''
                  })
                  .subscribe((res) => {
                    console.log('BP res hre_application_approve', res)
                    this.getDetails(this.detailId);
                  });
              }
            }
            // console.log('updated', val);
          })
      );
      console.log('MM', this.details['hre_vacation_table']);

      let update_table = this.details['hre_vacation_table'].filter(function (
          item
        ) {
          return item._edited == 1 && item._inserted != 1;
        }),
        insert_table = this.details['hre_vacation_table'].filter(function (
          item
        ) {
          return item._inserted == 1 && item._deleted != 1 && item._edited == 1;
        }),
        delete_table = this.details['hre_vacation_table'].filter(function (
          item
        ) {
          return item._inserted != 1 && item._deleted == 1;
        });

      if (update_table.length > 0) {
        console.log(update_table, 'upd');

        this.dbQueryService
          .updateTable('hre_vacation_table_new', update_table)
          .subscribe((res) => {
            console.log('when update again')
          });
      }
      if (insert_table.length > 0) {
        console.log('Insert');

        this.dbQueryService
          .insertTable('hre_vacation_table_new', insert_table)
          .subscribe((res) => {});
      }
      if (delete_table.length > 0) {
        this.dbQueryService
          .deleteBulk('hre_vacation_table_new', delete_table)
          .subscribe((res) => {});
      }

      // this.lookup.getLookup('hre_delegate_list').subscribe((res) => {
      //   let resp = res['items'].filter(x => x.vacation_id = this.detailId);

      //   resp.forEach(x => {
      //     this.dbQueryService.deleteTable("hre_delegate_list", x.id).subscribe(res => {
      //     })
      //     this.delegators.forEach(x => {
      //       let params = {
      //         vacation_id: this.detailId,
      //         delegate_from: this.detail['sent_by'],
      //         delegate_to: x.id,
      //         title: x.id
      //       }
      //       this.dbQueryService.insertTable("hre_delegate_list", [params]).subscribe(res => {
      //       });
      this.makeDisable();
      // this.detail['start_date'] = this.datepipe.transform(new Date(this.setEndDate(event)), 'yyyy-MM-dd');
      //     })
      //   });
      // });
    } else {
      //insert
      this.form.controls['status_id'].setValue(1);
      this.form.controls['priority'].setValue(2);
      this.form.controls['user_group'].setValue(1);
      this.form.controls['stage'].setValue(14); //stage
      this.form.controls['stage_id'].setValue(52);
      this.form.controls['title'].setValue("Заявка на отпуск");

      this.dbQueryService
        .insertTable(this.entity_code, [this.form.getRawValue()])
        .subscribe((res) => {
          console.log('REs', res);

          if (res['error']) {
            this.main.toastError(res['error_text']);
          } else {
            this.onSave.emit({
              data: this.form.getRawValue(),
              code: this.entity_code,
              id: res.items[0]['last_insert_id'],
            });
            this.last_id = res.items[0]['last_insert_id'];
            this.dbQueryService
              .bpRun('hre_new_req', {
                entity_code: this.entity_code,
                pk: res.items[0]['sys$uuid'],
                req_id: res.items[0]['last_insert_id'],
                action: 'new',
              })
              .subscribe((res) => {
                this.openRoute.emit({});
              });
          }
        });
    }
    console.log("end_date", this.detail['end_date']);
    console.log("start_date", this.detail['start_date']);

  }
  bpRun(code: string, input: any) {
    this.dbQueryService
      .bpRun(code, input)
      .subscribe((resp: RunTaskResponse) => {
        console.log(code + ': ', resp);
        if (resp.ok) {
          if (resp.instanceIsFinished) {
            if (!resp.output.last_error) {
              //this.main.toastSuccess('Успешно');
              this.getDetails(this.detailId);
            } else {
              this.main.toastError(resp.output.last_error);
            }
          } else if (resp.task) {
            // this.openBpModal();
            // this.getUserTaskData(resp.task);
          } else {
            this.main.toastInfo('BPM Run', 'Процесс запущен.');
          }
        } else {
          this.main.toastError('Ошибка! Что-то пошло не так.');
        }
      });
  }
  getDetails(id: number) {
    this.delegators = [];
    let query = this.dbQueryService
      .getDetail(this.entity_code, id)
      .subscribe((res) => {
        let m = this.users.filter((y) => {
          return y['id'] == '16';
        });
        console.log('MM', m);

        if (res) {
          this.details = res;
          this.detail = res[this.entity_code][0];
          this.userId = res[this.entity_code][0]['created_by'];
          let del = res['hre_vacation_delegate'];

          this.detail['executor']
            ? (this.showForExecutor = true)
            : (this.showForExecutor = false);
          console.log('DEl', del);

          del.forEach((x) => {
            this.accountService.getById(x['delegate_to']).subscribe((value) => {
              console.log(value);
              let tempUs = value['users'][0];
              this.delegators.push(tempUs);
              console.log(this.delegators);
            });
          });

          let length = this.details['hre_vacation_decree'].length;
          console.log('Length', length);
          length == 0
            ? (this.decree_values = this.details['hre_vacation_decree'])
            : this.decree_values.push(
                this.details['hre_vacation_decree'][length - 1]
              );
          console.log('Decree', this.delegators);

         // this.getVacationBalance();
          console.log('Form', this.form);
        }
        query.unsubscribe();
      });
  }

  getVacationBalance() {
    console.log('Get', this.userId);
    let query = this.dbQueryService
      .restapiGet('vacation_balance', {
        user_id: this.userId,
        datetime: new Date(),
      })
      .subscribe((res) => {
        if (res['result']['success']) {
          this.vacation_balance = res['result']['VacationBalance'];
        } else {
          this.main.toastError(res['result']['error']);
        }
        query.unsubscribe();
      });
  }

  cancel() {
    if (this.detailId) {
      this.ngOnInit();
      this.toDelegate = false;
      this.makeDisable();
      this.showSaveBtn = false;
    } else {
      this.onClose.emit({});
    }
  }
  makeDisable() {
    Object.keys(this.form.controls).forEach((key) => {
      this.form.controls[key].disable();
    });
  }
  ngOnDestroy() {}
}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VacationOrderFormComponent } from './vacation-order-form.component';

describe('VacationOrderFormComponent', () => {
  let component: VacationOrderFormComponent;
  let fixture: ComponentFixture<VacationOrderFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VacationOrderFormComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(VacationOrderFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HreVacationComponent } from './hre-vacation.component';

describe('HreVacationComponent', () => {
  let component: HreVacationComponent;
  let fixture: ComponentFixture<HreVacationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HreVacationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HreVacationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

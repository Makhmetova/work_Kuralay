import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AnnualScheduleComponent } from './annual-schedule.component';

describe('AnnualScheduleComponent', () => {
  let component: AnnualScheduleComponent;
  let fixture: ComponentFixture<AnnualScheduleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AnnualScheduleComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AnnualScheduleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

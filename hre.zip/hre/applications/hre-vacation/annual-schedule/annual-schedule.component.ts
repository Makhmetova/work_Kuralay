import { Component, Input, OnInit } from '@angular/core';
import { QueryOptions, User } from '@app/_models';
import { AccountService, DbQueryService } from '@app/_services';
import { MainService } from '@app/_services/main.service';

@Component({
  selector: 'app-annual-schedule',
  templateUrl: './annual-schedule.component.html',
  styleUrls: ['./annual-schedule.component.less']
})
export class AnnualScheduleComponent implements OnInit {

  @Input() details: Object;
  entity_code: string = "hre_ann_sch_table";
  month_arr: any[];
  ann_schedule: { month_values: any[] }[] = [];
  @Input() userId: number;
  month_values = [];
  constructor(
    private dbQueryService: DbQueryService,
    private mainService: MainService
  ) { }

  ngOnInit(): void {
    //this.bind();
    console.log("I am here");
    let options = new QueryOptions(this.entity_code);
    options.flteq = {
      user_id: this.userId
    }
    this.dbQueryService.getQuery(options)
      .subscribe(res => {
        if (res.items) {
          //let month_values = [];
          res['items'].forEach(m => {

            this.month_values.push({
              plan_day: m['plan_day'] ,
              fact_day: m['fact_day'],
              month: m['month$']
            });
          });

          this.ann_schedule.push({ month_values: this.month_values });
          console.log("Godovoi grafik: ", this.month_values);
          console.log("Godovoi grafiшшшk: ", this.ann_schedule);
        }
      })
  }

  ngAfterViewInit() {}

  bind() {
    this.dbQueryService.getQuerySelect("months_cls_select")
      .subscribe(res => {
        if (res.items) {
          this.month_arr = res.items;
          this.getAnnualSchedule();
        }
      });
  }

  getAnnualSchedule() {
    let options = new QueryOptions(this.entity_code);
    options.flteq = {
      user_id: this.userId
    }
    this.dbQueryService.getQuery(options)
      .subscribe(res => {
        if (res.items) {
          //let month_values = [];
          this.month_arr.forEach(m => {
            let find = res.items.find(e => e['month'] == m.id);
            this.month_values.push({
              plan_day: find ? find['plan_day'] : null,
              fact_day: find ? find['fact_day'] : null,
              month: find['month$']
            });
          });

          this.ann_schedule.push({ month_values: this.month_values });
          console.log("Godovoi grafik: ", this.month_values);
          console.log("Godovoi grafiшшшk: ", this.ann_schedule);
        }
      })
  }
}

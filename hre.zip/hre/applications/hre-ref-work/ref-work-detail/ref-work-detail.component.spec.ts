import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RefWorkDetailComponent } from './ref-work-detail.component';

describe('RefWorkDetailComponent', () => {
  let component: RefWorkDetailComponent;
  let fixture: ComponentFixture<RefWorkDetailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RefWorkDetailComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RefWorkDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

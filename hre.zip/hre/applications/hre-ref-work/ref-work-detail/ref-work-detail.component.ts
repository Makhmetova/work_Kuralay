
import {
  Component,
  Input,
  OnInit,
  SimpleChanges,
  ViewChild,
  ViewContainerRef,
  EventEmitter,
  Output,
} from '@angular/core';

import { Router } from '@angular/router';
import { AccountService, DbQueryService } from '@app/_services';
import { MainService } from '@app/_services/main.service';
import { BuilderSerice } from '@app/_services/builder.service';

import { RunTaskResponse, UserInfo } from '@app/_models';
import { take } from 'rxjs/operators';
import { TreeNode } from 'primeng/api';

@Component({
  selector: 'app-ref-work-detail',
  templateUrl: './ref-work-detail.component.html',
  styleUrls: ['./ref-work-detail.component.less'],
})
export class RefWorkDetailComponent implements OnInit {
  @Input() detailId: number;
  @Input() entity_code?: string = 'hre_ref_work';
  @Input() details: any;
  //@Input() incomingParams: Object = {};
  @Input() applicant: UserInfo;
  detail: Object;
  @Output() doStart: EventEmitter<Object> = new EventEmitter<Object>();
  @Output() doAction = new EventEmitter<Object>();
  Start = new EventEmitter<Object>();
  executors: any[] = [];
  statuses: any[] = [];
  sessionRoles: Object;
  sysuuid: string;
  @ViewChild('approveFormHolder', { read: ViewContainerRef })
  approveFormHolder: ViewContainerRef;
  user: Object;
  user2: Object;
  users: Array<Object> = [];
  userId: number;
  showSaveBtn: boolean = false;
  showAdditional: boolean = false;
  uuid: String;
  //emitter: EventEmitter;

  @Input() currentTask: Object;
  @Input() approve_res: Array<Object>;
  @Output() onSave = new EventEmitter<Object>();
  @Output() onClose = new EventEmitter<Object>();
  @Output() openRoute = new EventEmitter<Object>();
  @Input() onAction = new EventEmitter<Object>();
  @Input() onStart = new EventEmitter<Object>();

  sessioninfo: Object;
  entityOneActions: Array<Object>;

  constructor(
    private main: MainService,
    private dbQueryService: DbQueryService,
    private session: AccountService,
  ) {
    this.detail = {};

    this.statuses = [];
    this.currentTask = null;
    this.entityOneActions = [
      {
        label: 'Изменить',
        command: () => {
          this.editForm();
        },
      },
    ];
  }

  ngOnInit(): void {
    this.sessionRoles = this.session.sessionRoles;
    this.getItemsSelect('users_select_by_roles', '', { param1: 'hr_manager' })
      .toPromise()
      .then((res) => {
        this.executors = res.items;
      })

    this.user2 = this.session.userValue;
    this.dbQueryService
      .executeQuery(
        `code=users&flt$id$eq$=${this.user2['sessioninfo'].id}`,
        'get'
      )
      .pipe(take(1))
      .subscribe((res) => {
        this.user = res.items[0];
        this.userId = this.user['id'];
        //console.log(this.user);
      });

    console.log('Detail', this.details[this.entity_code]);
    let query = this.dbQueryService
      .getDetail(this.entity_code, this.detailId)
      .subscribe((res) => {
        if (res && res[this.entity_code].length > 0) {
          this.details = res;
          this.detailId =  res[this.entity_code][0].id;
          this.detail = res[this.entity_code][0];

        }
        query.unsubscribe();
      });
    console.log('current', this.currentTask);

    this.onStart.subscribe(res => {
     this.onClose.emit({})
     this.main.toastSuccess("Заявка отправлена")
     this.detail['status_id'] = "3";
     this.detail['stage_id'] = "84";
     console.log("approva начался", this.detail );
     this.dbQueryService
        .updateTable(this.entity_code, [this.detail])
        .subscribe((val) => {
          this.bpRun('hre_ref_work', {
            entity_code: this.entity_code,
            pk: this.detailId,
            pk_uuid: this.uuid,
          });
        });
    })
    this.onAction.subscribe((val) => {
      console.log('after start log', val, this.detailId);
           if (val['approve_res_id'] == 2) {
            this.detail["status_id"] = "5"
            this.dbQueryService
            .updateTable(this.entity_code, [this.detail])
            .subscribe((val) => {

            });
          }
      });
  }

  ngAfterViewInit() {}

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.details) {
      //this.bind();
    }
  }
  bind() {}
  getItemsSelect(code: string, _query?: string, params?: Object) {
    return this.dbQueryService.getQuerySelect(code, _query, 100, params);
  }
  editForm() {
    // Object.keys(this.form.controls).forEach((key) => {
    //   this.form.controls[key].enable();
    // });
    this.showSaveBtn = true;
    this.showAdditional = true
    console.log("хочу эдитнуть");
    console.log("showSaveBtn editform", this.showSaveBtn);
  }

  save() {


    if (this.detailId != 0) {
      console.log('Dt', this.detail);

      this.dbQueryService
        .updateTable(this.entity_code, [this.detail])
        .subscribe((val) => {
          if (val['items'] && val['items'].length > 0) {
            console.log(val);
            this.onSave.emit({
              data: this.detail,
              code: this.entity_code,
              id: this.detailId,
            });
            this.bpRun('hre_ref_work', {
              entity_code: this.entity_code,
              pk: this.detailId,
              pk_uuid: this.detail['sys$uuid'],
            });
          }
          let historicalData =  {
            entity_code:this.entity_code,
            rec_id:this.detailId,
            title:`Пользователь ${this.user2['title']} обновил заявку`,
            created_by:this.user2['id']
          }
          this.dbQueryService.insertTable('core_global_history',[historicalData]).subscribe(res=>{
            console.log('After saving history: ',res);
          })
        });

        console.log("showSaveBtn", this.showSaveBtn);
        this.showSaveBtn = false;
        console.log("showSaveBtn", this.showSaveBtn);

      //this.doStart.emit({});
      //this.onClose.emit({});
    } else {


      this.detail['status_id'] = "1";
      this.detail['priority'] = "2";

      // this.entity_class.form.getRawValue()[0]['status']='1';
      // console.log(this.entity_class.form.getRawValue());

      this.dbQueryService
        .insertTable(this.entity_code, [this.detail])
        .subscribe((val) => {
          if (val['items'] && val['items'].length > 0) {
            console.log(val);
            this.detailId = val['items'][0]['last_insert_id'];
            this.detail['id'] = this.detailId;
            this.onSave.emit({
              data: this.detail,
              code: this.entity_code,
              id: this.detailId,
            });
            this.uuid = val.items[0]['sys$uuid'];
            this.dbQueryService.bpRun('hre_new_req', {
              entity_code: this.entity_code,
              pk: val.items[0]['sys$uuid'],
              req_id: val.items[0]['last_insert_id'],
              action: 'new',
            }).subscribe(res => {
              this.openRoute.emit({});
            });
          }
        });
      // .then((res) => {
      //   if (res['error']) {
      //     this.main.toastError(res['error_text']);
      //   } else {
      //     this.router.navigate(['/hre/services']);
      //     this.main.toastSuccess('Ваша заявка принята!');
      //   }
      // });
      console.log("новый стейдж",this.detail['status_id']);

    }

  }
  bpRun(code: string, input: any) {
    this.dbQueryService
      .bpRun(code, input)
      .subscribe((resp: RunTaskResponse) => {
        console.log(code + ': ', resp);
        if (resp.ok) {
          if (resp.instanceIsFinished) {
            if (!resp.output.last_error) {
              //this.main.toastSuccess('Успешно');
              this.getDetails(this.detailId);
            } else {
              this.main.toastError(resp.output.last_error);
            }
          } else if (resp.task) {
            // this.openBpModal();
            // this.getUserTaskData(resp.task);
          } else {
            this.main.toastInfo('BPM Run', 'Процесс запущен.');
          }
        } else {
          this.main.toastError('Ошибка! Что-то пошло не так.');
        }
      });
  }
  getDetails(id: number) {
    let query = this.dbQueryService
      .getDetail(this.entity_code, id)
      .subscribe((res) => {
        if (res) {
          this.details = res;
          this.detail = res[this.entity_code][0];
          let userId = res[this.entity_code][0]['created_by'];
          // this.dbQueryService
          //   .executeQuery(`code=users&flt$id$eq$=${userId}`, 'get')
          //   .pipe(take(1))
          //   .subscribe((res) => {
          //     this.user = res.items[0];
          //     console.log(this.user);
          //   });
          console.log(this.details);
          console.log('detail', this.detail);
          //this.getAllTasks();
        }
        query.unsubscribe();
      });
  }
  cancel() {
    this.onClose.emit({});
    //this.bind();
  }

  ngOnDestroy() {}
}


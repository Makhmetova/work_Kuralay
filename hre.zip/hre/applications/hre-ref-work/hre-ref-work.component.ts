import { StepInfoComponent } from './../step-info/step-info.component';
import { Location } from '@angular/common';
import {
  Component,
  EventEmitter,
  Input,
  OnInit,
  ViewChild,
  ViewContainerRef,
} from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PureApproveFormComponent } from '@app/_components/PureApprove/pureApprove.component';
import { RunTaskResponse } from '@app/_models';
import { APPROVE_RESULT } from '@app/_models/commands';
import { AccountService, DbQueryService, IStage } from '@app/_services';
import { BuilderSerice } from '@app/_services/builder.service';
import { MainService } from '@app/_services/main.service';
import { take } from 'rxjs/operators';

@Component({
  selector: 'app-hre-ref-work',
  templateUrl: './hre-ref-work.component.html',
  styleUrls: ['./hre-ref-work.component.less'],
})
export class HreRefWorkComponent implements OnInit {
  @ViewChild('approveFormHolder', { read: ViewContainerRef })
  approveFormHolder: ViewContainerRef;

  entity_code: string = 'hre_ref_work';
  @Input() detailId: number;
  details: any = [];
  @Input() detail: Object;
  doStart = new EventEmitter<Object>();
  doAction = new EventEmitter<Object>();
  userId: string;
  user: Object = {};
  applicant: Object;
  emitter: EventEmitter<any>;

  displayEdsModal: boolean = false;
  task_manager_id: number;
  currentTask: Object;
  allTasks: Array<Object>;
  approve_res: Array<Object>;
  tasks: Array<Object>;

  @ViewChild('status', { read: ViewContainerRef }) status: ViewContainerRef;
  constructor(
    private location: Location,
    private dbQueryService: DbQueryService,
    private mainService: MainService,
    private accountService: AccountService,
    private route: ActivatedRoute,
    private factory: BuilderSerice
  ) {
    this.emitter = new EventEmitter();
    this.detail = {};
    this.tasks = [];
  }

  ngOnInit(): void {

    this.route.params.subscribe((params) => {
      this.detailId = Number(params['id']);
      console.log(this.detailId);
    })
    console.log(this.detailId);
    if (this.detailId) {
      this.getDetails(this.detailId);
    } else {
      this.accountService.getSession().subscribe((res) => {
        this.userId = res.sessioninfo['id'];
        this.user = res.sessioninfo;
        //this.buildStatus();
      });
      //console.log(this.userId);
      //StepInfoComponent
     // this.details = {};
    }
  }
  ngAfterViewInit() {
    this.factory.MountComponent(this.status, StepInfoComponent, {
      table_name: this.entity_code,
      id: this.detailId,
      detail: this.detail,
      details: this.details,
    });
  }
  getDetails(id: number) {
    let query = this.dbQueryService
      .getDetail(this.entity_code, id)
      .subscribe((res) => {
        if (res) {
          this.details = res;
          this.detail = res[this.entity_code][0];
          this.userId = res[this.entity_code][0]['created_by'];
          this.detailId = res[this.entity_code][0]['id'];
          this.dbQueryService
            .executeQuery(`code=users&flt$id$eq$=${this.userId}`, 'get')
            .pipe(take(1))
            .subscribe((res) => {
              this.user = res.items[0];

            });


          let approveRes;
          // approveRes = this.factory.MountComponent(
          //   this.approveFormHolder,
          //   PureApproveFormComponent,
          //   {
          //     table_name: this.entity_code,
          //     uuid: this.detail['sys$uuid'],
          //     user: this.user,
          //     id: this.detailId,
          //     showButtons: true,
          //     showApproveButtons: true,
          //     parentEmitter: this.emitter,
          //     detail: this.detail,
          //     templateId: 72,
          //   }
          // );

          approveRes.instance.doStart = this.doStart;
          approveRes.instance.doAction = this.doAction;
          approveRes.instance.onTasksLoaded.subscribe(res => {
            console.log("OnTasksLOad", res);
            this.tasks = res.all_tasks;
            this.currentTask = res.tasks.filter(x => x['status_id$code'] == 'opened')[0];
            console.log("currennt",this.currentTask);

            this.approve_res = res.task_approve_res;

          })

          // this.factory.MountComponent(this.status, StepInfoComponent, {
          //   table_name: this.entity_code,
          //   id: this.detailId,
          //   detail: this.detail,
          // });
        }
        query.unsubscribe();
      });
  }
  startApprove(detail?) {
    this.doStart.emit({});
    this.bpRun('hre_req_bp', {
      entity_code: this.entity_code,
      entity_pk: this.detail['sys$uuid'],
      id: this.detailId,
      user_id: this.detail['created_by'],

    })
  }
  doApprove(event){
    console.log(event);
  if(this.currentTask['action_type']==1){
    this.task_manager_id = this.currentTask['manager_id'];
    this.displayEdsModal = true;
  }else if (this.currentTask['action_type']==2){
    this.bpRun('hre_application_close', {
      entity_code: this.entity_code,
      pk: this.detailId,
      pk_uuid: this.currentTask['pk_uuid'],
      task_id: this.currentTask['task_id'],
    });
  }
      this.doAction.emit(event);

  //  this.tasks.forEach(t => {
  //   if(t['status_id$code'] == 'approver') {
  //     this.task_manager_id = this.currentTask['manager_id'];
  //     this.displayEdsModal = true;
  //   }
  //   else if (t['status_id$code'] == 'familirized') {

  //   } })
  }



  onApproveResult(data: any) {
    console.log('After approve: ', data);
    if (data?.approve_res_id == APPROVE_RESULT.IS_APPROVED) {
      this.task_manager_id = data.user_id_s;
      this.displayEdsModal = true;
    } else if (data?.approve_res_id == APPROVE_RESULT.IS_FAMILIARIZED) {
      this.bpRun('hre_application_close', {
        entity_code: this.entity_code,
        pk: this.detailId,
        pk_uuid: data.pk_uuid,
        task_id: data.task_id,
      });
    } else if (data?.approve_res_id == APPROVE_RESULT.IS_VERIFIED) {
      this.bpRun('hre_application_verify', {
        entity_code: this.entity_code,
        pk: this.detailId,
        pk_uuid: data.pk_uuid,
        task_id: data.task_id,
      });
    }
  }

  onDocumentSigned(data: any) {
    this.bpRun('hre_application_approve', {
      entity_code: this.entity_code,
      pk: this.detailId,
      signxml: data.sign,
    });
  }

  bpRun(code: string, input: any) {
    this.dbQueryService
      .bpRun(code, input)
      .subscribe((resp: RunTaskResponse) => {
        console.log(code + ': ', resp);
        if (resp.ok) {
          if (resp.instanceIsFinished) {
            if (!resp.output.last_error) {
              //this.mainService.toastSuccess('Успешно');
              //this.getDetails(this.detailId);
            } else {
              this.mainService.toastError(resp.output.last_error);
            }
          } else if (resp.task) {
            // this.openBpModal();
            // this.getUserTaskData(resp.task);
          } else {
            this.mainService.toastInfo('BPM Run', 'Процесс запущен.');
          }
        } else {
          this.mainService.toastError('Ошибка! Что-то пошло не так.');
        }

        this.displayEdsModal = false;
      });
  }
  getApplicant(app) {
    this.applicant = app;
    //console.log('Parent', this.applicant);
  }
  back() {
    this.location.back();
  }
}

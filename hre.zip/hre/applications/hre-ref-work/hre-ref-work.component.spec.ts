import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HreRefWorkComponent } from './hre-ref-work.component';

describe('HreRefWorkComponent', () => {
  let component: HreRefWorkComponent;
  let fixture: ComponentFixture<HreRefWorkComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HreRefWorkComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HreRefWorkComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

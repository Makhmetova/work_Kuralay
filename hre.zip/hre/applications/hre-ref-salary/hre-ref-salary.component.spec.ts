import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HreRefSalaryComponent } from './hre-ref-salary.component';

describe('HreRefSalaryComponent', () => {
  let component: HreRefSalaryComponent;
  let fixture: ComponentFixture<HreRefSalaryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HreRefSalaryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HreRefSalaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

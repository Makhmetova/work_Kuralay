import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RefSalaryDetailComponent } from './ref-salary-detail.component';

describe('RefSalaryDetailComponent', () => {
  let component: RefSalaryDetailComponent;
  let fixture: ComponentFixture<RefSalaryDetailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RefSalaryDetailComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RefSalaryDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

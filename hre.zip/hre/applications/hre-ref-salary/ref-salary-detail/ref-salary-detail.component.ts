import { Component, Input, OnInit, SimpleChanges } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { EntityClass } from '@app/_models/entity';
import { AccountService, DbQueryService } from '@app/_services';
import { MainService } from '@app/_services/main.service';

@Component({
  selector: 'app-ref-salary-detail',
  templateUrl: './ref-salary-detail.component.html',
  styleUrls: ['./ref-salary-detail.component.less']
})
export class RefSalaryDetailComponent implements OnInit {

  @Input() detailId: number;
  entity_code= "hre_ref_sal";
  @Input() details: any;

  entity_class: EntityClass;
  executors: any[] = [];
  statuses: any[] = [];
  sessionRoles: Object;
  
  // form: FormGroup;
  
  
  constructor(
    private mainService: MainService,
    private dbQueryService: DbQueryService,
    private router: Router,
    private accountService: AccountService
  ) { }

  ngOnInit(): void {
    this.sessionRoles = this.accountService.sessionRoles;

    this.getItemsSelect("users_select_by_roles", "", { param1: 'hr_manager' }).toPromise()
      .then((res) => {
        this.executors = res.items;
        return this.getItemsSelect("hre_application_status_select", "").toPromise();
      }).then((res) => {
        this.statuses = res.items;
        this.getEntityAttrs(this.entity_code);
      });
  }

  ngAfterViewInit() {
  }
  
  ngOnChanges(changes: SimpleChanges): void {
    if (changes.details && this.entity_class) {
      this.bind();
    }
  }

  bind() {
    this.entity_class.form = this.entity_class.createForm();
    if (this.details) {
      this.entity_class.bindForm(this.entity_class.form, this.details[this.entity_code][0]);
    }
  }

  getEntityAttrs(code: string) {
    this.dbQueryService.getEntityAttrsByCode(code)
      .subscribe( res => {
        if (res.items) {
          this.entity_class = new EntityClass(this.entity_code);
          this.entity_class.setEntityAttrs(res.items);
          this.bind();
        }
      })
  }

  getItemsSelect(code: string, _query?: string, params?: Object) {
    return this.dbQueryService.getQuerySelect(code, _query, 100, params);
  }

  save() {
    if (this.detailId) {
      this.dbQueryService.updateTable(this.entity_code, [this.entity_class.form.getRawValue()])
        .toPromise().then(res => {
          if (res['error']) {
            this.mainService.toastError(res['error_text']);
          } else {
            this.mainService.toastSuccess("Заявка успешно обновлено!");
          }
        });
    } else {
      this.dbQueryService.insertTable(this.entity_code, [this.entity_class.form.getRawValue()])
        .toPromise().then(res => {
          if (res['error']) {
            this.mainService.toastError(res['error_text']);
          } else {
            this.router.navigate(['/hre_ref_sal_details', { id: res['items'][0]['last_inserted_id']}])
          }
        });
    }
  }

  cancel() {
    this.bind();
  }

  ngOnDestroy() {

  }

}

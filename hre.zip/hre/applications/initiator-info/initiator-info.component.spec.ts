import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InitiatorInfoComponent } from './initiator-info.component';

describe('InitiatorInfoComponent', () => {
  let component: InitiatorInfoComponent;
  let fixture: ComponentFixture<InitiatorInfoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InitiatorInfoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InitiatorInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, Input, OnChanges, OnInit, SimpleChanges, EventEmitter as ngEventEmitter, Output } from '@angular/core';
import { UserInfo } from '@app/_models';
import { AccountService, MainService } from '@app/_services';
import { take } from 'rxjs/operators';

@Component({
  selector: 'app-initiator-info',
  templateUrl: './initiator-info.component.html',
  styleUrls: ['./initiator-info.component.less']
})
export class InitiatorInfoComponent implements OnInit, OnChanges {

  @Input() userId: string;
  @Output() onApplicantChange = new ngEventEmitter<Object>()
  @Input() detail: Object;

  userInfo: UserInfo;

  users: Array<Object> = [];
  applicant: UserInfo;
  lm_user_id:any;
  lmanager: any;

  usersSubscription = this.main.usersObservable.pipe(take(1)).subscribe((users) => {
    this.users = this.users.concat(...users);
    console.log('users loaded')
  });
  constructor(
    private accountService: AccountService,
    private main: MainService
  ) { }

  ngOnInit(): void {
  }

  ngOnChanges(changes: SimpleChanges): void {
    // console.log("Initiator changes: ", changes);
    if (changes.userId) {
      this.bind();
    }
  }

  ngAfterViewInit() {
    this.bind();
  }

  bind() {
    console.log(this.userId);

    if (this.userId) {
      let query = this.accountService.getById(this.userId)
      .subscribe( res => {
        if (res) {
          this.userInfo = res['users'][0];
          this.applicant = res['users'][0];
          // console.log("Initiator info: ", this.applicant);
        }
        query.unsubscribe();
      });
    }
  }
  getApplicantInfo() {
    if (this.applicant.id) {
      this.accountService.getById(this.applicant.id).subscribe(userInfo => {
        this.applicant = userInfo['users'][0];
        console.log(this.applicant);
        this.onApplicantChange.emit(this.applicant);

      });
    }
  }
}
